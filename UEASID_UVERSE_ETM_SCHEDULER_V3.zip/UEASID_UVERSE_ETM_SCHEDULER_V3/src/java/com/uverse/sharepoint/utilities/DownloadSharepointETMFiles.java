package com.uverse.sharepoint.utilities;

import java.io.File;
import java.net.URLEncoder;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.io.FileUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpStatus;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.NTCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpRequestRetryHandler;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;


import com.savvion.custom.framework.util.DBUtil;
import com.savvion.custom.framework.util.MechDetails;
import com.savvion.custom.framework.util.MechUtil;
import com.att.savvion.logger.UBMLogger;
import com.uverse.mktg.constants.SharepointConstants;


/**
 * @author sm802k
 *
 */
public class DownloadSharepointETMFiles {

  /**
   * download a file from a sharepoint library
   */
	
	private static Logger logger = UBMLogger.self().getLogger(SharepointConstants.ETM_IMPORT_LOGGER_NAME);

   /**
 * @param Files
 */
public static void downloadETMFiles(Set<String> Files){
	   
	  String etmFileName=null;
     try {
		CloseableHttpClient httpclient = HttpClients.custom()
		  .setRetryHandler(new DefaultHttpRequestRetryHandler(0,false))
		  .build();

		//System.setProperty("javax.net.ssl.trustStore", "jssecacerts");
	

		CredentialsProvider credsProvider = new BasicCredentialsProvider();
		MechDetails mechDetails = MechUtil.getMechDetails();
		String credntials ="";
		if(mechDetails.getMechPassword()!=null){
			credntials = mechDetails.getMechPassword();
		}
		credsProvider.setCredentials(AuthScope.ANY,
						new NTCredentials(mechDetails.getMechId(), credntials, "",""));
		
		/*credsProvider.setCredentials(AuthScope.ANY,
		new NTCredentials(Util.getMechId(), Util.getMechPassword(), "",""));*/
		
		 //HttpHost target = new HttpHost("hltv0280.hydc.sbc.com", 80, "http");
		 HttpClientContext context = HttpClientContext.create();
		 context.setCredentialsProvider(credsProvider);

		 // The authentication is NTLM.
		 // To trigger it, we send a minimal http request
		 CloseableHttpResponse response1 = null;
		 
		 try {
    		 String etmfiles[]= Files.toArray(new String[Files.size()]);;
    		 String targetFolder = SharepointConstants.LOCALFOLDERNAME;
			 deleteFolder(new File(targetFolder));
			 for (int i = 0; i < etmfiles.length; i++) {			
				 logger.logp(Level.ALL, DownloadSharepointETMFiles.class.getSimpleName(), "downloadETMFiles()","Count:"+ i + etmfiles[i]);
		     String file = URLEncoder.encode(etmfiles[i], "UTF-8");   
		     	logger.logp(Level.ALL, DownloadSharepointETMFiles.class.getSimpleName(), "downloadETMFiles()","file is:"+file);
		    // etmFileName = file+SharepointConstants.ETM_FILEEXT;
		     etmFileName = file;
		     // String get target Url from config table 
		     String targetURL = DBUtil.getConfigNVP("SHAREPOINT", "CONFIGURATION", "TARGET_URL");
		     //parse etmFileName get its .ext and append.
		     //HttpGet request2 = new HttpGet(SharepointConstants.TARGETURL+file);
		     HttpGet request2 = new HttpGet(targetURL+file);
			 
		     response1 = httpclient.execute(request2, context);
		     		     
		     HttpEntity entity = response1.getEntity();
		          
		   int rc = response1.getStatusLine().getStatusCode();
		   String reason = response1.getStatusLine().getReasonPhrase();
		   
		   if (rc == HttpStatus.SC_OK) {
			   logger.logp(Level.ALL, DownloadSharepointETMFiles.class.getSimpleName(), "downloadETMFiles()","Writing "+ file + ":" + targetFolder);
		      //File f = new File(file+SharepointConstants.ETM_FILEEXT);
			  File f = new File(file);
		      File ff= new File(targetFolder, f.getName());  // target
		      
		      // writing the byte array into a file using Apache Commons IO
		      
		      FileUtils.writeByteArrayToFile(ff, EntityUtils.toByteArray(entity));
		   }
		   else {
			   //continue;
			   logger.logp(Level.ALL, DownloadSharepointETMFiles.class.getSimpleName(), "downloadETMFiles()","Problem receiving " + file );
			   logger.logp(Level.ALL, DownloadSharepointETMFiles.class.getSimpleName(), "downloadETMFiles()", "reason : " + reason);
					   logger.logp(Level.ALL, DownloadSharepointETMFiles.class.getSimpleName(), "downloadETMFiles()", "httpcode : " + rc);
		     
		     try {
				} catch (Exception e1) {
					logger.logp(Level.ALL, DownloadSharepointETMFiles.class.getSimpleName(), "downloadETMFiles()", "Exception "+e1);
					e1.printStackTrace();
				}
		      
		   }
		         
			 }
		 }
		 finally {
		   if (response1 != null ) response1.close();
		 }
	} catch (Exception e) {
		logger.logp(Level.ALL, DownloadSharepointETMFiles.class.getSimpleName(), "downloadETMFiles()", "Exception  Connect Sharepoint "+e);
		e.printStackTrace();
		
	}

   }
   
   /**
 * @param folder
 */
public static void deleteFolder(File folder) {
	    File[] files = folder.listFiles();
	    if(files!=null) { //some JVMs return null for empty dirs
	        for(File f: files) {
	            if(f.isFile()) {	                
	                f.delete();
	            }
	        }
	    }	    
	}

}