package com.uverse.mktg.utilities;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import java.sql.SQLException;

import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.bean.CsvToBean;
import au.com.bytecode.opencsv.bean.HeaderColumnNameTranslateMappingStrategy;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.naming.NamingException;

import com.att.savvion.logger.UBMLogger;
import com.uverse.mktg.bean.ConfigBean;

import com.uverse.mktg.bean.QuotaBean;

import com.uverse.mktg.constants.SharepointConstants;
import com.savvion.custom.framework.util.DBUtil;
import com.uverse.mktg.dao.UtilityDAO;
import com.uverse.mktg.util.CommonUtility;



/**
 * @author sm802k
 *
 */
public class Quota_ImportUtility{
	
	//static String filename = "C:\\TBQUOTA_LIMITS_GLOB_RPTS.csv";
	private static String folderName = SharepointConstants.LOCALFOLDERNAME+"/";
	private static String etmFileName = "TBQUOTA_LIMITS_GLOB_RPTS";
	private String filename ="";
	private static Logger logger = UBMLogger.self().getLogger(SharepointConstants.ETM_IMPORT_LOGGER_NAME);
	private CommonUtility cUtil=new CommonUtility(etmFileName,folderName);
	private ConfigBean cBean=null;
	private Map<String,ConfigBean> configData=new HashMap<String,ConfigBean>();
	/**
	 * @param args
	 * @throws IOException
	 * @throws SQLException
	 */
	public static void main(String[] args) throws IOException, SQLException, NamingException {

		Quota_ImportUtility quota_ImportUtility = new Quota_ImportUtility();
		quota_ImportUtility.utility();

	}// end of main method

	/**
	 * @throws SQLException
	 * @throws NamingException
	 */
	public void utility() throws SQLException, NamingException {

		logger.logp(Level.ALL, this.getClass().getName(), "utility()","Enter");
			Boolean match = false;
			Connection conn = DBUtil.getConnection();
			try {
				conn.setAutoCommit(false);
				
				
			} catch (SQLException e2) {
				e2.printStackTrace();
				logger.logp(Level.ALL, this.getClass().getName(), "utility()", "Exception caught while utility "+e2);
			}
			try {
				match =cUtil.checkForMatchingColumns(conn);
				configData= cUtil.getConfigData();
				cBean=(ConfigBean) configData.get(etmFileName);
				logger.logp(Level.ALL, this.getClass().getName(), "utility()","TableName"+cBean.getTableName());
				logger.logp(Level.ALL, this.getClass().getName(), "utility()","BkpTableName"+cBean.getBkpTableName());
				if (match) {
					
					UtilityDAO.truncateBackupTable(conn,cBean.getBkpTableName());
					UtilityDAO.copyFromMasterToBackup(conn,cBean.getBkpTableName(),cBean.getTableName());
					UtilityDAO.truncateMasterTable(conn,cBean.getTableName());
					insertToMasterTable(conn);
					DBUtil.commitTransaction(conn);
				}
				else {
					logger.logp(Level.ALL, this.getClass().getName(), "utility()","Column Mismatch--Cannot copy to table");
				}
			} catch (Exception e) {
				e.printStackTrace();
				logger.logp(Level.ALL, this.getClass().getName(), "utility()", "Exception caught while DB manipulation "+e);
				DBUtil.rollbackTransaction(conn);
				

				try {
					SendEmail.sendExceptionToDevTeam(e,cBean.getFileName());
				} catch (Exception e1) {
					e1.printStackTrace();
					logger.logp(Level.ALL, this.getClass().getName(), "utility()", "Exception caught while SendEmail "+e1);
				}
				
			} finally {
				DBUtil.closeConnection(conn);
			}
		
	}



	public void insertToMasterTable(Connection conn) throws FileNotFoundException, SQLException {
		filename =folderName+cBean.getFileName()+cBean.getFileExt();//permanent filename
		PreparedStatement pstmt = null;
		String insertQuery = "Insert into UVERSE_QUOTA (GLOBAL_STATUS, QUOTA, " +
				"PROMO_OR_BUNDLE_ID, OFFER_ID, BUNDLE_PROMOTION_TYPE, QUOTA_LEVEL, " +
				"ENTITY, START_DATE, END_DATE, QUOTA_AMOUNT, DEPLOY_DATE, " +
				"CTDB_CREATION_DATE_TIME, LAST_IMPORT_DATE_TIME, LAST_IMPORTED_BY, ROW_ACTION_CODE, WORK_EFFORT_NAME, ENVIRONMENT_SOURCE)" +
				" VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

		pstmt = conn.prepareStatement(insertQuery);
		HeaderColumnNameTranslateMappingStrategy<QuotaBean> headerColumnNameMappingStrategy = null;
		headerColumnNameMappingStrategy=new HeaderColumnNameTranslateMappingStrategy<QuotaBean>();
		headerColumnNameMappingStrategy.setType(QuotaBean.class);

		CSVReader csvReader = new CSVReader(new FileReader(filename));
		CsvToBean<QuotaBean> csv = new CsvToBean<QuotaBean>();
		HashMap<String, String> columnMapping = new HashMap<String, String>();
		
		columnMapping=cUtil.getCsvColMap();
		headerColumnNameMappingStrategy.setColumnMapping(columnMapping);

		List<QuotaBean> list = csv.parse(headerColumnNameMappingStrategy, csvReader);
		
				
		for (Object object : list) {
			QuotaBean quotaBean = (QuotaBean) object;		
		
			pstmt.setString(1,quotaBean.getGlobalStatus());
			pstmt.setString(2,quotaBean.getQuotaID());
			pstmt.setString(3,quotaBean.getBundlePromoID());
			pstmt.setString(4,quotaBean.getOfferID());
			pstmt.setString(5,quotaBean.getBundlePromotionType());
			pstmt.setString(6,quotaBean.getQuotaLevel());
			pstmt.setString(7,quotaBean.getEntityID());
			pstmt.setString(8,quotaBean.getStartDate());
			pstmt.setString(9,quotaBean.getEndDate());
			pstmt.setString(10,quotaBean.getQuotaAmount());
			pstmt.setString(11,quotaBean.getDeployDate());
			pstmt.setString(12,quotaBean.getCTDBCreationDateTime());
			pstmt.setString(13,quotaBean.getLastImportDateTime());
			pstmt.setString(14,quotaBean.getLastImportedBy());
			pstmt.setString(15,quotaBean.getRowActionCode());
			pstmt.setString(16,quotaBean.getWorkEffortName());
			pstmt.setString(17,quotaBean.getEnvironmentSource());
			
						
			pstmt.addBatch();
		}
		
		pstmt.executeBatch();
		if(pstmt!=null)
		{
			pstmt.close();
		}
		logger.logp(Level.ALL, this.getClass().getName(), "insertToMasterTable()","Copy from csv to master table");
	}
	
}// end of utility class
