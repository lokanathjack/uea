package com.uverse.mktg.utilities;


import java.io.File;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import com.att.savvion.logger.UBMLogger;
import com.savvion.custom.framework.util.DBUtil;
import com.uverse.mktg.constants.SharepointConstants;
import com.uverse.sharepoint.utilities.DownloadSharepointETMFiles;
import com.savvion.sbm.bizlogic.server.ejb.BLServer;
import com.savvion.sbm.bizlogic.server.ejb.BLServerHome;
import com.savvion.ejb.bizlogic.manager.BizLogicManager;
import com.savvion.ejb.bizlogic.manager.BizLogicManagerHome;
import com.savvion.sbm.bizlogic.server.svo.DocumentDS;


/**
 * Auto-generated
 */
public class GetFileList{
	@SuppressWarnings("all")
	private java.util.Vector fileList;
	private static Logger logger = UBMLogger.self().getLogger(SharepointConstants.ETM_IMPORT_LOGGER_NAME);
	private static final String fetch_FileList = "select FILE_NAME,CLASS_NAME,FILE_EXT from UVERSE_ETM_COLUMNS_KCP";
	@SuppressWarnings("all")
	public java.util.Vector getFileList() {
		return this.fileList;
	}
	@SuppressWarnings("all")
	public void setFileList(java.util.Vector fileList) {
		this.fileList = fileList;
	}
	/**
	 * @throws Exception
	 */
	public void readFilesFromFolder() throws FileNotFoundException {
		logger.logp(Level.ALL, this.getClass().getName(),"readFilesFromFolder()","readFilesFromFolder");
		//Load FileListHM from DB
		fileListhm=loadFileListHM();
		logger.logp(Level.ALL, this.getClass().getName(),"readFilesFromFolder()","fileListhm:"+fileListhm);
		fileList = new Vector();
		//downloading files
		logger.logp(Level.ALL, this.getClass().getName(),"readFilesFromFolder()","key set :"+fileListhm.keySet());
		DownloadSharepointETMFiles.downloadETMFiles(fileListhm.keySet());
		//reading for import
		File folder = new File(SharepointConstants.LOCALFOLDERNAME); 
		File[] listOfFiles = folder.listFiles();
		logger.logp(Level.ALL, this.getClass().getName(),"readFilesFromFolder()","Number of Files:" + listOfFiles.length);
			
			for (int i = 0; i < listOfFiles.length; i++) {
		    if (listOfFiles[i].isFile()) {
		    	  		    	  
		    	logger.logp(Level.ALL, this.getClass().getName(),"readFilesFromFolder()","File " + listOfFiles[i].getName());
		    	 fileList.add(listOfFiles[i].getName());
		       }      	  
			} 	  
	}
	
	private Map<String,String> loadFileListHM() {
		logger.logp(Level.ALL, this.getClass().getName(),"loadFileListHM()","Enter loadFileListHM");
		Map<String,String> tmpFileList=new HashMap<String,String>();
		 PreparedStatement prpstmt = null;
		 Connection conn=null;
		 ResultSet rs = null;
			try {
				conn=DBUtil.getConnection();
				prpstmt = conn.prepareStatement(fetch_FileList);
				rs = prpstmt.executeQuery();
					while(rs.next())
					{
						tmpFileList.put(rs.getString("FILE_NAME")+rs.getString("FILE_EXT"),rs.getString("CLASS_NAME"));
					}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.logp(Level.ALL, this.getClass().getName(), "loadFileListHM()", "Exception caught while "+e);
			}
			finally
			{
				DBUtil.close(rs, prpstmt, conn);
			}
			logger.logp(Level.ALL, this.getClass().getName(),"loadFileListHM()","Exit loadFileListHM");
		return tmpFileList;
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		GetFileList gfl = new GetFileList();
		try {
			gfl.readFilesFromFolder();
		} catch (Exception e) {
			logger.logp(Level.ALL, GetFileList.class.getName(), "main()", "Exception caught while "+e);
		}
		
	}

	/**
	 * @param processInstanceName
	 * @param workstepName
	 * @param bizLogicHost
	 */
	public void PAKcallerID(String processInstanceName, String workstepName,
			java.util.Properties bizLogicHost) {
	}
	@SuppressWarnings("unchecked")
	private java.util.Map fileListhm;
	@SuppressWarnings("unchecked")
	public java.util.Map getFileListhm() {
		return this.fileListhm;
	}
	@SuppressWarnings("unchecked")
	public void setFileListhm(java.util.Map fileListhm) {
		this.fileListhm = fileListhm;
	}
	
}