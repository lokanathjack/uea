package com.uverse.mktg.utilities;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import java.sql.SQLException;

import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.bean.CsvToBean;
import au.com.bytecode.opencsv.bean.HeaderColumnNameTranslateMappingStrategy;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;

import javax.naming.NamingException;

import com.att.savvion.logger.UBMLogger;
import com.uverse.mktg.bean.ConfigBean;
import com.uverse.mktg.bean.GroupAttributesBean;
import com.uverse.mktg.constants.SharepointConstants;
import com.savvion.custom.framework.util.DBUtil;
import com.uverse.mktg.dao.UtilityDAO;
import com.uverse.mktg.util.CommonUtility;
import java.util.logging.Logger;



/**
 * @author sm802k
 *
 */
public class GroupAttributes_ImportUtility {

	 
	//static String filename = "C:\\TBATTRIBUTE_RULES_GLOB_RPTS.csv";
	private static String folderName = SharepointConstants.LOCALFOLDERNAME+"/";
	private static String etmFileName = "TBATTRIBUTE_RULES_GLOB_RPTS";
	private String filename ="";
	private static Logger logger = UBMLogger.self().getLogger(SharepointConstants.ETM_IMPORT_LOGGER_NAME);
	private CommonUtility cUtil=new CommonUtility(etmFileName,folderName);
	private ConfigBean cBean=null;
	private Map<String,ConfigBean> configData=new HashMap<String,ConfigBean>();
	/**
	 * @param args
	 * @throws IOException
	 * @throws SQLException
	 */

	
	
	/**
	 * @param args
	 * @throws IOException
	 * @throws SQLException
	 * @throws NamingException
	 */
	public static void main(String[] args) throws IOException, SQLException, NamingException {

		GroupAttributes_ImportUtility groupAttributes_ImportUtility = new GroupAttributes_ImportUtility();
		groupAttributes_ImportUtility.utility();

	}// end of main method

	/**
	 * @throws SQLException
	 * @throws NamingException
	 */
	public void utility() throws SQLException, NamingException {

		logger.logp(Level.ALL, this.getClass().getName(), "utility()","Enter into GroupAttributes_ImportUtility::::");
			Boolean match = false;
			Connection conn = DBUtil.getConnection();
			try {
				conn.setAutoCommit(false);
				
				
			} catch (SQLException e2) {
				logger.logp(Level.ALL, this.getClass().getName(), "utility()", "Exception caught while utility "+e2);
				e2.printStackTrace();
			}
			try {
				match =cUtil.checkForMatchingColumns(conn);
				configData= cUtil.getConfigData();
				cBean=(ConfigBean) configData.get(etmFileName);
				logger.logp(Level.ALL, this.getClass().getName(), "utility()","TableName"+cBean.getTableName());
				logger.logp(Level.ALL, this.getClass().getName(), "utility()","BkpTableName"+cBean.getBkpTableName());
				if (match) {
					
					UtilityDAO.truncateBackupTable(conn,cBean.getBkpTableName());
					UtilityDAO.copyFromMasterToBackup(conn,cBean.getBkpTableName(),cBean.getTableName());
					UtilityDAO.truncateMasterTable(conn,cBean.getTableName());
					insertToMasterTable(conn);
					DBUtil.commitTransaction(conn);
				}
				else {
					logger.logp(Level.ALL, this.getClass().getName(), "utility()","Column Mismatch--Cannot copy to table");
				}
			} catch (Exception e) {
				e.printStackTrace();
				logger.logp(Level.ALL, this.getClass().getName(), "utility()", "Exception caught while DB manipulation "+e);
				
				DBUtil.rollbackTransaction(conn);
				

				try {
					SendEmail.sendExceptionToDevTeam(e,cBean.getFileName());
				} catch (Exception e1) {
					e1.printStackTrace();
					logger.logp(Level.ALL, this.getClass().getName(), "utility()", "Exception caught while SendEmail "+e1);
				}
				
			} finally {
				DBUtil.closeConnection(conn);
			}
		
	}



	
	/**
	 * @param conn
	 * @throws FileNotFoundException
	 * @throws SQLException
	 */
	public void insertToMasterTable(Connection conn) throws FileNotFoundException, SQLException {
		filename =folderName+cBean.getFileName()+cBean.getFileExt();//permanent filename
		String sqlCopyFromCsvToMaster = "INSERT INTO UVERSE_ATTRIBUTE_RULES (GLOBAL_STATUS,RULE_ID,ATTRIBUTE_NAME,OPERATOR_VALUE,"
			+ "MIN_VALUE,MAX_VALUE,MIN_DURATION,MAX_DURATION,START_DATE,END_DATE,RESTRICT_GROUP_ID,RESTRICT_TARGET,RESTRICT_ORDERED,"
			+ "LEGALLY_BOUND,DEPLOY_DATE,STATUS,ROW_ACTION_CODE,LAST_IMPORT_DATE_TIME,LAST_IMPORTED_BY," +
			"WORK_EFFORT_NAME,ENVIRONMENT_SOURCE,RESTRICT_EXCEPTION,RULE_GROUP) "
			+ "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement pstmt = null;
		pstmt = conn.prepareStatement(sqlCopyFromCsvToMaster);
		HeaderColumnNameTranslateMappingStrategy<GroupAttributesBean> headerColumnNameMappingStrategy=null;
		headerColumnNameMappingStrategy = new HeaderColumnNameTranslateMappingStrategy<GroupAttributesBean>();
		headerColumnNameMappingStrategy.setType(GroupAttributesBean.class);

		CSVReader csvReader = new CSVReader(new FileReader(filename));
		CsvToBean<GroupAttributesBean> csv = new CsvToBean<GroupAttributesBean>();
		HashMap<String, String> columnMapping = new HashMap<String, String>();
		
		columnMapping=cUtil.getCsvColMap();
		headerColumnNameMappingStrategy.setColumnMapping(columnMapping);

		List<GroupAttributesBean> list = csv.parse(
				headerColumnNameMappingStrategy, csvReader);
		int i = 0;
		
		//for (int j = 0; j < 1; j++) {
			
			//GroupAttributesBean groupAttributesBean = (GroupAttributesBean) list.get(j);
			
			
				
		for (Object object : list) {
			GroupAttributesBean groupAttributesBean = (GroupAttributesBean) object;

			/*debug("Row Number : "+i
					  +" >> "+groupAttributesBean.getGlobalStatus());
					  debug("Row Number : "+i +" >> "+groupAttributesBean.getRuleID());
					  debug("Row Number : "+i
					  +" >> "+groupAttributesBean.getAttributeName());
					  debug("Row Number : "+i
					  +" >> "+groupAttributesBean.getOperatorValue());
					  debug("Row Number : "+i
					  +" >> "+groupAttributesBean.getMinValue());
					  debug("Row Number : "+i
					  +" >> "+groupAttributesBean.getMaxValue());
					  debug("Row Number : "+i
					  +" >> "+groupAttributesBean.getMinDuration());
					  debug("Row Number : "+i
					  +" >> "+groupAttributesBean.getMaxDuration());
					  debug("Row Number : "+i
					  +" >> "+groupAttributesBean.getStartDate());
					  debug("Row Number : "+i
					  +" >> "+groupAttributesBean.getEndDate());
					  debug("Row Number : "+i
					  +" >> "+groupAttributesBean.getRestrictGroupID());
					  debug("Row Number : "+i
					  +" >> "+groupAttributesBean.getRestrictTarget());
					  debug("Row Number : "+i
					  +" >> "+groupAttributesBean.getRestrictOrdered());
					  debug("Row Number : "+i
					  +" >> "+groupAttributesBean.getLegallyBound());
					  debug("Row Number : "+i
					  +" >> "+groupAttributesBean.getDeployDate());
					  debug("Row Number : "+i +" >> "+groupAttributesBean.getStatus());
					  debug("Row Number : "+i
					  +" >> "+groupAttributesBean.getRowActionCode());
					  debug("Row Number : "+i
					  +" >> "+groupAttributesBean.getLastImportDateTime());
					  debug("Row Number : "+i
					  +" >> "+groupAttributesBean.getLastImportedBy());
					  debug("Row Number : "+i
					  +" >> "+groupAttributesBean.getWorkEffortName());
					  debug("Row Number : "+i
					  +" >> "+groupAttributesBean.getEnvironmentSource());*/
			
			pstmt.setString(1, groupAttributesBean.getGlobalStatus());
			pstmt.setString(2, groupAttributesBean.getRuleID());
			pstmt.setString(3, groupAttributesBean.getAttributeName());
			pstmt.setString(4, groupAttributesBean.getOperatorValue());
			pstmt.setString(5, groupAttributesBean.getMinValue());
			pstmt.setString(6, groupAttributesBean.getMaxValue());
			pstmt.setString(7, groupAttributesBean.getMinDuration());
			pstmt.setString(8, groupAttributesBean.getMaxDuration());
			pstmt.setString(9, groupAttributesBean.getStartDate());
			pstmt.setString(10, groupAttributesBean.getEndDate());
			pstmt.setString(11, groupAttributesBean.getRestrictGroupID());
			pstmt.setString(12, groupAttributesBean.getRestrictTarget());
			pstmt.setString(13, groupAttributesBean.getRestrictOrdered());
			pstmt.setString(14, groupAttributesBean.getLegallyBound());
			pstmt.setString(15, groupAttributesBean.getDeployDate());
			pstmt.setString(16, groupAttributesBean.getStatus());
			pstmt.setString(17, groupAttributesBean.getRowActionCode());
			pstmt.setString(18, groupAttributesBean.getLastImportDateTime());
			pstmt.setString(19, groupAttributesBean.getLastImportedBy());
			pstmt.setString(20, groupAttributesBean.getWorkEffortName());
			pstmt.setString(21, groupAttributesBean.getEnvironmentSource());
			pstmt.setString(22, groupAttributesBean.getRestrictException());
			pstmt.setString(23, groupAttributesBean.getRuleGroup());
			pstmt.addBatch();
			 i++;
			
		}
		//logger.info("sqlCopyFromCsvToMaster::::"+sqlCopyFromCsvToMaster);
		pstmt.executeBatch();
		if(pstmt!=null)
		{
			pstmt.close();
		}
		logger.logp(Level.ALL, this.getClass().getName(), "insertToMasterTable()","Copy from csv to master table");
	}
	
}// end of utility class
