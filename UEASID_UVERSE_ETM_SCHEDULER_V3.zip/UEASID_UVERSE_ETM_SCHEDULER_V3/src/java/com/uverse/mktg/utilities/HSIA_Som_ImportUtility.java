package com.uverse.mktg.utilities;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import java.sql.SQLException;

import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.bean.CsvToBean;
import au.com.bytecode.opencsv.bean.HeaderColumnNameTranslateMappingStrategy;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.naming.NamingException;

import com.att.savvion.logger.UBMLogger;
import com.uverse.mktg.bean.ConfigBean;
import com.uverse.mktg.bean.SomBean;
import com.uverse.mktg.constants.SharepointConstants;
import com.savvion.custom.framework.util.DBUtil;
import com.uverse.mktg.dao.UtilityDAO;
import com.uverse.mktg.util.CommonUtility;



public class HSIA_Som_ImportUtility {
	
	private static String folderName = SharepointConstants.LOCALFOLDERNAME+"/";
	//static String filename="C:\\HSIA_SOM_PROMO_RPT.csv";
	private static String etmFileName="HSIA_SOM_PROMO_RPT";
	private String filename ="";
	//private static java.util.logging.Logger logger = UBMLogger.self().getLogger(Constants.UVERSE_LOGGER_NAME);
	private CommonUtility cUtil=new CommonUtility(etmFileName,folderName);
	private ConfigBean cBean=null;
	private Map<String,ConfigBean> configData=new HashMap<String,ConfigBean>();
	/**
	 * @param args
	 * @throws IOException
	 * @throws SQLException
	 */

	private static Logger logger = UBMLogger.self().getLogger(SharepointConstants.ETM_IMPORT_LOGGER_NAME);
	/**
	 * @param args
	 * @throws IOException
	 * @throws SQLException
	 * @throws NamingException
	 */
	public static void main(String[] args) throws IOException, SQLException, NamingException {

		HSIA_Som_ImportUtility hSIA_Som_ImportUtility = new HSIA_Som_ImportUtility();
		hSIA_Som_ImportUtility.utility();

	}// end of main method

	/**
	 * @throws SQLException
	 * @throws NamingException
	 */
	public void utility() throws SQLException, NamingException {

		logger.logp(Level.ALL, this.getClass().getName(), "utility()","Enter into HSIA_Som_ImportUtility");
		    
			Boolean match = false;
			Connection conn = DBUtil.getConnection();
			try {
				conn.setAutoCommit(false);
				
				
			} catch (SQLException e2) {
				logger.logp(Level.ALL, this.getClass().getName(), "utility()", "Exception caught while utility "+e2);
				e2.printStackTrace();
			}
			try {
				match =cUtil.checkForMatchingColumns(conn);
				configData= cUtil.getConfigData();
				cBean=(ConfigBean) configData.get(etmFileName);
				logger.logp(Level.ALL, this.getClass().getName(), "utility()","TableName"+cBean.getTableName());
				logger.logp(Level.ALL, this.getClass().getName(), "utility()","BkpTableName"+cBean.getBkpTableName());
				logger.logp(Level.ALL, this.getClass().getName(), "utility()","SomComponent"+cBean.getSomComponent());
				if (match) {
					UtilityDAO.truncateBackupTableSom(conn,cBean.getBkpTableName(),cBean.getSomComponent());
					UtilityDAO.copyFromMasterToBackupSom(conn,cBean.getBkpTableName(),cBean.getTableName(),cBean.getSomComponent());
					UtilityDAO.truncateMasterTableSom(conn,cBean.getTableName(),cBean.getSomComponent());
					insertToMasterTable(conn);
					DBUtil.commitTransaction(conn);
				}
				
				else {
					logger.logp(Level.ALL, this.getClass().getName(), "utility()","Column Mismatch--Cannot copy to table");
				}
			} catch (Exception e) {
				e.printStackTrace();
				logger.logp(Level.ALL, this.getClass().getName(), "utility()", "Exception caught while DB manipulation "+e);
				
				DBUtil.rollbackTransaction(conn);
				
				try {
					SendEmail.sendExceptionToDevTeam(e,cBean.getFileName());
				} catch (Exception e1) {
					e1.printStackTrace();
					logger.logp(Level.ALL, this.getClass().getName(), "utility()", "Exception caught while SendEmail "+e1);
				}
				
			} finally {
				
				DBUtil.closeConnection(conn);
			}
		
	}

	/**
	 * @param conn
	 * @throws FileNotFoundException
	 * @throws SQLException
	 */
	public void insertToMasterTable(Connection conn) throws FileNotFoundException, SQLException {
		filename =folderName+cBean.getFileName()+cBean.getFileExt();//permanent filename
		PreparedStatement pstmt = null;
		String insertQuery = "Insert into UVERSE_SOM (NEW_CHANGE_DEPLOYMENT_DATE, STATUS, NOTES, OFFER_ID, PROMOTION_CODE, " +
				"COMPONENT, PRODUCTS_AND_PLANS, BASE_OFFER_ID,GRANDFATHER_VERSIONS, RC_OC_PROMO, PROMO_TYPE, PROMO_BILL_DISPLAY, " +
				"MYATT_DISPLAY, PROMOTION_AMOUNT,MONTHS_DISCOUNT_APPLIED, MED_AND_LONG_DESC, " +
				"PROMO_EXP_DATE_BILL_DISPLAY, GROUP_RULE_ASSIGNED, " +
				"QUOTA_ASSIGNED, CONTRACT_ETF, PROMO_EXEMPTION, CUSTOMER_SUBTYPE, SOM_GEO, OMS_DISPLAY, " +
				"SALE_START_DATE, SALE_END_DATE, " +
				"RANKINGS, PROMO_ACTION_TYPE, PREMIUM_TIERS, PROMO_CTR, PAPERLESS_PROMO_TYPE," +
				"DISP_MONTH_BEFORE_EXP,FLEXIBLE_PRICING)" +
				" VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

		pstmt = conn.prepareStatement(insertQuery);
		HeaderColumnNameTranslateMappingStrategy<SomBean> headerColumnNameMappingStrategy =null;
		headerColumnNameMappingStrategy = new HeaderColumnNameTranslateMappingStrategy<SomBean>();
		headerColumnNameMappingStrategy.setType(SomBean.class);

		CSVReader csvReader = new CSVReader(new FileReader(filename),'\t');
		CsvToBean<SomBean> csv = new CsvToBean<SomBean>();
		HashMap<String, String> columnMapping = new HashMap<String, String>();
		columnMapping=cUtil.getCsvColMap();
		headerColumnNameMappingStrategy.setColumnMapping(columnMapping);
		
		List<SomBean> list = csv.parse(headerColumnNameMappingStrategy, csvReader);
				
		for (Object object : list) {
			SomBean somBean = (SomBean) object;		
				pstmt.setString(1,somBean.getNewChangeDeploymentDate());
				pstmt.setString(2,somBean.getStatus());
				pstmt.setString(3,somBean.getNotes());
				pstmt.setString(4,somBean.getOfferId());
				pstmt.setString(5,somBean.getPromotionCode());
				pstmt.setString(6,somBean.getComponent());
				pstmt.setString(7,somBean.getProductsAndPlans());			
				pstmt.setString(8,somBean.getBaseOfferId());
				pstmt.setString(9,somBean.getGrandfatherVersions());
				pstmt.setString(10,somBean.getRcOCPromo());
				pstmt.setString(11,somBean.getPromoType());
				pstmt.setString(12,somBean.getPromotionBillDisplay());
				pstmt.setString(13,somBean.getMyattComDisplay());
				pstmt.setString(14,somBean.getPromotionAmount());
				pstmt.setString(15,somBean.getMonthsDiscountApplied());
				pstmt.setString(16,somBean.getMedAndLongDesc());
				pstmt.setString(17,somBean.getPromoExpirationDateBillDisplay());
				pstmt.setString(18,somBean.getGroupRuleAssigned());
				pstmt.setString(19,somBean.getQuotaAssigned());
				pstmt.setString(20,somBean.getContractETF());
				pstmt.setString(21,somBean.getPromoExemption());
				pstmt.setString(22,somBean.getCustomerSubtype());
				pstmt.setString(23,somBean.getSomGeo());
				pstmt.setString(24,somBean.getOmsDisplay());
				pstmt.setString(25,somBean.getSaleStartDate());
				pstmt.setString(26,somBean.getSaleEndDate());
				pstmt.setString(27,somBean.getRankings());
				pstmt.setString(28,somBean.getPromoActionType());
				pstmt.setString(29, somBean.getPremium_Tiers());
				pstmt.setString(30,somBean.getPromoCtr());
				pstmt.setString(31,somBean.getPaperlessPromoType());
				pstmt.setString(32,somBean.getDisplayMonthsBeforeExpiration());
				pstmt.setString(33,somBean.getFlexiblePricing());
						
			pstmt.addBatch();
		}
		
		pstmt.executeBatch();
		if(pstmt!=null)
		{
			pstmt.close();
		}
		logger.logp(Level.ALL, this.getClass().getName(), "insertToMasterTable()","Successfully from csv to master table");
	}
		
}// end of utility class
