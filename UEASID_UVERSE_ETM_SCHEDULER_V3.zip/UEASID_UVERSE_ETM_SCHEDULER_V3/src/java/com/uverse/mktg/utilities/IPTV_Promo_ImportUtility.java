package com.uverse.mktg.utilities;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.naming.NamingException;

import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.bean.CsvToBean;
import au.com.bytecode.opencsv.bean.HeaderColumnNameTranslateMappingStrategy;

import com.att.savvion.logger.UBMLogger;
import com.savvion.custom.framework.util.DBUtil;
import com.uverse.mktg.bean.ConfigBean;
import com.uverse.mktg.bean.PromoBean;
import com.uverse.mktg.constants.SharepointConstants;
import com.uverse.mktg.dao.UtilityDAO;
import com.uverse.mktg.util.CommonUtility;

/**
 * @author sm802k
 *
 */
public class IPTV_Promo_ImportUtility {
	
	private static String folderName = SharepointConstants.LOCALFOLDERNAME+"/";
	//static String filename="C:\\Users\\lj7014\\Downloads\\DTV_SOM_PROMO_RPT.tsv";
	private static String etmFileName="IPTV_PROMO_SO_REPORT";
	private String filename ="";
	//private static java.util.logging.Logger logger = UBMLogger.self().getLogger(Constants.UVERSE_LOGGER_NAME);
	private CommonUtility cUtil=new CommonUtility(etmFileName,folderName);
	private ConfigBean cBean=null;
	private Map<String,ConfigBean> configData=new HashMap<String,ConfigBean>();
	/**
	 * @param args
	 * @throws IOException
	 * @throws SQLException
	 */

	private static Logger logger = UBMLogger.self().getLogger(SharepointConstants.ETM_IMPORT_LOGGER_NAME);
	/**
	 * @param args
	 * @throws IOException
	 * @throws SQLException
	 * @throws NamingException
	 */
	public static void main(String[] args) throws IOException, SQLException, NamingException {

		IPTV_Promo_ImportUtility iptv_Promo_ImportUtility = new IPTV_Promo_ImportUtility();
		iptv_Promo_ImportUtility.utility();

	}// end of main method

	/**
	 * @throws SQLException
	 * @throws NamingException
	 */
	public void utility() throws SQLException, NamingException {

		logger.logp(Level.ALL, this.getClass().getName(), "utility()","Enter into IPTV_PROMO_ImportUtility");
		    
			Boolean match = false;
			Connection conn = DBUtil.getConnection();
			try {
				conn.setAutoCommit(false);
				
				
			} catch (SQLException e2) {
				// TODO Auto-generated catch block
				logger.logp(Level.ALL, this.getClass().getName(), "utility()", "Exception caught while utility "+e2);
				e2.printStackTrace();
			}
			try {
				match =cUtil.checkForMatchingColumns(conn);
				configData= cUtil.getConfigData();
				cBean=(ConfigBean) configData.get(etmFileName);
				logger.logp(Level.ALL, this.getClass().getName(), "utility()","TableName"+cBean.getTableName());
				logger.logp(Level.ALL, this.getClass().getName(), "utility()","BkpTableName"+cBean.getBkpTableName());
				logger.logp(Level.ALL, this.getClass().getName(), "utility()","SomComponent"+cBean.getPromoComponent());
				if (match) {
					UtilityDAO.truncateBackupTablePromo(conn,cBean.getBkpTableName(),cBean.getPromoComponent());
					UtilityDAO.copyFromMasterToBackupPromo(conn,cBean.getBkpTableName(),cBean.getTableName(),cBean.getPromoComponent());
					UtilityDAO.truncateMasterTablePromo(conn,cBean.getTableName(),cBean.getPromoComponent());
					/*UtilityDAO.truncateBackupTable(conn,cBean.getBkpTableName());
					UtilityDAO.copyFromMasterToBackup(conn,cBean.getBkpTableName(),cBean.getTableName());
					UtilityDAO.truncateMasterTable(conn,cBean.getTableName());*/
					insertToMasterTable(conn);
					DBUtil.commitTransaction(conn);
				}
				
				else {
					logger.logp(Level.ALL, this.getClass().getName(), "utility()","Column Mismatch--Cannot copy to table");
				}
			} catch (Exception e) {
				e.printStackTrace();
				logger.logp(Level.ALL, this.getClass().getName(), "utility()", "Exception caught while DB manipulation "+e);
				
				DBUtil.rollbackTransaction(conn);
				
				try {
					SendEmail.sendExceptionToDevTeam(e,cBean.getFileName());
				} catch (Exception e1) {
					e1.printStackTrace();
					logger.logp(Level.ALL, this.getClass().getName(), "utility()", "Exception caught while SendEmail "+e1);
				}
				
			} finally {
				
				DBUtil.closeConnection(conn);
			}
		
	}

	/**
	 * @param conn
	 * @throws FileNotFoundException
	 * @throws SQLException
	 */
	public void insertToMasterTable(Connection conn) throws FileNotFoundException, SQLException {
		filename =folderName+cBean.getFileName()+cBean.getFileExt();//permanent filename
		PreparedStatement pstmt = null;
		String insertQuery = "Insert into UVERSE_PROMO_SO (STATUS,DEPLOYMENT_DATE,NOTES,SALES_OFFER_ID," +
				"SALES_OFFER_NAME,SALES_OFFER_DESCRIPTION," + 
		"OFFER_ID,CATEGORY,LOB,TYPE,PRIORITY,DISPOSITION,SECTION,SO_GROUP,SEND_TO_ADE,ADE_NAME," +
		"MAIN_PERMUTATION_ID,CALL_INTENT_1,CALL_INTENT_2,"+
		"START_DATE,END_DATE,FILTER_KEY,LOCAL_ID,SALES_CHANNEL,TRANSPORT_TYPE_GROUP,SWITCH_ON_OFF," +
		"IS_NEW_COMP,IS_PREMIUM,CREDIT_RISK,TEAM_SKILLS,"+
		"SECURITY_PROFILE,DEALER_GROUP,MSC,IS_NEW_SERVICE,GEOCODE,ZIP_CODE_EXCLUSION,PROMOTION_CODE,CREDIT_BAND," +
		"TREATMENT_CODE,PARTNER_NAME,CUSTOMER_SUBTYPE,PROMO_CTR)" +
		" VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

		pstmt = conn.prepareStatement(insertQuery);
		HeaderColumnNameTranslateMappingStrategy<PromoBean> headerColumnNameMappingStrategy =null;
		headerColumnNameMappingStrategy = new HeaderColumnNameTranslateMappingStrategy<PromoBean>();
		headerColumnNameMappingStrategy.setType(PromoBean.class);

		CSVReader csvReader = new CSVReader(new FileReader(filename),'\t');
		CsvToBean<PromoBean> csv = new CsvToBean<PromoBean>();
		HashMap<String, String> columnMapping = new HashMap<String, String>();
		columnMapping=cUtil.getCsvColMap();
		headerColumnNameMappingStrategy.setColumnMapping(columnMapping);
		
		List<PromoBean> list = csv.parse(headerColumnNameMappingStrategy, csvReader);
		String tmp=null;
		int count = 1;		
		for (Object object : list) {
			PromoBean promoBean = (PromoBean) object;		
			pstmt.setString(1,promoBean.getStatus());
			pstmt.setString(2,promoBean.getDeploymentDate());
			pstmt.setString(3,promoBean.getNotes());
			pstmt.setString(4,promoBean.getSalesOfferId());
			pstmt.setString(5,promoBean.getSalesOfferName());
			pstmt.setString(6,promoBean.getSalesOfferDescription());
			pstmt.setString(7,promoBean.getOfferId());
			pstmt.setString(8,promoBean.getCategory());
			pstmt.setString(9,promoBean.getLob());
			pstmt.setString(10,promoBean.getType());
			pstmt.setString(11,promoBean.getPriority());
			pstmt.setString(12,promoBean.getDisposition());
			pstmt.setString(13,promoBean.getSection());
			pstmt.setString(14,promoBean.getSoGroup());
			pstmt.setString(15,promoBean.getSendToADE());
			pstmt.setString(16,promoBean.getAdeName());
			pstmt.setString(17,promoBean.getMainPermutationId());
			pstmt.setString(18,promoBean.getCallIntent1());
			pstmt.setString(19,promoBean.getCallIntent2());
			pstmt.setString(20,promoBean.getStartDate());
			pstmt.setString(21,promoBean.getEndDate());
			pstmt.setString(22,promoBean.getFilterKey());
			pstmt.setString(23,promoBean.getLocalId());
			pstmt.setString(24,promoBean.getSalesChannel());
			pstmt.setString(25,promoBean.getTransportTypeGroup());
			pstmt.setString(26,promoBean.getSwitchOnOff());
			pstmt.setString(27,promoBean.getIsNewComp());
			pstmt.setString(28,promoBean.getIsPremium());
			pstmt.setString(29,promoBean.getCreditRisk());
			pstmt.setString(30,promoBean.getTeamSkills());
			pstmt.setString(31,promoBean.getSecurityProfile());
			pstmt.setString(32,promoBean.getDealerGroup());
			pstmt.setString(33,promoBean.getMsc());
			pstmt.setString(34,promoBean.getIsNewService());
			pstmt.setString(35,promoBean.getGeoCode());
			pstmt.setString(36,promoBean.getZipCodeExclusion());
			pstmt.setString(37,promoBean.getPromotionCode());
			pstmt.setString(38,promoBean.getCreditBand());
			pstmt.setString(39,promoBean.getTreatmentCode());
			pstmt.setString(40,promoBean.getPartnerName());
			pstmt.setString(41,promoBean.getCustomerSubtype());
			if(promoBean.getSalesOfferId() != null && promoBean.getSalesOfferId().equals(tmp))
			{
				pstmt.setInt(42,count+1);
				count++;
			}
			else {
				pstmt.setInt(42,promoBean.getPromoCtr());
				count=1;
			}
			tmp=promoBean.getSalesOfferId();		
			pstmt.addBatch();
		}
		
		pstmt.executeBatch();
		if(pstmt!=null)
		{
			pstmt.close();
		}
		logger.logp(Level.ALL, this.getClass().getName(), "insertToMasterTable()","Successfully data from csv to master table");
	}
		
}
