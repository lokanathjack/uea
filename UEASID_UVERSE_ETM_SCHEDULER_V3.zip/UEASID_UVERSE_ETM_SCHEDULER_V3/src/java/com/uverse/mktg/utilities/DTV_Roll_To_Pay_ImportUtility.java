package com.uverse.mktg.utilities;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.naming.NamingException;

import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.bean.CsvToBean;
import au.com.bytecode.opencsv.bean.HeaderColumnNameTranslateMappingStrategy;

import com.att.savvion.logger.UBMLogger;
import com.savvion.custom.framework.util.DBUtil;
import com.uverse.mktg.bean.ConfigBean;
import com.uverse.mktg.bean.DTVRollToPayBean;
import com.uverse.mktg.constants.SharepointConstants;
import com.uverse.mktg.dao.UtilityDAO;
import com.uverse.mktg.util.CommonUtility;

public class DTV_Roll_To_Pay_ImportUtility {

	private static String folderName = SharepointConstants.LOCALFOLDERNAME+"/";
	private static String etmFileName="DTV_ROLL_TYPE_DISCLOSURES";
	private String filename ="";
	private CommonUtility cUtil=new CommonUtility(etmFileName,folderName);
	private ConfigBean cBean=null;
	private Map<String,ConfigBean> configData=new HashMap<String,ConfigBean>();
	private static Logger logger = UBMLogger.self().getLogger(SharepointConstants.ETM_IMPORT_LOGGER_NAME);	
	/**
	 * @param args
	 * @throws IOException
	 * @throws SQLException
	 * @throws NamingException
	 */
	public static void main(String[] args) throws IOException, SQLException, NamingException {

		DTV_Roll_To_Pay_ImportUtility dtv_rolltopay_importutility = new DTV_Roll_To_Pay_ImportUtility();
		dtv_rolltopay_importutility.utility();

	}

	/**
	 * @throws SQLException
	 * @throws NamingException
	 */
	public void utility() throws SQLException, NamingException {
		logger.logp(Level.ALL, this.getClass().getName(), "utility()","Enter into DTV_Roll_To_Pay_ImportUtility");
		Boolean match = false;
		Connection conn = DBUtil.getConnection();
		try {
			conn.setAutoCommit(false);
		}catch (SQLException e2) {
			logger.logp(Level.ALL, this.getClass().getName(), "utility()", "Exception caught while utility "+e2);
			e2.printStackTrace();
		}
		try {
			match =cUtil.checkForMatchingColumns(conn);
			configData= cUtil.getConfigData();
			cBean=(ConfigBean) configData.get(etmFileName);
			logger.logp(Level.ALL, this.getClass().getName(), "utility()","TableName"+cBean.getTableName());
			logger.logp(Level.ALL, this.getClass().getName(), "utility()","BkpTableName"+cBean.getBkpTableName());
			logger.logp(Level.ALL, this.getClass().getName(), "utility()","SomComponent"+cBean.getSomComponent());
			if (match) {
				UtilityDAO.truncateBackupTable(conn,cBean.getBkpTableName());
				UtilityDAO.copyFromMasterToBackup(conn,cBean.getBkpTableName(),cBean.getTableName());
				UtilityDAO.truncateMasterTable(conn,cBean.getTableName());
				insertToMasterTable(conn);
				DBUtil.commitTransaction(conn);
			}
			else {
				logger.logp(Level.ALL, this.getClass().getName(), "utility()","Column Mismatch--Cannot copy to table");
			}
		}catch (Exception e) {
			e.printStackTrace();
			logger.logp(Level.ALL, this.getClass().getName(), "utility()", "Exception caught while DB manipulation "+e);
			DBUtil.rollbackTransaction(conn);
			
			try {
				SendEmail.sendExceptionToDevTeam(e,cBean.getFileName());
			} catch (Exception e1) {
				e1.printStackTrace();
				logger.logp(Level.ALL, this.getClass().getName(), "utility()", "Exception caught while SendEmail "+e1);
			}
			
		}finally {
			DBUtil.closeConnection(conn);
		}
		
	}

	public void insertToMasterTable(Connection conn) throws FileNotFoundException, SQLException {
		filename =folderName+cBean.getFileName()+cBean.getFileExt();//permanent filename
		PreparedStatement pstmt = null;
		String insertQuery = "Insert into UVERSE_DTV_ROLL_TO_PAY (STATUS, NEW_CHANGE_DEPLOYMENT_DATE, " +
				"PROMO_CODE, OFFER_ID, OFFER_NAME, " +
				"ROLL_TYPE, SHORT_MESSAGE_ID, SHORT_MESSAGE_TEXT,LONG_MESSAGE_ID, LONG_MESSAGE_TEXT, " +
				"PFD_MESSAGE_ID, PFD_MESSAGE_TEXT)" +
				" VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";

		pstmt = conn.prepareStatement(insertQuery);
		HeaderColumnNameTranslateMappingStrategy<DTVRollToPayBean> headerColumnNameMappingStrategy =null;
		headerColumnNameMappingStrategy = new HeaderColumnNameTranslateMappingStrategy<DTVRollToPayBean>();
		headerColumnNameMappingStrategy.setType(DTVRollToPayBean.class);

		CSVReader csvReader = new CSVReader(new FileReader(filename),'\t');
		CsvToBean<DTVRollToPayBean> csv = new CsvToBean<DTVRollToPayBean>();
		HashMap<String, String> columnMapping = new HashMap<String, String>();
		columnMapping=cUtil.getCsvColMap();
		headerColumnNameMappingStrategy.setColumnMapping(columnMapping);
		
		List<DTVRollToPayBean> list = csv.parse(headerColumnNameMappingStrategy, csvReader);
						
		for (Object object : list) {
			DTVRollToPayBean dtvRollToPayBean = (DTVRollToPayBean) object;		
				pstmt.setString(1,dtvRollToPayBean.getStatus());
				pstmt.setString(2,dtvRollToPayBean.getNewChangeDeploymentDate());
				pstmt.setString(3,dtvRollToPayBean.getPromoCode());
				pstmt.setString(4,dtvRollToPayBean.getOfferId());
				pstmt.setString(5,dtvRollToPayBean.getOfferName());
				pstmt.setString(6,dtvRollToPayBean.getRollType());
				pstmt.setString(7,dtvRollToPayBean.getShortMessageId());			
				pstmt.setString(8,dtvRollToPayBean.getShortMessageText());
				pstmt.setString(9,dtvRollToPayBean.getLongMessageId());
				pstmt.setString(10,dtvRollToPayBean.getLongMessageText());
				pstmt.setString(11,dtvRollToPayBean.getPfdMessageId());
				pstmt.setString(12,dtvRollToPayBean.getPfdMessageText());
			pstmt.addBatch();
		}
		
		pstmt.executeBatch();
		if(pstmt!=null)
			pstmt.close();
		logger.logp(Level.ALL, this.getClass().getName(), "insertToMasterTable()","Successfully data from csv to master table");
	}
		
}
