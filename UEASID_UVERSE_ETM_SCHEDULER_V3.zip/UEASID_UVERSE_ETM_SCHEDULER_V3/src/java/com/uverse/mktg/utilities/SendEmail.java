package com.uverse.mktg.utilities;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import com.att.savvion.common.util.PropertyReader;
import com.att.savvion.logger.UBMLogger;
import com.att.uverse.email.EmailConstants;
import com.uverse.mktg.constants.SharepointConstants;
import com.savvion.custom.framework.util.DBUtil;
import com.savvion.sbm.bizlogic.server.ejb.BLServer;
import com.savvion.sbm.bizlogic.server.ejb.BLServerHome;
import com.savvion.ejb.bizlogic.manager.BizLogicManager;
import com.savvion.ejb.bizlogic.manager.BizLogicManagerHome;
import com.savvion.sbm.bizlogic.server.svo.DocumentDS;


/**
 * Auto-generated
 */
public class SendEmail {

	
	private static Logger logger = UBMLogger.self().getLogger(SharepointConstants.ETM_IMPORT_LOGGER_NAME);
	//this method is to be called in the first step- call sendMail method
	/**
	 * @throws Exception
	 */
	@SuppressWarnings("all")
	public void perform() throws Exception
	{
		PreparedStatement psmt = null;
		ResultSet rs = null;
		Connection con=null;
		try
		{
		logger.logp(Level.ALL, this.getClass().getName(), "perform()","Enter into send mail perform method::::");
		con = DBUtil.getConnection();
		
		StringBuilder sbSuccess = new StringBuilder();
		StringBuilder sbFail = new StringBuilder();
		
		//Class.forName("oracle.jdbc.driver.OracleDriver");
		//P1SAV1D1.EDC.CINGULAR.NET:1524:P1UEAS", "ap317d", "February2015"
		//con = DriverManager.getConnection("jdbc:oracle:thin:@d1sav1d1.edc.cingular.net:1524:d1ueas", "ebms5", "ebms");
		
		
		//System.out.println("send mail");
		String sql="select distinct ETM_FILENAME,CSV_COLUMN_NAME,DB_COLUMN_NAME,to_char(max(SYS_DATE),'MM/DD/YYYY HH24:MI:SS')" +
				",import_status from UVERSE_UTILITY_REPORT where trunc(sys_date) = trunc(sysdate) group by " +
				"ETM_FILENAME,CSV_COLUMN_NAME,DB_COLUMN_NAME,import_status";
		psmt = con.prepareStatement(sql);
		rs = psmt.executeQuery();
		
		
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy H:mm:ss");
		//MM:dd:yyyy H:mm:ss
		sbSuccess.append("Hello All, <BR><BR> The following ETM files were imported successfully for ");
		sbSuccess.append (sdf.format(new Date()) + ". <BR><BR>");
		
		sbFail.append("Hello All, <BR><BR> The following ETM files were not imported successfully for ");
		sbFail.append (sdf.format(new Date()) + ". <BR><BR>");
		int successCount=0;
		int failureCount=0;
		
		if (rs.next())
		{
		sbSuccess.append("<table border=\"1\">");
		sbSuccess.append("<tr>");
		sbSuccess.append("<th> ETM File Name </th>");
		sbSuccess.append("<th> ETM File Date and Time </th>");
		sbSuccess.append("</tr>");
		
		sbFail.append("<table border=\"1\">");
		sbFail.append("<tr>");
		sbFail.append("<th> ETM File Name </th>");
		sbFail.append("<th> Import Issue </th>");
		sbFail.append("<th> ETM File Date and Time </th>");
		sbFail.append("</tr>");
		
				do
				{
					
					if(rs.getString(5).equals("Successful"))
					{
					sbSuccess.append("<tr>");
					sbSuccess.append("<td> " + rs.getString(1) + " </td>");
					sbSuccess.append("<td> " + rs.getString(4) + " </td>");
					sbSuccess.append("</tr>");
					successCount++;
					}
					else
					{
						sbFail.append("<tr>");
						sbFail.append("<td> " + rs.getString(1) + " </td>");
						// if else to avoid printing null in email
						if(rs.getString(2)==null){
						sbFail.append("<td> " + " " + rs.getString(3) + " </td>");
						}
						else if(rs.getString(3)==null){
							sbFail.append("<td> " + rs.getString(2) + " " + " </td>");
						}
						else{
							sbFail.append("<td> " + rs.getString(2) + " " + rs.getString(3) + " </td>");	
						}
						sbFail.append("<td> " + rs.getString(4) + " </td>");
						sbFail.append("</tr>");
						failureCount++;
					}
				}while(rs.next());
				sbSuccess.append("</table>");
				sbFail.append("</table>");
		}
		
		sbFail.append("<BR><BR> The UBM Development team is investigating the import issue to determine the root cause.");
		sbFail.append("A notification providing an explanation will be forwarded once a resolution is determined.");
		logger.logp(Level.ALL, this.getClass().getName(), "perform()",sbSuccess.toString());
		logger.logp(Level.ALL, this.getClass().getName(), "perform()",sbFail.toString());
		
		
		try 
		{
			
			
			StringBuilder sbSubjectSuccess = new StringBuilder("ETM Import Successful - " + sdf.format(new Date()));
			StringBuilder sbSubjectFail = new StringBuilder("ETM Import Unsuccessful - " + sdf.format(new Date()));
			if(successCount>0)
			{
				logger.logp(Level.ALL, this.getClass().getName(), "perform()","inside success if " + successCount);
				sendMail(sbSubjectSuccess, sbSuccess, con);
			}	
			if(failureCount>0)
			{
				logger.logp(Level.ALL, this.getClass().getName(), "perform()","inside failure if " + failureCount);
			    sendMail(sbSubjectFail, sbFail, con);
			} 
		}catch (Exception e)
		{
			logger.logp(Level.ALL, this.getClass().getName(), "perform()", "(sbSubject, sb);<<>>Exception = " + e);
		}
		
		
		}
	catch (Exception e)
		{
		logger.logp(Level.ALL, this.getClass().getName(), "perform()", "Exception = " + e);
			e.printStackTrace();
			throw e;
		}
		
	finally{
		DBUtil.close(rs, psmt, con);
	}
	
	}
	//this method adds emailIds- calls send method
	//needs to be called at the end of perform()
	/**
	 * @param subject
	 * @param body
	 * @param con
	 * @throws Exception
	 */
	 @SuppressWarnings("all")
	public static void sendMail (StringBuilder subject, StringBuilder body, Connection con) throws Exception
	{
		List<String> emailIds;
		emailIds = new Vector<String>();
		PreparedStatement psmt = null;
		ResultSet rs =null;
		try {
			
			String sqlEmailIds = "select EMAIL_ID from UVERSE_EMAIL_NOTIFY where ACTIVITY_ID='uverseutilityreport'";
			
			psmt = con.prepareStatement(sqlEmailIds);
			rs = psmt.executeQuery();
			if(rs.next())
			{
				String [] emailId = rs.getString(1).split(",");
				for (String id : emailId) 
				{
					emailIds.add(id);
				}
			}
		} catch (Exception e) {
			logger.logp(Level.ALL, SendEmail.class.getSimpleName(), "sendMail()", "ImportUtility<<>>sendMail<<>>Exception = " + e);
		}
		finally{
			DBUtil.close(rs, psmt);
		}
		send (emailIds, subject.toString(), body.toString());
	}
	
	//main method that sends- it needs to be called at the end of sendMail()
	/**
	 * @param emailIdList
	 * @param subject
	 * @param body
	 * @throws Exception
	 */
	 @SuppressWarnings("all")
	public static void send (List<String> emailIdList, String subject, String body) throws Exception
	{
		try {
		Properties props = new Properties();
		props.setProperty("mail.transport.protocol", "smtp");
		props.setProperty("mail.host", PropertyReader.getProperty("sbmemail.properties", "sbm.email.outgoing.server"));

		boolean debug = false;
		debug = PropertyReader.getPropertyBoolean("sbmemail.properties", "bizlogic.email.session.debug");
		javax.mail.Session mailSession = javax.mail.Session.getDefaultInstance(props, null);
		mailSession.setDebug(debug);
		
			String from = PropertyReader.getProperty("sbmemail.properties", "bizlogic.email.id");

			MimeMessage message = new MimeMessage(mailSession);
			message.setFrom(new InternetAddress(from));
			message.addRecipient(Message.RecipientType.BCC, new InternetAddress(from));

			message.setSubject(subject);
			message.setContent(body, "text/html"); 

			if (emailIdList != null && emailIdList.size() > 0)
			{
				for (String toEmailId : emailIdList) {
					message.addRecipient(Message.RecipientType.TO, new InternetAddress(toEmailId));
				}
			}
			else
			{
				//logger.error("EmailHelper.send() To cannot be empty.");
				return;
			}
			
			Transport.send(message);
		} 
		catch (Exception e) 
		{
				logger.logp(Level.ALL, SendEmail.class.getName(), "send()", "Exception send mail"+e);
				throw e;
		}

	}

	/**
	 * @param ex
	 * @param etmFile
	 * @throws Exception
	 */
	public static void sendExceptionToDevTeam(Exception ex,String etmFile) throws MessagingException
	{
		
		logger.logp(Level.ALL, SendEmail.class.getSimpleName(),"sendExceptionToDevTeam()","sendExceptionToDevTeam");
		
		SimpleDateFormat sdf =new SimpleDateFormat("MM/dd/yyyy");
		String subject = "Error in ETM Scheduler application on " + sdf.format(new Date());

		String note = "NOTE: This email was automatically generated by the application - ETM Scheduler" +
		" and sent when the "+etmFile+" File failed to download and import";
		
		StringBuilder sbBody = new StringBuilder();
		
		sbBody.append(note);
		sbBody.append("<br /><br />");

		sbBody.append("Error Message: " + ex.getMessage() + "<br /><br />");
		
		StackTraceElement ste[] = null;
		
		if (ex.getCause() != null)
		{
			sbBody.append(ex.getCause().getMessage() + "<br />");
			ste = ex.getCause().getStackTrace();
		}
		else
		{
			ste = ex.getStackTrace();
		}

		for (StackTraceElement stackTraceElement : ste) {
			sbBody.append(stackTraceElement.toString() + "<br />");
		}
		sbBody.append("<br /><br />");
		
		Properties Properties = new Properties();
		Properties.put("mail.smtp.host", PropertyReader.getProperty(EmailConstants.SBM_EMAIL, "sbm.email.outgoing.server"));
		Session session = Session.getDefaultInstance(Properties, null);
		MimeMessage mimeMessage = new MimeMessage(session);

		InternetAddress addressFrom = new InternetAddress(PropertyReader.getProperty(EmailConstants.SBM_EMAIL, "bizlogic.email.id"));
		mimeMessage.setFrom(addressFrom);
		//mimeMessage.setRecipients(Message.RecipientType.TO, "DL-SAVVION-DEV@att.com");
		mimeMessage.setRecipients(Message.RecipientType.TO, "ks532r@att.com");
		/*mimeMessage.setRecipients(Message.RecipientType.TO, "ap317d@att.com");
		mimeMessage.setRecipients(Message.RecipientType.TO, "as582h@att.com");*/
		//mimeMessage.setRecipients(Message.RecipientType.TO, "ayushi.b.agrawal@accenture.com");
		/*mimeMessage.setRecipients(Message.RecipientType.TO, "sg178q@att.com");
		mimeMessage.setRecipients(Message.RecipientType.TO, "vs252n@att.com");*/
		mimeMessage.setSubject(subject);
		mimeMessage.setContent(sbBody.toString(), "text/html");

		Transport.send(mimeMessage);
		
		logger.logp(Level.ALL, SendEmail.class.getSimpleName(),"sendExceptionToDevTeam()","exit sendExceptionToDevTeam()");
	}
	
	private java.util.ArrayList successList;

	public java.util.ArrayList getSuccessList() {
		return this.successList;
	}


	public void setSuccessList(java.util.ArrayList successList) {
		this.successList = successList;
	}


	


	/**
	 * @param processInstanceName
	 * @param workstepName
	 * @param bizLogicHost
	 */
	public void PAKcallerID(String processInstanceName, String workstepName,
			java.util.Properties bizLogicHost) {
	}

	private java.util.Map fileListhm;
	public java.util.Map getFileListhm() {
		return this.fileListhm;
	}
	public void setFileListhm(java.util.Map fileListhm) {
		this.fileListhm = fileListhm;
	}
	
	
	
}
