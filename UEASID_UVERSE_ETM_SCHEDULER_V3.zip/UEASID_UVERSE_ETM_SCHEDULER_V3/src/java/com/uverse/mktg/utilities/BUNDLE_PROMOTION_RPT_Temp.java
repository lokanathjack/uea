package com.uverse.mktg.utilities;


import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import javax.naming.NamingException;

import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.bean.CsvToBean;
import au.com.bytecode.opencsv.bean.HeaderColumnNameTranslateMappingStrategy;

import com.att.savvion.logger.Constants;
import com.att.savvion.logger.UBMLogger;

import com.uverse.mktg.bean.BundlePromoBean;
import com.uverse.mktg.bean.ConfigBean;
import com.uverse.mktg.constants.SharepointConstants;
import com.savvion.custom.framework.util.DBUtil;
import com.uverse.mktg.dao.UtilityDAO;
import com.uverse.mktg.util.CommonUtility;

/**
 * Auto-generated
 */
public class BUNDLE_PROMOTION_RPT_Temp {
	
	//static String filename = "C:\\BUNDLE_PROMOTION_RPT.csv";
	private String filename="";
	private static String folderName = SharepointConstants.LOCALFOLDERNAME+"/";
	private static String etmFileName = "BUNDLE_PROMOTION_RPT";
	private static java.util.logging.Logger logger = UBMLogger.self().getLogger(Constants.UVERSE_LOGGER_NAME);
	private CommonUtility cUtil=new CommonUtility(etmFileName,folderName);
	private ConfigBean cBean=null;
	private Map<String,ConfigBean> configData=new HashMap<String,ConfigBean>();
	/**
	 * @param args
	 * @throws IOException
	 * @throws SQLException
	 */

	
	/**
	 * @param args
	 * @throws IOException
	 * @throws SQLException
	 * @throws NamingException
	 */
	public static void main(String[] args) throws IOException, SQLException, NamingException {

		BUNDLE_PROMOTION_RPT_Temp bundlePromo_ImportUtility = new BUNDLE_PROMOTION_RPT_Temp();
		bundlePromo_ImportUtility.utility();

	}// end of main method
	
	/**
	 * @throws SQLException
	 * @throws NamingException
	 */
	public void utility() throws SQLException, NamingException {
		
		logger.info("enter into BUNDLE_PROMOTION_RPT_Temp Utility method");
		
		Boolean match = false;
		
		Connection conn = DBUtil.getConnection();
		
		try {
			conn.setAutoCommit(false);
			
			
		} catch (SQLException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
			logger.info("Exception::::"+e2);
			
		}
		try {
			match =cUtil.checkForMatchingColumns(conn);
			configData= cUtil.getConfigData();
			cBean=(ConfigBean) configData.get(etmFileName);
			logger.info("TableName"+cBean.getTableName());
			logger.info("BkpTableName"+cBean.getBkpTableName());
			if (match) {
				UtilityDAO.truncateBackupTable(conn,cBean.getBkpTableName());
				UtilityDAO.copyFromMasterToBackup(conn,cBean.getBkpTableName(),cBean.getTableName());
				UtilityDAO.truncateMasterTable(conn,cBean.getTableName());
				insertToMasterTable(conn);
				DBUtil.commitTransaction(conn);
			}
			else {
				logger.info("Column Mismatch--Cannot copy to table");
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Exception ::::"+e);
			
			DBUtil.rollbackTransaction(conn);
			
			
			try {
				
				SendEmail.sendExceptionToDevTeam(e,cBean.getFileName());
				logger.info("after sendExceptionToDevTeam ");
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				logger.info("Enter into BUNDLE_PROMOTION_RPT_Temp utility method exception::"+e1);
			}
			
		} finally {
			DBUtil.closeConnection(conn);
		}
	}



/**
 * @param conn
 * @throws FileNotFoundException
 * @throws SQLException
 */
public void insertToMasterTable(Connection conn) throws FileNotFoundException, SQLException {
	filename =folderName+cBean.getFileName()+cBean.getFileExt();//permanent filename
String sqlCopyFromCsvToMaster = "INSERT INTO UVERSE_BUNDLE_PROMO (NEW_CHANGE_DEPLOYMENT_DATE,STATUS,NOTES,OFFER_ID,"
	+ "PROMO_CODE,COMPONENT,BASE_OFFER_DESCRIPTION,BASE_OFFER_ID,PROMO_TYPE,BUNDLE_IDS,PROMO_BILL_DISPLAY," +
			"OMS_DISPLAY,MED_AND_LONG_DESC,"
	+ "PROMO_EXP_DATE_BILL_DISPLAY,PROMOTION_AMOUNT,MONTHS_DISCOUNT_APPLIED,PROMO_CTR) "
	+ "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

PreparedStatement pstmt = null;
pstmt = conn.prepareStatement(sqlCopyFromCsvToMaster);

HeaderColumnNameTranslateMappingStrategy<BundlePromoBean> headerColumnNameMappingStrategy = new HeaderColumnNameTranslateMappingStrategy<BundlePromoBean>();
headerColumnNameMappingStrategy.setType(BundlePromoBean.class);
//headerColumnNameMappingStrategy is used for mapping csv file data to bean class
CSVReader csvReader = new CSVReader(new FileReader(filename),'\t');
CsvToBean<BundlePromoBean> csv = new CsvToBean<BundlePromoBean>();
HashMap<String, String> columnMapping = new HashMap<String, String>();

columnMapping = cUtil.getCsvColMap();
headerColumnNameMappingStrategy.setColumnMapping(columnMapping);

List<BundlePromoBean> list = csv.parse(
		headerColumnNameMappingStrategy, csvReader);
int i = 0;

//for (int j = 0; j < 1; j++) {
	
	//GroupAttributesBean groupAttributesBean = (GroupAttributesBean) list.get(j);
	
	
		
for (Object object : list) {
	BundlePromoBean bundlePromoBean = (BundlePromoBean) object;

	/*logger.info("Row Number : "+i
			  +" >> "+bundlePromoBean.getNewChangeDeploymentDate());
	logger.info("Row Number : "+i +" >> "+bundlePromoBean.getStatus());
	logger.info("Row Number : "+i
			  +" >> "+bundlePromoBean.getNotes());
	logger.info("Row Number : "+i
			  +" >> "+bundlePromoBean.getOfferId());
	logger.info("Row Number : "+i
			  +" >> "+bundlePromoBean.getPromoCode());
	logger.info("Row Number : "+i
			  +" >> "+bundlePromoBean.getComponent());
	logger.info("Row Number : "+i
			  +" >> "+bundlePromoBean.getBaseOfferDescription());
	logger.info("Row Number : "+i
			  +" >> "+bundlePromoBean.getBaseOfferId());
	logger.info("Row Number : "+i
			  +" >> "+bundlePromoBean.getPromoType());
	logger.info("Row Number : "+i
			  +" >> "+bundlePromoBean.getBundleIds());
	logger.info("Row Number : "+i
			  +" >> "+bundlePromoBean.getPromoBillDisplay());
	logger.info("Row Number : "+i
			  +" >> "+bundlePromoBean.getOmsDisplay());
	logger.info("Row Number : "+i
			  +" >> "+bundlePromoBean.getMedAndLongDesc());
	logger.info("Row Number : "+i
			  +" >> "+bundlePromoBean.getPromoExpDateBillDisplay());
	logger.info("Row Number : "+i
			  +" >> "+bundlePromoBean.getPromotionAmount());
	logger.info("Row Number : "+i +" >> "+bundlePromoBean.getMonthsDiscountApplied());
	logger.info("Row Number : "+i
			  +" >> "+bundlePromoBean.getPromoCtr());
			  */
	
	pstmt.setString(1, bundlePromoBean.getNewChangeDeploymentDate());
	pstmt.setString(2, bundlePromoBean.getStatus());
	pstmt.setString(3, bundlePromoBean.getNotes());
	pstmt.setString(4, bundlePromoBean.getOfferId());
	pstmt.setString(5, bundlePromoBean.getPromoCode());
	pstmt.setString(6, bundlePromoBean.getComponent());
	pstmt.setString(7, bundlePromoBean.getBaseOfferDescription());
	pstmt.setString(8, bundlePromoBean.getBaseOfferId());
	pstmt.setString(9, bundlePromoBean.getPromoType());
	pstmt.setString(10, bundlePromoBean.getBundleIds());
	pstmt.setString(11, bundlePromoBean.getPromoBillDisplay());
	pstmt.setString(12, bundlePromoBean.getOmsDisplay());
	pstmt.setString(13, bundlePromoBean.getMedAndLongDesc());
	pstmt.setString(14, bundlePromoBean.getPromoExpDateBillDisplay());
	pstmt.setString(15, bundlePromoBean.getPromotionAmount());
	pstmt.setString(16, bundlePromoBean.getMonthsDiscountApplied());
	pstmt.setString(17, bundlePromoBean.getPromoCtr());

	pstmt.addBatch();
	 i++;
	
}
pstmt.executeBatch();
if(pstmt!=null)
{
	pstmt.close();
}
logger.info("Copy from csv to master table");
}
	
	/**
	 * @param processInstanceName
	 * @param workstepName
	 * @param bizLogicHost
	 */
	public void PAKcallerID(String processInstanceName, String workstepName,
			java.util.Properties bizLogicHost) {
	}

	@SuppressWarnings("all")
	private java.util.Vector fileList;
	@SuppressWarnings("all")
	public java.util.Vector getFileList() {
		return this.fileList;
	}
	@SuppressWarnings("all")
	public void setFileList(java.util.Vector fileList) {
		this.fileList = fileList;
	}

	private long loopctr;
	public long getLoopctr() {
		return this.loopctr;
	}

	public void setLoopctr(long loopctr) {
		this.loopctr = loopctr;
	}
}