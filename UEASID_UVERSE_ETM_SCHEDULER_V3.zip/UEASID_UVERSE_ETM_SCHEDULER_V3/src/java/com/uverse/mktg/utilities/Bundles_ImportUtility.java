package com.uverse.mktg.utilities;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import java.sql.SQLException;

import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.bean.CsvToBean;
import au.com.bytecode.opencsv.bean.HeaderColumnNameTranslateMappingStrategy;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.naming.NamingException;

import com.att.savvion.logger.UBMLogger;
import com.uverse.mktg.bean.BundlesBean;
import com.uverse.mktg.bean.ConfigBean;

import com.uverse.mktg.constants.SharepointConstants;

import com.savvion.custom.framework.util.DBUtil;
import com.uverse.mktg.dao.UtilityDAO;
import com.uverse.mktg.util.CommonUtility;

/**
 * @author sm802k
 *
 */
public class Bundles_ImportUtility {
	private static String folderName = SharepointConstants.LOCALFOLDERNAME+"/";
	private static String etmFileName = "BUNDLE_MATRIX_RPT";
	private String filename =""; 
	//static String filename = "C:\\BUNDLE_MATRIX_RPT.csv";
	private static Logger logger = UBMLogger.self().getLogger(SharepointConstants.ETM_IMPORT_LOGGER_NAME);
	private CommonUtility cUtil=new CommonUtility(etmFileName,folderName);
	private ConfigBean cBean=null;
	private Map<String,ConfigBean> configData=new HashMap<String,ConfigBean>();
	/**
	 * @param args
	 * @throws IOException
	 * @throws SQLException
	 */

	
	/**
	 * @param args
	 * @throws IOException
	 * @throws SQLException
	 * @throws NamingException
	 */
	public static void main(String[] args) throws IOException, SQLException, NamingException{

		Bundles_ImportUtility bundles_ImportUtility = new Bundles_ImportUtility();
		bundles_ImportUtility.utility();

	}// end of main method

	/**
	 * @throws SQLException
	 * @throws NamingException
	 */
	public void utility() throws SQLException, NamingException {

		logger.logp(Level.ALL, this.getClass().getName(), "utility()","Enter into Bundles_ImportUtility::::");
			Boolean match = false;
			Connection conn = DBUtil.getConnection();
			try {
				conn.setAutoCommit(false);
				
				
			} catch (SQLException e2) {
				e2.printStackTrace();
				logger.logp(Level.ALL, this.getClass().getName(), "utility()", "Exception caught while utility "+e2);
			}
			try {
				match =cUtil.checkForMatchingColumns(conn);
				configData= cUtil.getConfigData();
				cBean=(ConfigBean) configData.get(etmFileName);
				logger.logp(Level.ALL, this.getClass().getName(), "utility()","TableName"+cBean.getTableName());
				logger.logp(Level.ALL, this.getClass().getName(), "utility()","BkpTableName"+cBean.getBkpTableName());
				if (match) {
					
					UtilityDAO.truncateBackupTable(conn,cBean.getBkpTableName());
					UtilityDAO.copyFromMasterToBackup(conn,cBean.getBkpTableName(),cBean.getTableName());
					UtilityDAO.truncateMasterTable(conn,cBean.getTableName());
					insertToMasterTable(conn);
					DBUtil.commitTransaction(conn);
				}
				else {
					logger.logp(Level.ALL, this.getClass().getName(), "utility()","Column Mismatch--Cannot copy to table");
				}
			} catch (Exception e) {
				e.printStackTrace();
				logger.logp(Level.ALL, this.getClass().getName(), "utility()", "Exception caught while DB manipulation "+e);
				
				DBUtil.rollbackTransaction(conn);
				

				try {
					SendEmail.sendExceptionToDevTeam(e,cBean.getFileName());
				} catch (Exception e1) {
					e1.printStackTrace();
					logger.logp(Level.ALL, this.getClass().getName(), "utility()", "Exception caught while SendEmail "+e1);
				}
				
			} finally {
				DBUtil.closeConnection(conn);
			}
		
	}

	
	

	
	public void insertToMasterTable(Connection conn) throws FileNotFoundException, SQLException {
		filename =folderName+cBean.getFileName()+cBean.getFileExt();//permanent filename
		String sqlCopyFromCsvToMaster = "INSERT INTO UVERSE_BUNDLES (NEW_CHANGE_DEPLOYMENT_DATE,STATUS,NOTES,BUNDLE_PACKAGE_ID," +
				"ASSOCIATED_PROMO_OFFER_ID,ASSOCIATED_PROMO_CODE"
			+ ",BASE_OFFER_ID,BASE_OFFER_DESCRIPTION,REQUIRED_PRODUCTS,PACKAGES_PLANS,CUSTOMER_SUBTYPE,GEO,SALES_CHANNEL," +
					"PROFILE_DEFAULT_TEAM,GLOBAL_ROLE,"
			+ "MOBILITY_BUSINESS_CHANNEL,SECURTY_PROFILE,EXISTING_DSL_LEGACY_IND,EXISTING_TELCO_LEGACY_IND,BUNDLE_DESCRIPTION," +
					"CPP_RANKING,START_DATE,END_DATE,"
			+ "BUNDLE_ORDER_ACTION_TYPE,CPP_DURATION,ASSIGN_TO_GROUP_RULE,QUOTA_DEFINED,TITAN_INDICATOR,TRANSPORT_TYPE," +
					"BUNDLE_REPLACEABILITY_IND,PRICE_GUARANTEE,CONTRACT_TERM,ETF_BASED_ON_UVERSE,"
			+ "ETF_STATIC_AMOUNT,CORE_PRODUCT_ADDED_NEW,CORE_PRODUCT_EXISTING,OPTIONAL_CORE_UVERSE_UPGR,RETERM_MOBILITY_EQUIP_UPGR," +
					"ADD_LINE_MOBILITY,"
			+ "RETERM_EQUIP_AND_DU,RETERM_EQUIP_OR_DU,PROMOTION_SINGLE_CREDIT_DISP,SC_SHORT_BILL_DESCRIPTION," +
					"SC_SHORT_BILL_SPANISH_DESC,SC_MEDIUM_BOLD_BILL_DESC,"
			+ "SC_LONG_BILL_DESC,SPANISH_MEDIUM_BOLD_DESC,SPANISH_LONG_BILL_DESC,SC_CSR_MOBILITY_ONLINE,PROMO_CTR)"
			+ " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		
		PreparedStatement pstmt = null;
		pstmt = conn.prepareStatement(sqlCopyFromCsvToMaster);
		HeaderColumnNameTranslateMappingStrategy<BundlesBean> headerColumnNameMappingStrategy=null;
		headerColumnNameMappingStrategy = new HeaderColumnNameTranslateMappingStrategy<BundlesBean>();
		headerColumnNameMappingStrategy.setType(BundlesBean.class);

		CSVReader csvReader = new CSVReader(new FileReader(filename),'\t');
		CsvToBean<BundlesBean> csv = new CsvToBean<BundlesBean>();
		HashMap<String, String> columnMapping = new HashMap<String, String>();
		
		columnMapping=cUtil.getCsvColMap();
		headerColumnNameMappingStrategy.setColumnMapping(columnMapping);

		List<BundlesBean> list = csv.parse(headerColumnNameMappingStrategy, csvReader);
		int i = 0;
		
		//for (int j = 0; j < 1; j++) {
			
			//GroupAttributesBean groupAttributesBean = (GroupAttributesBean) list.get(j);
			
			System.out.println(list.size());
				
		for (Object object : list) {
			BundlesBean bundlesBean = (BundlesBean) object;

			         /* debug("Row Number : "+i+" >> "+bundlesBean.getNewChangeDeploymentDate());
					  debug("Row Number : "+i +" >> "+bundlesBean.getStatus());
					  debug("Row Number : "+i+" >> "+bundlesBean.getNotes());
					  debug("Row Number : "+i+" >> "+bundlesBean.getBundlePackageId()); 
					  debug("Row Number : "+i+" >> "+bundlesBean.getAssociatedPromoofferId());
					  debug("Row Number : "+i+" >> "+bundlesBean.getAssociatedpromocode());
					  debug("Row Number : "+i+" >> "+bundlesBean.getBaseOfferId());
					  debug("Row Number : "+i+" >> "+bundlesBean.getBaseOfferDescription());
					  debug("Row Number : "+i+" >> "+bundlesBean.getRequiredProducts());
					  debug("Row Number : "+i+" >> "+bundlesBean.getPackagePlan());
					  debug("Row Number : "+i+" >> "+bundlesBean.getCustomerSubtype());
					  debug("Row Number : "+i+" >> "+bundlesBean.getGeo());
					  debug("Row Number : "+i+" >> "+bundlesBean.getSalesChannel());
					  debug("Row Number : "+i+" >> "+bundlesBean.getProfileDefaulTeam());
					  debug("Row Number : "+i+" >> "+bundlesBean.getGlobalRole());
					  debug("Row Number : "+i+" >> "+bundlesBean.getMobilityBusinessChannel());
					  debug("Row Number : "+i+" >> "+bundlesBean.getSecurtyProfile());
					  debug("Row Number : "+i+" >> "+bundlesBean.getExistingDslLegacyInd());
					  debug("Row Number : "+i+" >> "+bundlesBean.getExistingTelcoLegacyInd());
					  debug("Row Number : "+i+" >> "+bundlesBean.getBundleDescription());
                      debug("Row Number : "+i+" >> "+bundlesBean.getCppRanking());
					  debug("Row Number : "+i+" >> "+bundlesBean.getStartDate());
					  debug("Row Number : "+i+" >> "+bundlesBean.getEndDate());
					  debug("Row Number : "+i+" >> "+bundlesBean.getBundleOrderActionType());
					  debug("Row Number : "+i+" >> "+bundlesBean.getCppDuration());
					  debug("Row Number : "+i+" >> "+bundlesBean.getAssignToGroupRule());
					  debug("Row Number : "+i+" >> "+bundlesBean.getQuotaDefined());
					  debug("Row Number : "+i+" >> "+bundlesBean.getTitanIndicator());
					  debug("Row Number : "+i+" >> "+bundlesBean.getTransportType());
					  debug("Row Number : "+i+" >> "+bundlesBean.getBundleReplaceabilityInd());
					  debug("Row Number : "+i+" >> "+bundlesBean.getPriceGuarantee());
					  debug("Row Number : "+i+" >> "+bundlesBean.getContractTerm());
					  debug("Row Number : "+i+" >> "+bundlesBean.getEtfBasedOnUverse());
					  debug("Row Number : "+i+" >> "+bundlesBean.getEtfStaticAmount());
					  debug("Row Number : "+i+" >> "+bundlesBean.getCoreProductAddedNew());
					  debug("Row Number : "+i+" >> "+bundlesBean.getCoreProductExisting());
					  debug("Row Number : "+i+" >> "+bundlesBean.getOptionalCoreUverseUpgr());
					  debug("Row Number : "+i+" >> "+bundlesBean.getRetermMobilityEquipUpgr());
					  debug("Row Number : "+i+" >> "+bundlesBean.getAddLineMobility());
					  debug("Row Number : "+i+" >> "+bundlesBean.getRetermEquipAndDu());
					  debug("Row Number : "+i+" >> "+bundlesBean.getRetermEquipOrDu());
					  debug("Row Number : "+i+" >> "+bundlesBean.getPromotionSingleCreditDisp());
					  debug("Row Number : "+i+" >> "+bundlesBean.getScShortBillDescription());
					  debug("Row Number : "+i+" >> "+bundlesBean.getScShortBillSpanishDesc());
					  debug("Row Number : "+i+" >> "+bundlesBean.getScMediumBoldBillDesc());
					  debug("Row Number : "+i+" >> "+bundlesBean.getScLongBillDesc());
					  debug("Row Number : "+i+" >> "+bundlesBean.getSpanishMediumBoldDesc());
					  debug("Row Number : "+i+" >> "+bundlesBean.getSpanishLongBillDesc());
					  debug("Row Number : "+i+" >> "+bundlesBean.getScCsrMobilityOnline());
					  debug("Row Number : "+i+" >> "+bundlesBean.getPromoCtr());*/
					  
			pstmt.setString(1, bundlesBean.getNewChangeDeploymentDate());
			pstmt.setString(2, bundlesBean.getStatus());
			pstmt.setString(3, bundlesBean.getNotes());
			pstmt.setString(4, bundlesBean.getBundlePackageId());
			pstmt.setString(5, bundlesBean.getAssociatedPromoofferId());
			pstmt.setString(6, bundlesBean.getAssociatedpromocode());
			pstmt.setString(7, bundlesBean.getBaseOfferId());
			pstmt.setString(8, bundlesBean.getBaseOfferDescription());
			pstmt.setString(9, bundlesBean.getRequiredProducts());
			pstmt.setString(10, bundlesBean.getPackagesPlans());
			pstmt.setString(11, bundlesBean.getCustomerSubtype());
			pstmt.setString(12, bundlesBean.getGeo());
			pstmt.setString(13, bundlesBean.getSalesChannel());
			pstmt.setString(14, bundlesBean.getProfileDefaulTeam());
			pstmt.setString(15, bundlesBean.getGlobalRole());
			pstmt.setString(16, bundlesBean.getMobilityBusinessChannel());
			pstmt.setString(17, bundlesBean.getSecurtyProfile());
			pstmt.setString(18, bundlesBean.getExistingDslLegacyInd());
			pstmt.setString(19, bundlesBean.getExistingTelcoLegacyInd());
			pstmt.setString(20, bundlesBean.getBundleDescription());
			pstmt.setString(21, bundlesBean.getCppRanking());
			pstmt.setString(22, bundlesBean.getStartDate());
			pstmt.setString(23, bundlesBean.getEndDate());
			pstmt.setString(24, bundlesBean.getBundleOrderActionType());
			pstmt.setString(25, bundlesBean.getCppDuration());
			pstmt.setString(26, bundlesBean.getAssignToGroupRule());
			pstmt.setString(27, bundlesBean.getQuotaDefined());
			pstmt.setString(28, bundlesBean.getTitanIndicator());
			pstmt.setString(29, bundlesBean.getTransportType());
			pstmt.setString(30, bundlesBean.getBundleReplaceabilityInd());
			pstmt.setString(31, bundlesBean.getPriceGuarantee());
			pstmt.setString(32, bundlesBean.getContractTerm());
			pstmt.setString(33, bundlesBean.getEtfBasedOnUverse());
			pstmt.setString(34, bundlesBean.getEtfStaticAmount());
			pstmt.setString(35, bundlesBean.getCoreProductAddedNew());
			pstmt.setString(36, bundlesBean.getCoreProductExisting());
			pstmt.setString(37, bundlesBean.getOptionalCoreUverseUpgr());
			pstmt.setString(38, bundlesBean.getRetermMobilityEquipUpgr());
			pstmt.setString(39, bundlesBean.getAddLineMobility());
			pstmt.setString(40, bundlesBean.getRetermEquipAndDu());
			pstmt.setString(41, bundlesBean.getRetermEquipOrDu());
			pstmt.setString(42, bundlesBean.getPromotionSingleCreditDisp());
			pstmt.setString(43, bundlesBean.getScShortBillDescription());
			pstmt.setString(44, bundlesBean.getScShortBillSpanishDesc());
			pstmt.setString(45, bundlesBean.getScMediumBoldBillDesc());
			pstmt.setString(46, bundlesBean.getScLongBillDesc());
			pstmt.setString(47, bundlesBean.getSpanishMediumBoldDesc());
			pstmt.setString(48, bundlesBean.getSpanishLongBillDesc());
			pstmt.setString(49, bundlesBean.getScCsrMobilityOnline());
			pstmt.setString(50, bundlesBean.getPromoCtr());
			pstmt.addBatch();
			//System.out.println(sqlCopyFromCsvToMaster);
			//pstmt.executeUpdate();
			 i++;
					}
		
		//System.out.println("ENDDDDDDDDDDDDDDDDDDDDDDDD");
		pstmt.executeBatch();
		//pstmt.close();
		if(pstmt!=null)
		{
			pstmt.close();
		}
		logger.logp(Level.ALL, this.getClass().getName(), "insertToMasterTable()","Copy from csv to master table");
	}
	
}
