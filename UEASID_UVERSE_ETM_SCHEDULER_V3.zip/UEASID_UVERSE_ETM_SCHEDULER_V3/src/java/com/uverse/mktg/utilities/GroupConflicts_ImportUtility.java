package com.uverse.mktg.utilities;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import java.sql.SQLException;

import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.bean.CsvToBean;
import au.com.bytecode.opencsv.bean.HeaderColumnNameTranslateMappingStrategy;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;

import javax.naming.NamingException;

import com.att.savvion.logger.UBMLogger;
import com.uverse.mktg.bean.ConfigBean;
import com.uverse.mktg.bean.GroupConflictBean;
import com.uverse.mktg.constants.SharepointConstants;
import com.savvion.custom.framework.util.DBUtil;
import com.uverse.mktg.dao.UtilityDAO;
import com.uverse.mktg.util.CommonUtility;
import java.util.logging.Logger;



/**
 * @author sm802k
 *
 */
public class GroupConflicts_ImportUtility {
	//static String filename = "C:\\TBGROUP_LIMITATION_GLOB_RPTS.csv";
	private static String folderName = SharepointConstants.LOCALFOLDERNAME+"/";
	private static String etmFileName = "TBGROUP_LIMITATION_GLOB_RPTS";
	private String filename ="";
	private static Logger logger = UBMLogger.self().getLogger(SharepointConstants.ETM_IMPORT_LOGGER_NAME);
	private CommonUtility cUtil=new CommonUtility(etmFileName,folderName);
	private ConfigBean cBean=null;
	private Map<String,ConfigBean> configData=new HashMap<String,ConfigBean>();
	/**
	 * @param args
	 * @throws IOException
	 * @throws SQLException
	 */


	
	/**
	 * @param args
	 * @throws IOException
	 * @throws SQLException
	 * @throws NamingException
	 */
	public static void main(String[] args) throws IOException, SQLException, NamingException {

		GroupConflicts_ImportUtility groupConflicts_ImportUtility = new GroupConflicts_ImportUtility();
		groupConflicts_ImportUtility.utility();

	}// end of main method

	/**
	 * @throws SQLException
	 * @throws NamingException
	 */
	public void utility() throws SQLException, NamingException {

		logger.logp(Level.ALL, this.getClass().getName(), "utility()","Enter into GroupConflicts_ImportUtility::::::::");
			Boolean match = false;
			Connection conn = DBUtil.getConnection();
			try {
				conn.setAutoCommit(false);
				
				
			} catch (SQLException e2) {
				logger.logp(Level.ALL, this.getClass().getName(), "utility()", "Exception caught while utility "+e2);
				e2.printStackTrace();
			}
			try {
				match =cUtil.checkForMatchingColumns(conn);
				configData= cUtil.getConfigData();
				cBean=(ConfigBean) configData.get(etmFileName);
				logger.logp(Level.ALL, this.getClass().getName(), "utility()","TableName"+cBean.getTableName());
				logger.logp(Level.ALL, this.getClass().getName(), "utility()","BkpTableName"+cBean.getBkpTableName());
				if (match) {
					
					UtilityDAO.truncateBackupTable(conn,cBean.getBkpTableName());
					UtilityDAO.copyFromMasterToBackup(conn,cBean.getBkpTableName(),cBean.getTableName());
					UtilityDAO.truncateMasterTable(conn,cBean.getTableName());
					insertToMasterTable(conn);
					DBUtil.commitTransaction(conn);
				}
				else {
					logger.logp(Level.ALL, this.getClass().getName(), "utility()","Column Mismatch--Cannot copy to table");
				}
			} catch (Exception e) {
				e.printStackTrace();
				logger.logp(Level.ALL, this.getClass().getName(), "utility()", "Exception caught while DB manipulation "+e);
				
				DBUtil.rollbackTransaction(conn);
				

				try {
					SendEmail.sendExceptionToDevTeam(e,cBean.getFileName());
				} catch (Exception e1) {
					e1.printStackTrace();
					logger.logp(Level.ALL, this.getClass().getName(), "utility()", "Exception caught while SendEmail "+e1);
				}
				
			} finally {
				DBUtil.closeConnection(conn);
			}
		
	}



	/**
	 * @param conn
	 * @throws FileNotFoundException
	 * @throws SQLException
	 */
	public void insertToMasterTable(Connection conn) throws FileNotFoundException, SQLException {
		
		filename =folderName+cBean.getFileName()+cBean.getFileExt();//permanent filename
		PreparedStatement pstmt = null;
		String insertQuery = "Insert into UVERSE_GROUPCONFLICTRULES (GLOBAL_STATUS, RULE_ID, " +
				"QUALIFYING_GROUP, RESTRICTED_GROUP, MIN_NO_QUAL_GROUP, QUAL_GROUP_HISTORY, " +
				"MIN_DURATION, MAX_DURATION, EFFECTIVE_DATE, EXPIRATION_DATE, CONTRACT_OBLIGATION, " +
				"CHECK_ORDER, QUALIFYING_ENTITY, IMPACTED_ENTITY, STATUS, DEPLOY_DATE, CREATION_DATE, " +
				"LAST_IMPORT_DATE_TIME, LAST_IMPORTED_BY, ROW_ACTION_CODE, WORK_EFFORT_NAME, ENVIRONMENT_SOURCE," +
				"QUALIFYING_GROUP_EXCEPTION,IMPACTED_GROUP_EXCEPTION) VALUES " +
				"(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

		pstmt = conn.prepareStatement(insertQuery);
		HeaderColumnNameTranslateMappingStrategy<GroupConflictBean> headerColumnNameMappingStrategy =null;
		headerColumnNameMappingStrategy = new HeaderColumnNameTranslateMappingStrategy<GroupConflictBean>();
		headerColumnNameMappingStrategy.setType(GroupConflictBean.class);

		CSVReader csvReader = new CSVReader(new FileReader(filename));
		CsvToBean<GroupConflictBean> csv = new CsvToBean<GroupConflictBean>();
		HashMap<String, String> columnMapping = new HashMap<String, String>();
		
		columnMapping=cUtil.getCsvColMap();
		headerColumnNameMappingStrategy.setColumnMapping(columnMapping);

		List<GroupConflictBean> list = csv.parse(headerColumnNameMappingStrategy, csvReader);
				
		for (Object object : list) {
			GroupConflictBean groupDefinitionBean = (GroupConflictBean) object;		
		
			pstmt.setString(1,groupDefinitionBean.getGlobalStatus());
			pstmt.setString(2,groupDefinitionBean.getRuleID());
			pstmt.setString(3,groupDefinitionBean.getQualifyingGroup());
			pstmt.setString(4,groupDefinitionBean.getRestrictedGroup());
			pstmt.setString(5,groupDefinitionBean.getMinNofromQualGroup());
			pstmt.setString(6,groupDefinitionBean.getQualGroupHistory());
			pstmt.setString(7,groupDefinitionBean.getMinDuration());
			pstmt.setString(8,groupDefinitionBean.getMaxDuration());
			pstmt.setString(9,groupDefinitionBean.getEffectiveDate());
			pstmt.setString(10,groupDefinitionBean.getExpirationDate());
			pstmt.setString(11,groupDefinitionBean.getContractObligation());
			pstmt.setString(12,groupDefinitionBean.getCheckOrder());
			pstmt.setString(13,groupDefinitionBean.getQualifyingEntity());
			pstmt.setString(14,groupDefinitionBean.getImpactedEntity());
			pstmt.setString(15,groupDefinitionBean.getStatus());
			pstmt.setString(16,groupDefinitionBean.getDeployDate());
			pstmt.setString(17,groupDefinitionBean.getCreationDate());
			pstmt.setString(18,groupDefinitionBean.getLastImportDateTime());
			pstmt.setString(19,groupDefinitionBean.getLastImportedBy());
			pstmt.setString(20,groupDefinitionBean.getRowActionCode());
			pstmt.setString(21,groupDefinitionBean.getWorkEffortName());
			pstmt.setString(22,groupDefinitionBean.getEnvironmentSource());
			pstmt.setString(23, groupDefinitionBean.getQualifyingGroupException());
			pstmt.setString(24, groupDefinitionBean.getImpactedGroupException());
						
			pstmt.addBatch();
		}
		
		pstmt.executeBatch();
		if(pstmt!=null)
		{
			pstmt.close();
		}
		logger.logp(Level.ALL, this.getClass().getName(), "insertToMasterTable()","Copy from csv to master table");
	}
	
}// end of utility class
