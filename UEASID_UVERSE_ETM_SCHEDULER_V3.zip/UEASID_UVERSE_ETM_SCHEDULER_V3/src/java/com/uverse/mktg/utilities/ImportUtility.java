package com.uverse.mktg.utilities;


import java.lang.reflect.Method;
import java.util.logging.Level;

import com.att.savvion.logger.UBMLogger;
import com.uverse.mktg.constants.SharepointConstants;
import java.util.logging.Logger;
import com.savvion.sbm.bizlogic.server.ejb.BLServer;
import com.savvion.sbm.bizlogic.server.ejb.BLServerHome;
import com.savvion.ejb.bizlogic.manager.BizLogicManager;
import com.savvion.ejb.bizlogic.manager.BizLogicManagerHome;
import com.savvion.sbm.bizlogic.server.svo.DocumentDS;

/**
 * Auto-generated
 */
public class ImportUtility{
	@SuppressWarnings("all")
	private java.util.Vector fileList;
	private long loopctr;
	private static Logger logger = UBMLogger.self().getLogger(SharepointConstants.ETM_IMPORT_LOGGER_NAME);
	@SuppressWarnings("all")
	public java.util.Vector getFileList() {
		return this.fileList;
	}

	public long getLoopctr() {
		return this.loopctr;
	}
	@SuppressWarnings("all")
	public void setFileList(java.util.Vector fileList) {
		this.fileList = fileList;
	}

	public void setLoopctr(long loopctr) {
		this.loopctr = loopctr;
	}

	public void utility() {
		logger.logp(Level.ALL, this.getClass().getName(), "utility()","File name" + fileList.get((int)loopctr) );
		logger.logp(Level.ALL, this.getClass().getName(), "utility()","Class file:" + (String)fileListhm.get(fileList.get((int)loopctr)));
		logger.logp(Level.ALL, this.getClass().getName(), "utility()","fileListhm :"+fileListhm);
		logger.logp(Level.ALL, this.getClass().getName(), "utility()","fileList:"+fileList);
	 String className = (String)fileListhm.get(fileList.get((int)loopctr));
	 if (className != null) {
		
		 logger.logp(Level.ALL, this.getClass().getName(), "utility()","Enetered to invoke class ::: " + className);
		try {Class<?> cls = Class.forName(className);  
		Object obj = cls.newInstance();
		logger.logp(Level.ALL, this.getClass().getName(), "utility()","END CLASS");
			
	    Method	 method =    cls.getMethod("utility");	
		method.invoke(obj);	
			} catch (Exception e){
				logger.logp(Level.ALL, this.getClass().getName(), "utility()", "Exception caught while utility "+e);
			}
			
	 }
	}
	
	/**
	 * @param processInstanceName
	 * @param workstepName
	 * @param bizLogicHost
	 */
	public void PAKcallerID(String processInstanceName, String workstepName,
			java.util.Properties bizLogicHost) {
	}

	private java.util.Map fileListhm;

	public java.util.Map getFileListhm() {
		return this.fileListhm;
	}

	public void setFileListhm(java.util.Map fileListhm) {
		this.fileListhm = fileListhm;
	}
}