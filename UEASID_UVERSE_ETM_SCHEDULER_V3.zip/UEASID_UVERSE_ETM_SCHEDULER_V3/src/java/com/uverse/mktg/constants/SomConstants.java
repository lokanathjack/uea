package com.uverse.mktg.constants;

public class SomConstants {

	public static final String UTILITY_TABLENAME = "UVERSE_SOM";
	public static final String UTILITY_TABLENAME_BKP = "UVERSE_SOM_BKP";
	public static final String ETM_FILENAME_RG = "RG_SOM_PROMO_RPT";
	public static final String ETM_FILENAME_HSIA = "HSIA_SOM_PROMO_RPT";
	public static final String ETM_FILENAME_STB = "STB_SOM_PROMO_RPT";
	public static final String ETM_FILENAME_VOIP = "VOIP_SOM_PROMO_RPT";
	public static final String ETM_FILENAME_IPTV = "IPTV_SOM_PROMO_RPT";
	
	public static final String COLUMN_IPTV = "UVERSE_SOM_IPTV";
	public static final String COLUMN_HSIA = "UVERSE_SOM_HSIA";
	public static final String COLUMN_RG = "UVERSE_SOM_RG";
	public static final String COLUMN_STB = "UVERSE_SOM_STB";
	public static final String COLUMN_VOIP = "UVERSE_SOM_VOIP";
	
	public static final String COMPONENT_RG = "RG";
	public static final String COMPONENT_HSIA = "HSIA";
	public static final String COMPONENT_STB = "STB";
	public static final String COMPONENT_VOIP = "VOIP";
	public static final String COMPONENT_IPTV = "IPTV";
	
	public static final String NEW_CHANGE_DEPLOYMENT_DATE = "New/Change Deployment Date";
	public static final String STATUS = "Status";
	public static final String NOTES = "Notes";
	public static final String OFFER_ID = "Offer Id";
	public static final String PROMOTION_CODE = "Promotion Code";
	public static final String COMPONENT = "Component";
	public static final String PRODUCTS_AND_PLANS = "Products and Plans";
	public static final String BASE_OFFER_ID = "Base Offer Id";
	public static final String GRANDFATHER_VERSIONS = "Grandfather Versions";
	public static final String RC_OC_PROMO = "RC or OC Promo";
	public static final String PROMO_TYPE = "Promo Type (Basic or Stackable)";
	public static final String PROMO_BILL_DISPLAY = "Promotion Bill Display";
	public static final String MYATT_DISPLAY = "myatt.com Display";
	public static final String PROMOTION_AMOUNT = "Promotion Amount";
	public static final String MONTHS_DISCOUNT_APPLIED = "Months Discount Applied";
	public static final String MED_AND_LONG_DESC = "Med and Long Desc (Y/N)";
	public static final String PROMO_EXP_DATE_BILL_DISPLAY = "Promo Expiration Date Bill Display";
	public static final String GROUP_RULE_ASSIGNED = "Group/Rule Assigned";
	public static final String QUOTA_ASSIGNED = "Quota Assigned";
	public static final String CONTRACT_ETF = "Contract ETF";
	public static final String PROMO_EXEMPTION = "Promo Exemption";
	public static final String CUSTOMER_SUBTYPE = "Customer Subtype";
	public static final String SOM_GEO = "SOM/GEO";
	public static final String OMS_DISPLAY = "OMS Display";
	public static final String SALE_START_DATE = "Sale Start Date";
	public static final String SALE_END_DATE = "Sale End Date";
	public static final String RANKINGS = "Rankings";
	public static final String PROMO_ACTION_TYPE = "Promo Action Type";
	public static final String PREMIUM_TIERS = "Premium Tiers";
	public static final String PAPERLESS_PROMO_TYPE = "Paperless Promotion Type";
	public static final String PROMO_CTR = "Promo ctr";
	public static final String DISPLAY_MONTHS_BEFORE_EXPIRATION = "Display Months Before Expiration";
	public static final String FLEXIBLE_PRICING = "Flexible Pricing";
	
}

													
