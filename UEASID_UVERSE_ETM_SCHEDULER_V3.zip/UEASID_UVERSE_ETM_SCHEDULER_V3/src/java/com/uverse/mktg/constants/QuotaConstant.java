package com.uverse.mktg.constants;

public class QuotaConstant {

	public static final String UTILITY_TABLENAME = "UVERSE_QUOTA";
	public static final String UTILITY_TABLENAME_BKP = "UVERSE_QUOTA_BKP";
	public static final String ETM_FILENAME = "TBQUOTA_LIMITS_GLOB_RPTS";
	
	public static final String GLOBAL_STATUS = "Global Status";
	public static final String QUOTA = "Quota ID";
	public static final String PROMO_OR_BUNDLE_ID = "Bundle Promo ID";
	public static final String OFFER_ID = "Offer ID";
	public static final String BUNDLE_PROMOTION_TYPE = "Bundle Promotion Type";
	public static final String QUOTA_LEVEL = "Quota Level";
	public static final String ENTITY = "Entity ID";
	public static final String START_DATE = "Start Date";
	public static final String END_DATE = "End Date";
	public static final String QUOTA_AMOUNT = "Quota Amount";
	public static final String DEPLOY_DATE = "Deploy Date";
	public static final String CTDB_CREATION_DATE_TIME = "CTDB Creation Date/Time";
	public static final String LAST_IMPORT_DATE_TIME = "Last Import Date/Time";
	public static final String LAST_IMPORTED_BY = "Last Imported By";
	public static final String ROW_ACTION_CODE = "Row Action Code";
	public static final String WORK_EFFORT_NAME = "Work Effort Name";
	public static final String ENVIRONMENT_SOURCE = "Environment Source";

}
