package com.uverse.mktg.constants;

/**
 * @author sm802k
 *
 */
public class SharepointConstants {
	
	public static final String LOCALFOLDERNAME = "/tmp/ETMFiles";
	public static final String TARGETURL = "https://businesssolutions.web.att.com/sites/Uverse-BPMRI/Billing%20Data%20Management/Promo%20Management%20Reports/";
	public static final String ETM_FILEEXT = ".csv";
	public static final String[] SHAREPOINT_ETM_FILES = { "TBGROUP_DEFINITION_GLOB_RPTS",
		"BUNDLE_PROMOTION_RPT",
		"VOIP_SOM_PROMO_RPT",
		"TBQUOTA_LIMITS_GLOB_RPTS",
		"STB_SOM_PROMO_RPT",
		"HSIA_SOM_PROMO_RPT",
		"TBATTRIBUTE_RULES_GLOB_RPTS",
		"TBGROUP_LIMITATION_GLOB_RPTS",
		"IPTV_SOM_PROMO_RPT",
		"RG_SOM_PROMO_RPT",
		"TBRULE_DATES_GLOB_RPTS"
		};
	/**
	 * 
	 */
	public static final String ETM_IMPORT_LOGGER_NAME = "etmimport";
}
