package com.uverse.mktg.constants;

/**
 * @author sm802k
 *
 */
public class BundlePromoConstants {
	public static final String UTILITY_TABLENAME = "UVERSE_BUNDLE_PROMO";
	public static final String UTILITY_TABLENAME_BKP = "UVERSE_BUNDLE_PROMO_BKP";
	public static final String ETM_FILENAME = "BUNDLE_PROMOTION_RPT";
	
	public static final String NEW_CHANGE_DEPLOYMENT_DATE = "New/Change Deployment Date";
	public static final String STATUS = "Status"; 
	public static final String NOTES = "Notes"; 
	public static final String OFFER_ID = "Offer Id";
	public static final String PROMO_CODE = "Promo Code"; 
	public static final String COMPONENT = "Component"; 
	public static final String BASE_OFFER_DESCRIPTION = "Base Offer Description"; 
	public static final String BASE_OFFER_ID = "Base Offer ID"; 
	public static final String PROMO_TYPE = "Promo Type"; 
	public static final String BUNDLE_IDS = "Bundle IDs"; 
	public static final String PROMO_BILL_DISPLAY = "Promotion Bill Display"; 
	public static final String OMS_DISPLAY = "OMS Display/myatt.com Display"; 
	public static final String MED_AND_LONG_DESC = "Med and Long Desc(Y/N)"; 
	public static final String PROMO_EXP_DATE_BILL_DISPLAY = "Promo Exp Date Bill Dispay (Y/N)"; 
	public static final String PROMOTION_AMOUNT = "Promotion Amount"; 
	public static final String MONTHS_DISCOUNT_APPLIED = "Months Discount Applied";  
	public static final String PROMO_CTR = "Promo ctr"; 
}
