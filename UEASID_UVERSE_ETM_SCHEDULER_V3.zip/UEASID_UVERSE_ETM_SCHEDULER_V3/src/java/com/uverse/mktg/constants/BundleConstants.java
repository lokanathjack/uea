package com.uverse.mktg.constants;

/**
 * @author sm802k
 *
 */
public class BundleConstants {
	public static final String UTILITY_TABLENAME = "UVERSE_BUNDLES";
	public static final String UTILITY_TABLENAME_BKP = "UVERSE_BUNDLES_BKP";
	public static final String ETM_FILENAME = "BUNDLE_MATRIX_RPT";
	
	public static final String NEW_CHANGE_DEPLOYMENT_DATE = "New/Change Deployment Date";
	public static final String STATUS = "Status";
	public static final String NOTES = "Notes";
	public static final String BUNDLE_PACKAGE_ID = "Bundle Package ID";
	public static final String ASSOCIATED_PROMO_OFFER_ID = "Associated Promo Offer ID";
	public static final String ASSOCIATED_PROMO_CODE = "Associated Promo Code";
	public static final String BASE_OFFER_ID = "Base Offer ID";
	public static final String BASE_OFFER_DESCRIPTION = "Base Offer Description";
	public static final String REQUIRED_PRODUCTS = "Required Products";
	public static final String PACKAGES_PLANS = "Packages/Plans";
	public static final String CUSTOMER_SUBTYPE = "Customer Subtype";
	public static final String GEO = "Geo";
	public static final String SALES_CHANNEL = "Sales Channel";
	public static final String PROFILE_DEFAULT_TEAM = "Profile, Default Team";
	public static final String GLOBAL_ROLE = "Global Role";
	public static final String MOBILITY_BUSINESS_CHANNEL = "Mobility Business Channel";
	public static final String SECURTY_PROFILE = "Security Profile";
	public static final String EXISTING_DSL_LEGACY_IND = "Existing DSL Legacy Ind";
	public static final String EXISTING_TELCO_LEGACY_IND = "Existing Telco Legacy Ind";
	public static final String BUNDLE_DESCRIPTION = "Bundle Description";
	public static final String CPP_RANKING = "CPP ranking";
	public static final String START_DATE = "Start Date";
	public static final String END_DATE = "End Date";
	public static final String BUNDLE_ORDER_ACTION_TYPE = "Bundle/Order Action Type";
	public static final String CPP_DURATION = "CPP duration";
	public static final String ASSIGN_TO_GROUP_RULE = "Assigned to Group/Rule (Y/N)";
	public static final String QUOTA_DEFINED = "Quota Defined";
	public static final String TITAN_INDICATOR = "Titan Indicator (Y/N)";
	public static final String TRANSPORT_TYPE = "Transport Type"; 
	public static final String BUNDLE_REPLACEABILITY_IND = "Bundle Replaceability ind";
	public static final String PRICE_GUARANTEE = "Price Guarantee";
	public static final String CONTRACT_TERM = "Contract Term";
	public static final String ETF_BASED_ON_UVERSE = "ETF Based on U-verse";
	public static final String ETF_STATIC_AMOUNT = "ETF Static $ Amount";
	public static final String CORE_PRODUCT_ADDED_NEW = "Core Product to be added New";
	public static final String CORE_PRODUCT_EXISTING = "Core Product existing";
	public static final String OPTIONAL_CORE_UVERSE_UPGR = "OPTIONAL Core U-verse to Upgr";
	public static final String RETERM_MOBILITY_EQUIP_UPGR = "Re-Term Mobility Equip Upgr";
	public static final String ADD_LINE_MOBILITY = "Add a Line to Mobility";
	public static final String RETERM_EQUIP_AND_DU = "Re-term with Equip Upgr and DU";
	public static final String RETERM_EQUIP_OR_DU = "Re-term with Equip Upgr or DU";
	public static final String PROMOTION_SINGLE_CREDIT_DISP = "Promotion Single Credit Disp";
	public static final String SC_SHORT_BILL_DESCRIPTION = "SC Short Bill Description";
	public static final String SC_SHORT_BILL_SPANISH_DESC = "SC Short Bill Spanish Desc";
	public static final String SC_MEDIUM_BOLD_BILL_DESC = "SC Medium BOLD Bill Desc";
	public static final String SC_LONG_BILL_DESC = "SC long Bill Desc";
    public static final String SPANISH_MEDIUM_BOLD_DESC = "Spanish Medium BOLD Bill Desc";
	public static final String SPANISH_LONG_BILL_DESC  = "Spanish long Bill Description";
	public static final String SC_CSR_MOBILITY_ONLINE = "SC CSR/Mobility/Online";
	public static final String PROMO_CTR = "Promo ctr";
	

}



