package com.uverse.mktg.constants;

/**
 * @author sm802k
 *
 */
public class GroupAttributesConstants {

	public static final String UTILITY_TABLENAME = "UVERSE_ATTRIBUTE_RULES";
	public static final String UTILITY_TABLENAME_BKP = "UVERSE_ATTRIBUTE_RULES_BKP";
	public static final String ETM_FILENAME = "TBATTRIBUTE_RULES_GLOB_RPTS";
	
	public static final String GLOBAL_STATUS = "Global Status";
	public static final String RULE_ID = "Rule ID";
	public static final String ATTRIBUTE_NAME = "Attribute Name";
	public static final String OPERATOR_VALUE = "Operator Value";
	public static final String MIN_VALUE = "Min Value";
	public static final String MAX_VALUE = "Max Value";
	public static final String MIN_DURATION = "Min Duration";
	public static final String MAX_DURATION = "Max Duration";
	public static final String START_DATE = "Start Date";
	public static final String END_DATE = "End Date";
	public static final String RESTRICT_GROUP_ID = "Restrict Group ID";
	public static final String RESTRICT_TARGET = "Restrict Target";
	public static final String RESTRICT_ORDERED = "Restrict Ordered";
	public static final String RESTRICT_EXCEPTION = "Restrict Exception";
	public static final String LEGALLY_BOUND = "Legally Bound";
	public static final String DEPLOY_DATE = "Deploy Date";
	public static final String STATUS = "Status";
	public static final String ROW_ACTION_CODE = "Row Action Code";
	public static final String LAST_IMPORT_DATE_TIME = "Last Import Date/Time";
	public static final String LAST_IMPORTED_BY = "Last Imported By";
	public static final String WORK_EFFORT_NAME = "Work Effort Name";
	public static final String ENVIRONMENT_SOURCE = "Environment Source";
	public static final String RULE_GROUP = "Rule Group";
	

	
	
}
