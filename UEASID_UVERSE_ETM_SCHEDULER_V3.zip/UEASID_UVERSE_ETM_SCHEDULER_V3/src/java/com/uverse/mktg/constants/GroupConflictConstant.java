package com.uverse.mktg.constants;

public class GroupConflictConstant {
	
	public static final String UTILITY_TABLENAME = "UVERSE_GROUPCONFLICTRULES";
	public static final String UTILITY_TABLENAME_BKP = "UVERSE_GROUPCONFLICTRULES_BKP";
	public static final String ETM_FILENAME = "TBGROUP_LIMITATION_GLOB_RPTS";
	
	public static final String GLOBAL_STATUS = "Global Status";
	public static final String RULE_ID = "Rule ID";
	public static final String QUALIFYING_GROUP = "Qualifying Group";
	public static final String RESTRICTED_GROUP = "Restricted Group";
	public static final String MIN_NO_QUAL_GROUP = "Min No from Qual Group";
	public static final String QUAL_GROUP_HISTORY = "Qual Group History";
	public static final String MIN_DURATION = "Min Duration";
	public static final String MAX_DURATION = "Max Duration";
	public static final String EFFECTIVE_DATE = "Effective Date";
	public static final String EXPIRATION_DATE = "Expiration Date";
	public static final String CONTRACT_OBLIGATION = "Contract Obligation";
	public static final String CHECK_ORDER = "Check Order";
	public static final String QUALIFYING_ENTITY = "Qualifying Entity";
	public static final String IMPACTED_ENTITY = "Impacted Entity";
	public static final String STATUS = "Status";
	public static final String DEPLOY_DATE = "Deploy Date";
	public static final String CREATION_DATE = "Creation Date";
	public static final String LAST_IMPORT_DATE_TIME = "Last Import Date/Time";
	public static final String LAST_IMPORTED_BY = "Last Imported By";
	public static final String ROW_ACTION_CODE = "Row Action Code";
	public static final String WORK_EFFORT_NAME = "Work Effort Name";
	public static final String ENVIRONMENT_SOURCE = "Environment Source";
	public static final String QUALIFYING_GROUP_EXCEPTION = "Qualifying Group Exception";
	public static final String IMPACTED_GROUP_EXCEPTION = "Impacted Group Exception";
	
	
	
	
}
