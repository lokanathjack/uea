package com.uverse.mktg.constants;

public class GroupDefinitionsConstants {
	
	public static final String UTILITY_TABLENAME = "UVERSE_GROUP_DEFINITIONS";
	public static final String UTILITY_TABLENAME_BKP = "UVERSE_GROUP_DEFINITIONS_BKP";
	public static final String ETM_FILENAME = "TBGROUP_DEFINITION_GLOB_RPTS";

	public static final String globalStatus="Global Status";
	public static final String groupId="Group ID";
	public static final String type="Type";
	public static final String promotionOrBundleId="Promotion or Bundle ID";
	public static final String offerID="Offer ID";
	public static final String rowActionCode="Row Action Code";
	public static final String deployDate="Deploy Date";
	public static final String ctdbCreationDateTime="CTDB Creation Date/Time";
	public static final String lastImportDateTime="Last Import Date/Time";
	public static final String lastImportedBy="Last Imported By";
	public static final String workEffortName="Work Effort Name";
	public static final String environmentSource="Environment Source";
	
}

