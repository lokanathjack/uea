package com.uverse.mktg.util;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import au.com.bytecode.opencsv.CSVReader;

import com.att.savvion.logger.UBMLogger;
import com.savvion.custom.framework.util.DBUtil;
import com.uverse.mktg.bean.ConfigBean;
import com.uverse.mktg.constants.SharepointConstants;

public class CommonUtility {
	private String importStatus;
	private String firstParam = null;
	private String etmFilename;
	private String folder;
	private HashMap<String,String> csvColMap=new HashMap<String, String>();
	private List<String>csvColsDB=new ArrayList<String>();
	private List<String> csvColumnList = new ArrayList<String>();
	private List<String> csvColumnListIgnore = new ArrayList<String>();
	private List<String> tableMismatchList = new ArrayList<String>();
	//new Map
	private Map<String,ConfigBean> configData=new HashMap<String,ConfigBean>();
	private String filename ="";
	private static Logger logger = UBMLogger.self().getLogger(SharepointConstants.ETM_IMPORT_LOGGER_NAME);
	private static final String fetch_Master_Data = "select K.FILE_NAME,K.MAIN_TABLE_NAME,K.BACKUP_TABLE_NAME,K.FILE_EXT,K.DELEIMETER," +
			"N.CSV_COLUMN_NAME,N.BEAN_ATTRIBUTE_NAME from" +
			" UVERSE_ETM_COLUMNS_KCP K, UVERSE_ETM_COLUMNS_NVP N where N.UVERSE_ETM_COLUMNS_KCP_ID = (select UVERSE_ETM_COLUMNS_KCP_ID from " +
			"UVERSE_ETM_COLUMNS_KCP where FILE_NAME=?) and K.UVERSE_ETM_COLUMNS_KCP_ID=N.UVERSE_ETM_COLUMNS_KCP_ID order by " +
			"UVERSE_ETM_COLUMNS_NVP_ID";
	
 /**
 * @param etmFilename
 * @param folder
 */
public CommonUtility(String etmFilename,String folder)
	{
		this.etmFilename=etmFilename;
		this.folder=folder;
	}
 
 /**
 * @param conn
 * @return
 * @throws IOException
 * @throws SQLException
 */
public boolean checkForMatchingColumns(Connection conn) throws IOException,
	SQLException {
	 //load values from master table
	 loadMasterData(conn,etmFilename);
	 logger.info("config bean::"+configData);
	 ConfigBean cBean=(ConfigBean) configData.get(etmFilename);
String[] nextLine,nextLineNew;
//filename="C:\\HSIA_SOM_PROMO_RPT.csv";
filename =folder+cBean.getFileName()+cBean.getFileExt();//permanent filename
logger.info("filename::: "+filename);
CSVReader csvReader;
CSVReader csvReaderNew;
if(cBean.getDeleimeter().trim().toString().equals("tab"))
{
csvReader = new CSVReader(new FileReader(filename),'\t');
csvReaderNew = new CSVReader(new FileReader(filename),'\t');
}
else
{

csvReader = new CSVReader(new FileReader(filename));
csvReaderNew = new CSVReader(new FileReader(filename));
}
int i = 0;
int j = 0;
//new code
int csvColsize = 0;
if((nextLine = csvReader.readNext()) != null) {
	csvColsize= nextLine.length;
}
System.out.println("csvColsize::::" + csvColsize);
//getting the csv column list value from master map
List<String>tmpcsvColsDB=cBean.getCsvColumns();
System.out.println("tmpcsvColsDB::::" + tmpcsvColsDB);
while ((nextLineNew = csvReaderNew.readNext()) != null) {
		for (j = 0; j < csvColsize; j++) {
			if (tmpcsvColsDB.contains(nextLineNew[j])) {
				csvColumnList.add(nextLineNew[j]);
			}
			else
			{
			csvColumnListIgnore.add(nextLineNew[j]);
			}
		}
	i++;
	if (i == 1)
		break;
}
logger.info("size "+tmpcsvColsDB.size()+" tmpcsvColsDB is:"+tmpcsvColsDB);
logger.info("size "+csvColumnList.size()+" csvColumnList is:"+csvColumnList);
logger.info("csvColumnListIgnore: "+csvColumnListIgnore);

//comparing CSV columns with DB configuration
tableMismatchList = createMismatchList(csvColsDB, csvColumnList);
logger.info(tableMismatchList + ":tableMismatchList");
logger.info("csvColumnList:" + csvColumnList);
logger.info("csvColumnListIgnore:" + csvColumnListIgnore);

if (tableMismatchList.size() > 0)
	importStatus="Failed"; 
else
	importStatus="Successful"; //also when csvColumnListIgnore is not null.

//To add into uverse_utility_report table
addToMismatchTable(conn, csvColumnListIgnore, tableMismatchList, importStatus,cBean);

// This if else condition is to determine whether to proceed with the insert into database or not.
if (tableMismatchList.size() > 0)
	return false;
else
	return true;

}

 private void addToMismatchTable(Connection conn,
			List<String> csvColumnListIgnore, List<String> tableMismatchList, String importStatus,ConfigBean cBean)
			throws SQLException {

	String sqlMismatchTableAdd = "INSERT INTO UVERSE_UTILITY_REPORT(TABLE_NAME,ETM_FILENAME,CSV_COLUMN_NAME,IMPORT_STATUS,SYS_DATE) " +
			"VALUES(?,?,?,?,SYSDATE)";
	logger.info("Adding to column mismatch table- UVERSE_UTILITY_REPORT to update recent column mismatch report");

	StringBuilder buffer = new StringBuilder();
	boolean processedFirst = false;
	

	try {
		for (String record : tableMismatchList) {
			if (processedFirst)
				buffer.append(",");
			buffer.append(record);
			processedFirst = true;
		}
		for (String record : csvColumnListIgnore) {
			if (processedFirst)
				buffer.append(",");
			buffer.append(record);
			processedFirst = true;
		}
		firstParam = buffer.toString();
	} finally {
		buffer = null;
	}
	
	PreparedStatement prpstmt = null;

	prpstmt = conn.prepareStatement(sqlMismatchTableAdd);
	prpstmt.setString(1, cBean.getTableName());//from DB 
	prpstmt.setString(2, cBean.getFileName());//from DB
	prpstmt.setString(3, firstParam);
	prpstmt.setString(4, importStatus);
	prpstmt.executeUpdate();
	prpstmt.close();
}
 /**
 * @param List1
 * @param List2
 * @return
 */
public List<String> createMismatchList(List<String> List1,
			List<String> List2) {
		int columnCount = List1.size();
		logger.info(columnCount+" columnCount");
		List<String> mismatchList = new ArrayList<String>();
		int x = 0;
		for (int columnIndex = 0; columnIndex < columnCount; columnIndex++)

		{
			boolean xyz = List2.contains(List1.get(columnIndex));
			{
				if (!xyz) {
					mismatchList.add(x, List1.get(columnIndex));
					x++;
				}
			}

		}

		return (mismatchList);
	}

 private void loadMasterData(Connection conn,String etmfilename) {
	 logger.info("Enter loadMasterData");
	 PreparedStatement prpstmt = null;
	 ResultSet rs = null;
		try {
			prpstmt = conn.prepareStatement(fetch_Master_Data);
			prpstmt.setString(1, etmfilename);
			rs = prpstmt.executeQuery();
			ConfigBean cfgBean=null;
			String fileName=null;
				cfgBean=new ConfigBean();
				if(rs.next()){
					fileName=rs.getString("FILE_NAME");
					if(fileName.contains("SOM"))
					{//parse FileName and fetch som Type component and store it in bean.
				cfgBean.setSomComponent(fileName.split("_")[0]);
					}
					else if(fileName.contains("PROMO")){
						cfgBean.setPromoComponent(fileName.split("_")[0]);
					}
				cfgBean.setTableName(rs.getString("MAIN_TABLE_NAME"));
				cfgBean.setBkpTableName(rs.getString("BACKUP_TABLE_NAME"));
				cfgBean.setFileName(rs.getString("FILE_NAME"));
				cfgBean.setFileExt(rs.getString("FILE_EXT"));
				cfgBean.setDeleimeter(rs.getString("DELEIMETER"));
				csvColsDB.add(rs.getString("CSV_COLUMN_NAME"));
				csvColMap.put(rs.getString("CSV_COLUMN_NAME"),rs.getString("BEAN_ATTRIBUTE_NAME"));
				}
				while(rs.next())
				{
					csvColsDB.add(rs.getString("CSV_COLUMN_NAME"));
					csvColMap.put(rs.getString("CSV_COLUMN_NAME"),rs.getString("BEAN_ATTRIBUTE_NAME"));
				}
				cfgBean.setCsvColumns(csvColsDB);
				configData.put(fileName, cfgBean);
			//}
		} catch (SQLException e) {
			logger.logp(Level.ALL, this.getClass().getName(), "loadMasterData()", "Exception caught while "+e);
		}
		finally
		{
			DBUtil.close(rs,prpstmt);
		}
		logger.info("Exit loadMasterData");
}

public HashMap<String, String> getCsvColMap() {
	return csvColMap;
}

public void setCsvColMap(HashMap<String, String> csvColMap) {
	this.csvColMap = csvColMap;
}

public Map<String, ConfigBean> getConfigData() {
	return configData;
}

public void setConfigData(Map<String, ConfigBean> configData) {
	this.configData = configData;
}

}
