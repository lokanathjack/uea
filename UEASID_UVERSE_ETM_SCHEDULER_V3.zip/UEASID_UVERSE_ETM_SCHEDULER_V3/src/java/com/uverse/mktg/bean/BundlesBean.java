package com.uverse.mktg.bean;

/**
 * @author sm802k
 *
 */
public class BundlesBean
{
	private String newChangeDeploymentDate;
	private String status;
	private String notes;
    private String bundlePackageId;
	private String associatedPromoofferId;
	private String associatedpromocode;
	private String baseOfferId;
	private String baseOfferDescription;
	private String requiredProducts;
	private String packagesPlans;
	private String customerSubtype;
	private String geo;
	private String salesChannel;
	private String profileDefaulTeam;
	private String globalRole;
	private String mobilityBusinessChannel;
	private String securtyProfile;
	private String existingDslLegacyInd;
	private String existingTelcoLegacyInd;
	private String bundleDescription;
	private String cppRanking;
	private String startDate;
	private String endDate;
	private String bundleOrderActionType;
	private String cppDuration;
	private String assignToGroupRule;
	private String quotaDefined;
	private String titanIndicator;
	private String transportType;
	private String bundleReplaceabilityInd;
	private String priceGuarantee;
	private String contractTerm;
	private String etfBasedOnUverse;
	private String etfStaticAmount;
	private String coreProductAddedNew;
	private String coreProductExisting;
	private String optionalCoreUverseUpgr;
	private String retermMobilityEquipUpgr;
	private String addLineMobility;
	private String retermEquipAndDu;
	private String retermEquipOrDu;
	private String promotionSingleCreditDisp;
	private String scShortBillDescription;
	private String scShortBillSpanishDesc;
	private String scMediumBoldBillDesc;
	private String scLongBillDesc;
    private String spanishMediumBoldDesc;
	private String spanishLongBillDesc;
	private  String scCsrMobilityOnline;
	private String promoCtr;
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((addLineMobility == null) ? 0 : addLineMobility.hashCode());
		result = prime
				* result
				+ ((assignToGroupRule == null) ? 0 : assignToGroupRule
						.hashCode());
		result = prime
				* result
				+ ((associatedPromoofferId == null) ? 0
						: associatedPromoofferId.hashCode());
		result = prime
				* result
				+ ((associatedpromocode == null) ? 0 : associatedpromocode
						.hashCode());
		result = prime
				* result
				+ ((baseOfferDescription == null) ? 0 : baseOfferDescription
						.hashCode());
		result = prime * result
				+ ((baseOfferId == null) ? 0 : baseOfferId.hashCode());
		result = prime
				* result
				+ ((bundleDescription == null) ? 0 : bundleDescription
						.hashCode());
		result = prime
				* result
				+ ((bundleOrderActionType == null) ? 0 : bundleOrderActionType
						.hashCode());
		result = prime * result
				+ ((bundlePackageId == null) ? 0 : bundlePackageId.hashCode());
		result = prime
				* result
				+ ((bundleReplaceabilityInd == null) ? 0
						: bundleReplaceabilityInd.hashCode());
		result = prime * result
				+ ((contractTerm == null) ? 0 : contractTerm.hashCode());
		result = prime
				* result
				+ ((coreProductAddedNew == null) ? 0 : coreProductAddedNew
						.hashCode());
		result = prime
				* result
				+ ((coreProductExisting == null) ? 0 : coreProductExisting
						.hashCode());
		result = prime * result
				+ ((cppDuration == null) ? 0 : cppDuration.hashCode());
		result = prime * result
				+ ((cppRanking == null) ? 0 : cppRanking.hashCode());
		result = prime * result
				+ ((customerSubtype == null) ? 0 : customerSubtype.hashCode());
		result = prime * result + ((endDate == null) ? 0 : endDate.hashCode());
		result = prime
				* result
				+ ((etfBasedOnUverse == null) ? 0 : etfBasedOnUverse.hashCode());
		result = prime * result
				+ ((etfStaticAmount == null) ? 0 : etfStaticAmount.hashCode());
		result = prime
				* result
				+ ((existingDslLegacyInd == null) ? 0 : existingDslLegacyInd
						.hashCode());
		result = prime
				* result
				+ ((existingTelcoLegacyInd == null) ? 0
						: existingTelcoLegacyInd.hashCode());
		result = prime * result + ((geo == null) ? 0 : geo.hashCode());
		result = prime * result
				+ ((globalRole == null) ? 0 : globalRole.hashCode());
		result = prime
				* result
				+ ((mobilityBusinessChannel == null) ? 0
						: mobilityBusinessChannel.hashCode());
		result = prime
				* result
				+ ((newChangeDeploymentDate == null) ? 0
						: newChangeDeploymentDate.hashCode());
		result = prime * result + ((notes == null) ? 0 : notes.hashCode());
		result = prime
				* result
				+ ((optionalCoreUverseUpgr == null) ? 0
						: optionalCoreUverseUpgr.hashCode());
		result = prime * result
				+ ((packagesPlans == null) ? 0 : packagesPlans.hashCode());
		result = prime * result
				+ ((priceGuarantee == null) ? 0 : priceGuarantee.hashCode());
		result = prime
				* result
				+ ((profileDefaulTeam == null) ? 0 : profileDefaulTeam
						.hashCode());
		result = prime * result
				+ ((promoCtr == null) ? 0 : promoCtr.hashCode());
		result = prime
				* result
				+ ((promotionSingleCreditDisp == null) ? 0
						: promotionSingleCreditDisp.hashCode());
		result = prime * result
				+ ((quotaDefined == null) ? 0 : quotaDefined.hashCode());
		result = prime
				* result
				+ ((requiredProducts == null) ? 0 : requiredProducts.hashCode());
		result = prime
				* result
				+ ((retermEquipAndDu == null) ? 0 : retermEquipAndDu.hashCode());
		result = prime * result
				+ ((retermEquipOrDu == null) ? 0 : retermEquipOrDu.hashCode());
		result = prime
				* result
				+ ((retermMobilityEquipUpgr == null) ? 0
						: retermMobilityEquipUpgr.hashCode());
		result = prime * result
				+ ((salesChannel == null) ? 0 : salesChannel.hashCode());
		result = prime
				* result
				+ ((scCsrMobilityOnline == null) ? 0 : scCsrMobilityOnline
						.hashCode());
		result = prime * result
				+ ((scLongBillDesc == null) ? 0 : scLongBillDesc.hashCode());
		result = prime
				* result
				+ ((scMediumBoldBillDesc == null) ? 0 : scMediumBoldBillDesc
						.hashCode());
		result = prime
				* result
				+ ((scShortBillDescription == null) ? 0
						: scShortBillDescription.hashCode());
		result = prime
				* result
				+ ((scShortBillSpanishDesc == null) ? 0
						: scShortBillSpanishDesc.hashCode());
		result = prime * result
				+ ((securtyProfile == null) ? 0 : securtyProfile.hashCode());
		result = prime
				* result
				+ ((spanishLongBillDesc == null) ? 0 : spanishLongBillDesc
						.hashCode());
		result = prime
				* result
				+ ((spanishMediumBoldDesc == null) ? 0 : spanishMediumBoldDesc
						.hashCode());
		result = prime * result
				+ ((startDate == null) ? 0 : startDate.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		result = prime * result
				+ ((titanIndicator == null) ? 0 : titanIndicator.hashCode());
		result = prime * result
				+ ((transportType == null) ? 0 : transportType.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BundlesBean other = (BundlesBean) obj;
		if (addLineMobility == null) {
			if (other.addLineMobility != null)
				return false;
		} else if (!addLineMobility.equals(other.addLineMobility))
			return false;
		if (assignToGroupRule == null) {
			if (other.assignToGroupRule != null)
				return false;
		} else if (!assignToGroupRule.equals(other.assignToGroupRule))
			return false;
		if (associatedPromoofferId == null) {
			if (other.associatedPromoofferId != null)
				return false;
		} else if (!associatedPromoofferId.equals(other.associatedPromoofferId))
			return false;
		if (associatedpromocode == null) {
			if (other.associatedpromocode != null)
				return false;
		} else if (!associatedpromocode.equals(other.associatedpromocode))
			return false;
		if (baseOfferDescription == null) {
			if (other.baseOfferDescription != null)
				return false;
		} else if (!baseOfferDescription.equals(other.baseOfferDescription))
			return false;
		if (baseOfferId == null) {
			if (other.baseOfferId != null)
				return false;
		} else if (!baseOfferId.equals(other.baseOfferId))
			return false;
		if (bundleDescription == null) {
			if (other.bundleDescription != null)
				return false;
		} else if (!bundleDescription.equals(other.bundleDescription))
			return false;
		if (bundleOrderActionType == null) {
			if (other.bundleOrderActionType != null)
				return false;
		} else if (!bundleOrderActionType.equals(other.bundleOrderActionType))
			return false;
		if (bundlePackageId == null) {
			if (other.bundlePackageId != null)
				return false;
		} else if (!bundlePackageId.equals(other.bundlePackageId))
			return false;
		if (bundleReplaceabilityInd == null) {
			if (other.bundleReplaceabilityInd != null)
				return false;
		} else if (!bundleReplaceabilityInd
				.equals(other.bundleReplaceabilityInd))
			return false;
		if (contractTerm == null) {
			if (other.contractTerm != null)
				return false;
		} else if (!contractTerm.equals(other.contractTerm))
			return false;
		if (coreProductAddedNew == null) {
			if (other.coreProductAddedNew != null)
				return false;
		} else if (!coreProductAddedNew.equals(other.coreProductAddedNew))
			return false;
		if (coreProductExisting == null) {
			if (other.coreProductExisting != null)
				return false;
		} else if (!coreProductExisting.equals(other.coreProductExisting))
			return false;
		if (cppDuration == null) {
			if (other.cppDuration != null)
				return false;
		} else if (!cppDuration.equals(other.cppDuration))
			return false;
		if (cppRanking == null) {
			if (other.cppRanking != null)
				return false;
		} else if (!cppRanking.equals(other.cppRanking))
			return false;
		if (customerSubtype == null) {
			if (other.customerSubtype != null)
				return false;
		} else if (!customerSubtype.equals(other.customerSubtype))
			return false;
		if (endDate == null) {
			if (other.endDate != null)
				return false;
		} else if (!endDate.equals(other.endDate))
			return false;
		if (etfBasedOnUverse == null) {
			if (other.etfBasedOnUverse != null)
				return false;
		} else if (!etfBasedOnUverse.equals(other.etfBasedOnUverse))
			return false;
		if (etfStaticAmount == null) {
			if (other.etfStaticAmount != null)
				return false;
		} else if (!etfStaticAmount.equals(other.etfStaticAmount))
			return false;
		if (existingDslLegacyInd == null) {
			if (other.existingDslLegacyInd != null)
				return false;
		} else if (!existingDslLegacyInd.equals(other.existingDslLegacyInd))
			return false;
		if (existingTelcoLegacyInd == null) {
			if (other.existingTelcoLegacyInd != null)
				return false;
		} else if (!existingTelcoLegacyInd.equals(other.existingTelcoLegacyInd))
			return false;
		if (geo == null) {
			if (other.geo != null)
				return false;
		} else if (!geo.equals(other.geo))
			return false;
		if (globalRole == null) {
			if (other.globalRole != null)
				return false;
		} else if (!globalRole.equals(other.globalRole))
			return false;
		if (mobilityBusinessChannel == null) {
			if (other.mobilityBusinessChannel != null)
				return false;
		} else if (!mobilityBusinessChannel
				.equals(other.mobilityBusinessChannel))
			return false;
		if (newChangeDeploymentDate == null) {
			if (other.newChangeDeploymentDate != null)
				return false;
		} else if (!newChangeDeploymentDate
				.equals(other.newChangeDeploymentDate))
			return false;
		if (notes == null) {
			if (other.notes != null)
				return false;
		} else if (!notes.equals(other.notes))
			return false;
		if (optionalCoreUverseUpgr == null) {
			if (other.optionalCoreUverseUpgr != null)
				return false;
		} else if (!optionalCoreUverseUpgr.equals(other.optionalCoreUverseUpgr))
			return false;
		if (packagesPlans == null) {
			if (other.packagesPlans != null)
				return false;
		} else if (!packagesPlans.equals(other.packagesPlans))
			return false;
		if (priceGuarantee == null) {
			if (other.priceGuarantee != null)
				return false;
		} else if (!priceGuarantee.equals(other.priceGuarantee))
			return false;
		if (profileDefaulTeam == null) {
			if (other.profileDefaulTeam != null)
				return false;
		} else if (!profileDefaulTeam.equals(other.profileDefaulTeam))
			return false;
		if (promoCtr == null) {
			if (other.promoCtr != null)
				return false;
		} else if (!promoCtr.equals(other.promoCtr))
			return false;
		if (promotionSingleCreditDisp == null) {
			if (other.promotionSingleCreditDisp != null)
				return false;
		} else if (!promotionSingleCreditDisp
				.equals(other.promotionSingleCreditDisp))
			return false;
		if (quotaDefined == null) {
			if (other.quotaDefined != null)
				return false;
		} else if (!quotaDefined.equals(other.quotaDefined))
			return false;
		if (requiredProducts == null) {
			if (other.requiredProducts != null)
				return false;
		} else if (!requiredProducts.equals(other.requiredProducts))
			return false;
		if (retermEquipAndDu == null) {
			if (other.retermEquipAndDu != null)
				return false;
		} else if (!retermEquipAndDu.equals(other.retermEquipAndDu))
			return false;
		if (retermEquipOrDu == null) {
			if (other.retermEquipOrDu != null)
				return false;
		} else if (!retermEquipOrDu.equals(other.retermEquipOrDu))
			return false;
		if (retermMobilityEquipUpgr == null) {
			if (other.retermMobilityEquipUpgr != null)
				return false;
		} else if (!retermMobilityEquipUpgr
				.equals(other.retermMobilityEquipUpgr))
			return false;
		if (salesChannel == null) {
			if (other.salesChannel != null)
				return false;
		} else if (!salesChannel.equals(other.salesChannel))
			return false;
		if (scCsrMobilityOnline == null) {
			if (other.scCsrMobilityOnline != null)
				return false;
		} else if (!scCsrMobilityOnline.equals(other.scCsrMobilityOnline))
			return false;
		if (scLongBillDesc == null) {
			if (other.scLongBillDesc != null)
				return false;
		} else if (!scLongBillDesc.equals(other.scLongBillDesc))
			return false;
		if (scMediumBoldBillDesc == null) {
			if (other.scMediumBoldBillDesc != null)
				return false;
		} else if (!scMediumBoldBillDesc.equals(other.scMediumBoldBillDesc))
			return false;
		if (scShortBillDescription == null) {
			if (other.scShortBillDescription != null)
				return false;
		} else if (!scShortBillDescription.equals(other.scShortBillDescription))
			return false;
		if (scShortBillSpanishDesc == null) {
			if (other.scShortBillSpanishDesc != null)
				return false;
		} else if (!scShortBillSpanishDesc.equals(other.scShortBillSpanishDesc))
			return false;
		if (securtyProfile == null) {
			if (other.securtyProfile != null)
				return false;
		} else if (!securtyProfile.equals(other.securtyProfile))
			return false;
		if (spanishLongBillDesc == null) {
			if (other.spanishLongBillDesc != null)
				return false;
		} else if (!spanishLongBillDesc.equals(other.spanishLongBillDesc))
			return false;
		if (spanishMediumBoldDesc == null) {
			if (other.spanishMediumBoldDesc != null)
				return false;
		} else if (!spanishMediumBoldDesc.equals(other.spanishMediumBoldDesc))
			return false;
		if (startDate == null) {
			if (other.startDate != null)
				return false;
		} else if (!startDate.equals(other.startDate))
			return false;
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		if (titanIndicator == null) {
			if (other.titanIndicator != null)
				return false;
		} else if (!titanIndicator.equals(other.titanIndicator))
			return false;
		if (transportType == null) {
			if (other.transportType != null)
				return false;
		} else if (!transportType.equals(other.transportType))
			return false;
		return true;
	}
	
	

	public String getNewChangeDeploymentDate() {
		return newChangeDeploymentDate;
	}
	public void setNewChangeDeploymentDate(String newChangeDeploymentDate) {
		this.newChangeDeploymentDate = newChangeDeploymentDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getBundlePackageId() {
		return bundlePackageId;
	}
	public void setBundlePackageId(String bundlePackageId) {
		this.bundlePackageId = bundlePackageId;
	}
	public String getAssociatedPromoofferId() {
		return associatedPromoofferId;
	}
	public void setAssociatedPromoofferId(String associatedPromoofferId) {
		this.associatedPromoofferId = associatedPromoofferId;
	}
	public String getAssociatedpromocode() {
		return associatedpromocode;
	}
	public void setAssociatedpromocode(String associatedpromocode) {
		this.associatedpromocode = associatedpromocode;
	}
	public String getBaseOfferId() {
		return baseOfferId;
	}
	public void setBaseOfferId(String baseOfferId) {
		this.baseOfferId = baseOfferId;
	}
	public String getBaseOfferDescription() {
		return baseOfferDescription;
	}
	public void setBaseOfferDescription(String baseOfferDescription) {
		this.baseOfferDescription = baseOfferDescription;
	}
	public String getRequiredProducts() {
		return requiredProducts;
	}
	public void setRequiredProducts(String requiredProducts) {
		this.requiredProducts = requiredProducts;
	}
	public String getPackagesPlans() {
		return packagesPlans;
	}
	public void setPackagesPlans(String packagesPlans) {
		this.packagesPlans = packagesPlans;
	}
	public String getCustomerSubtype() {
		return customerSubtype;
	}
	public void setCustomerSubtype(String customerSubtype) {
		this.customerSubtype = customerSubtype;
	}
	public String getGeo() {
		return geo;
	}
	public void setGeo(String geo) {
		this.geo = geo;
	}
	public String getSalesChannel() {
		return salesChannel;
	}
	public void setSalesChannel(String salesChannel) {
		this.salesChannel = salesChannel;
	}
	public String getProfileDefaulTeam() {
		return profileDefaulTeam;
	}
	public void setProfileDefaulTeam(String profileDefaulTeam) {
		this.profileDefaulTeam = profileDefaulTeam;
	}
	public String getGlobalRole() {
		return globalRole;
	}
	public void setGlobalRole(String globalRole) {
		this.globalRole = globalRole;
	}
	public String getMobilityBusinessChannel() {
		return mobilityBusinessChannel;
	}
	public void setMobilityBusinessChannel(String mobilityBusinessChannel) {
		this.mobilityBusinessChannel = mobilityBusinessChannel;
	}
	public String getSecurtyProfile() {
		return securtyProfile;
	}
	public void setSecurtyProfile(String securtyProfile) {
		this.securtyProfile = securtyProfile;
	}
	public String getExistingDslLegacyInd() {
		return existingDslLegacyInd;
	}
	public void setExistingDslLegacyInd(String existingDslLegacyInd) {
		this.existingDslLegacyInd = existingDslLegacyInd;
	}
	public String getExistingTelcoLegacyInd() {
		return existingTelcoLegacyInd;
	}
	public void setExistingTelcoLegacyInd(String existingTelcoLegacyInd) {
		this.existingTelcoLegacyInd = existingTelcoLegacyInd;
	}
	public String getBundleDescription() {
		return bundleDescription;
	}
	public void setBundleDescription(String bundleDescription) {
		this.bundleDescription = bundleDescription;
	}
	public String getCppRanking() {
		return cppRanking;
	}
	public void setCppRanking(String cppRanking) {
		this.cppRanking = cppRanking;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getBundleOrderActionType() {
		return bundleOrderActionType;
	}
	public void setBundleOrderActionType(String bundleOrderActionType) {
		this.bundleOrderActionType = bundleOrderActionType;
	}
	public String getCppDuration() {
		return cppDuration;
	}
	public void setCppDuration(String cppDuration) {
		this.cppDuration = cppDuration;
	}
	public String getAssignToGroupRule() {
		return assignToGroupRule;
	}
	public void setAssignToGroupRule(String assignToGroupRule) {
		this.assignToGroupRule = assignToGroupRule;
	}
	public String getQuotaDefined() {
		return quotaDefined;
	}
	public void setQuotaDefined(String quotaDefined) {
		this.quotaDefined = quotaDefined;
	}
	public String getTitanIndicator() {
		return titanIndicator;
	}
	public void setTitanIndicator(String titanIndicator) {
		this.titanIndicator = titanIndicator;
	}
	public String getBundleReplaceabilityInd() {
		return bundleReplaceabilityInd;
	}
	public void setBundleReplaceabilityInd(String bundleReplaceabilityInd) {
		this.bundleReplaceabilityInd = bundleReplaceabilityInd;
	}
	public String getPriceQuarantee() {
		return priceGuarantee;
	}
	public void setPriceQuarantee(String priceQuarantee) {
		this.priceGuarantee = priceQuarantee;
	}
	public String getContractTerm() {
		return contractTerm;
	}
	public void setContractTerm(String contractTerm) {
		this.contractTerm = contractTerm;
	}
	public String getEtfBasedOnUverse() {
		return etfBasedOnUverse;
	}
	public void setEtfBasedOnUverse(String etfBasedOnUverse) {
		this.etfBasedOnUverse = etfBasedOnUverse;
	}
	public String getEtfAmount() {
		return etfStaticAmount;
	}
	public void setEtfAmount(String etfAmount) {
		this.etfStaticAmount = etfAmount;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public String getTransportType() {
		return transportType;
	}
	public void setTransportType(String transportType) {
		this.transportType = transportType;
	}
	public String getPriceGuarantee() {
		return priceGuarantee;
	}
	public void setPriceGuarantee(String priceGuarantee) {
		this.priceGuarantee = priceGuarantee;
	}
	public String getEtfStaticAmount() {
		return etfStaticAmount;
	}
	public void setEtfStaticAmount(String etfStaticAmount) {
		this.etfStaticAmount = etfStaticAmount;
	}
	public String getCoreProductAddedNew() {
		return coreProductAddedNew;
	}
	public void setCoreProductAddedNew(String coreProductAddedNew) {
		this.coreProductAddedNew = coreProductAddedNew;
	}
	public String getCoreProductExisting() {
		return coreProductExisting;
	}
	public void setCoreProductExisting(String coreProductExisting) {
		this.coreProductExisting = coreProductExisting;
	}
	public String getOptionalCoreUverseUpgr() {
		return optionalCoreUverseUpgr;
	}
	public void setOptionalCoreUverseUpgr(String optionalCoreUverseUpgr) {
		this.optionalCoreUverseUpgr = optionalCoreUverseUpgr;
	}
	public String getRetermMobilityEquipUpgr() {
		return retermMobilityEquipUpgr;
	}
	public void setRetermMobilityEquipUpgr(String retermMobilityEquipUpgr) {
		this.retermMobilityEquipUpgr = retermMobilityEquipUpgr;
	}
	public String getAddLineMobility() {
		return addLineMobility;
	}
	public void setAddLineMobility(String addLineMobility) {
		this.addLineMobility = addLineMobility;
	}
	public String getRetermEquipAndDu() {
		return retermEquipAndDu;
	}
	public void setRetermEquipAndDu(String retermEquipAndDu) {
		this.retermEquipAndDu = retermEquipAndDu;
	}
	public String getRetermEquipOrDu() {
		return retermEquipOrDu;
	}
	public void setRetermEquipOrDu(String retermEquipOrDu) {
		this.retermEquipOrDu = retermEquipOrDu;
	}
	public String getPromotionSingleCreditDisp() {
		return promotionSingleCreditDisp;
	}
	public void setPromotionSingleCreditDisp(String promotionSingleCreditDisp) {
		this.promotionSingleCreditDisp = promotionSingleCreditDisp;
	}
	public String getScShortBillDescription() {
		return scShortBillDescription;
	}
	public void setScShortBillDescription(String scShortBillDescription) {
		this.scShortBillDescription = scShortBillDescription;
	}
	public String getScShortBillSpanishDesc() {
		return scShortBillSpanishDesc;
	}
	public void setScShortBillSpanishDesc(String scShortBillSpanishDesc) {
		this.scShortBillSpanishDesc = scShortBillSpanishDesc;
	}
	public String getScMediumBoldBillDesc() {
		return scMediumBoldBillDesc;
	}
	public void setScMediumBoldBillDesc(String scMediumBoldBillDesc) {
		this.scMediumBoldBillDesc = scMediumBoldBillDesc;
	}
	public String getScLongBillDesc() {
		return scLongBillDesc;
	}
	public void setScLongBillDesc(String scLongBillDesc) {
		this.scLongBillDesc = scLongBillDesc;
	}
	public String getSpanishMediumBoldDesc() {
		return spanishMediumBoldDesc;
	}
	public void setSpanishMediumBoldDesc(String spanishMediumBoldDesc) {
		this.spanishMediumBoldDesc = spanishMediumBoldDesc;
	}
	public String getSpanishLongBillDesc() {
		return spanishLongBillDesc;
	}
	public void setSpanishLongBillDesc(String spanishLongBillDesc) {
		this.spanishLongBillDesc = spanishLongBillDesc;
	}
	public String getScCsrMobilityOnline() {
		return scCsrMobilityOnline;
	}
	public void setScCsrMobilityOnline(String scCsrMobilityOnline) {
		this.scCsrMobilityOnline = scCsrMobilityOnline;
	}
	public String getPromoCtr() {
		return promoCtr;
	}
	public void setPromoCtr(String promoCtr) {
		this.promoCtr = promoCtr;
	}
	

}
