package com.uverse.mktg.bean;

/**
 * @author sm802k
 *
 */
public class EmailStatusBean {

	private String fileName;
	private String importIssue;
	private String importStatus;

	public String getImportStatus() {
		return importStatus;
	}

	public void setImportStatus(String importStatus) {
		this.importStatus = importStatus;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getImportIssue() {
		return importIssue;
	}

	public void setImportIssue(String importIssue) {
		this.importIssue = importIssue;
	}

}
