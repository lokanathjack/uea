package com.uverse.mktg.bean;

public class GroupConflictBean {
	
	private String globalStatus;
	private String ruleID;
	private String qualifyingGroup;
	private String restrictedGroup;
	private String minNofromQualGroup;
	private String qualGroupHistory;
	private String minDuration;
	private String maxDuration;
	private String effectiveDate;
	private String expirationDate;
	private String contractObligation;
	private String checkOrder;
	private String qualifyingEntity;
	private String impactedEntity;
	private String status;
	private String deployDate;
	private String creationDate;
	private String lastImportDateTime;
	private String lastImportedBy;
	private String rowActionCode;
	private String workEffortName;
	private String environmentSource;
	private String qualifyingGroupException;
	private String impactedGroupException;
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((checkOrder == null) ? 0 : checkOrder.hashCode());
		result = prime
				* result
				+ ((contractObligation == null) ? 0 : contractObligation
						.hashCode());
		result = prime * result
				+ ((creationDate == null) ? 0 : creationDate.hashCode());
		result = prime * result
				+ ((deployDate == null) ? 0 : deployDate.hashCode());
		result = prime * result
				+ ((effectiveDate == null) ? 0 : effectiveDate.hashCode());
		result = prime
				* result
				+ ((environmentSource == null) ? 0 : environmentSource
						.hashCode());
		result = prime * result
				+ ((expirationDate == null) ? 0 : expirationDate.hashCode());
		result = prime * result
				+ ((globalStatus == null) ? 0 : globalStatus.hashCode());
		result = prime * result
				+ ((impactedEntity == null) ? 0 : impactedEntity.hashCode());
		result = prime
				* result
				+ ((impactedGroupException == null) ? 0
						: impactedGroupException.hashCode());
		result = prime
				* result
				+ ((lastImportDateTime == null) ? 0 : lastImportDateTime
						.hashCode());
		result = prime * result
				+ ((lastImportedBy == null) ? 0 : lastImportedBy.hashCode());
		result = prime * result
				+ ((maxDuration == null) ? 0 : maxDuration.hashCode());
		result = prime * result
				+ ((minDuration == null) ? 0 : minDuration.hashCode());
		result = prime
				* result
				+ ((minNofromQualGroup == null) ? 0 : minNofromQualGroup
						.hashCode());
		result = prime
				* result
				+ ((qualGroupHistory == null) ? 0 : qualGroupHistory.hashCode());
		result = prime
				* result
				+ ((qualifyingEntity == null) ? 0 : qualifyingEntity.hashCode());
		result = prime * result
				+ ((qualifyingGroup == null) ? 0 : qualifyingGroup.hashCode());
		result = prime
				* result
				+ ((qualifyingGroupException == null) ? 0
						: qualifyingGroupException.hashCode());
		result = prime * result
				+ ((restrictedGroup == null) ? 0 : restrictedGroup.hashCode());
		result = prime * result
				+ ((rowActionCode == null) ? 0 : rowActionCode.hashCode());
		result = prime * result + ((ruleID == null) ? 0 : ruleID.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		result = prime * result
				+ ((workEffortName == null) ? 0 : workEffortName.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		GroupConflictBean other = (GroupConflictBean) obj;
		if (checkOrder == null) {
			if (other.checkOrder != null)
				return false;
		} else if (!checkOrder.equals(other.checkOrder))
			return false;
		if (contractObligation == null) {
			if (other.contractObligation != null)
				return false;
		} else if (!contractObligation.equals(other.contractObligation))
			return false;
		if (creationDate == null) {
			if (other.creationDate != null)
				return false;
		} else if (!creationDate.equals(other.creationDate))
			return false;
		if (deployDate == null) {
			if (other.deployDate != null)
				return false;
		} else if (!deployDate.equals(other.deployDate))
			return false;
		if (effectiveDate == null) {
			if (other.effectiveDate != null)
				return false;
		} else if (!effectiveDate.equals(other.effectiveDate))
			return false;
		if (environmentSource == null) {
			if (other.environmentSource != null)
				return false;
		} else if (!environmentSource.equals(other.environmentSource))
			return false;
		if (expirationDate == null) {
			if (other.expirationDate != null)
				return false;
		} else if (!expirationDate.equals(other.expirationDate))
			return false;
		if (globalStatus == null) {
			if (other.globalStatus != null)
				return false;
		} else if (!globalStatus.equals(other.globalStatus))
			return false;
		if (impactedEntity == null) {
			if (other.impactedEntity != null)
				return false;
		} else if (!impactedEntity.equals(other.impactedEntity))
			return false;
		if (impactedGroupException == null) {
			if (other.impactedGroupException != null)
				return false;
		} else if (!impactedGroupException.equals(other.impactedGroupException))
			return false;
		if (lastImportDateTime == null) {
			if (other.lastImportDateTime != null)
				return false;
		} else if (!lastImportDateTime.equals(other.lastImportDateTime))
			return false;
		if (lastImportedBy == null) {
			if (other.lastImportedBy != null)
				return false;
		} else if (!lastImportedBy.equals(other.lastImportedBy))
			return false;
		if (maxDuration == null) {
			if (other.maxDuration != null)
				return false;
		} else if (!maxDuration.equals(other.maxDuration))
			return false;
		if (minDuration == null) {
			if (other.minDuration != null)
				return false;
		} else if (!minDuration.equals(other.minDuration))
			return false;
		if (minNofromQualGroup == null) {
			if (other.minNofromQualGroup != null)
				return false;
		} else if (!minNofromQualGroup.equals(other.minNofromQualGroup))
			return false;
		if (qualGroupHistory == null) {
			if (other.qualGroupHistory != null)
				return false;
		} else if (!qualGroupHistory.equals(other.qualGroupHistory))
			return false;
		if (qualifyingEntity == null) {
			if (other.qualifyingEntity != null)
				return false;
		} else if (!qualifyingEntity.equals(other.qualifyingEntity))
			return false;
		if (qualifyingGroup == null) {
			if (other.qualifyingGroup != null)
				return false;
		} else if (!qualifyingGroup.equals(other.qualifyingGroup))
			return false;
		if (qualifyingGroupException == null) {
			if (other.qualifyingGroupException != null)
				return false;
		} else if (!qualifyingGroupException
				.equals(other.qualifyingGroupException))
			return false;
		if (restrictedGroup == null) {
			if (other.restrictedGroup != null)
				return false;
		} else if (!restrictedGroup.equals(other.restrictedGroup))
			return false;
		if (rowActionCode == null) {
			if (other.rowActionCode != null)
				return false;
		} else if (!rowActionCode.equals(other.rowActionCode))
			return false;
		if (ruleID == null) {
			if (other.ruleID != null)
				return false;
		} else if (!ruleID.equals(other.ruleID))
			return false;
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		if (workEffortName == null) {
			if (other.workEffortName != null)
				return false;
		} else if (!workEffortName.equals(other.workEffortName))
			return false;
		return true;
	}
	public String getGlobalStatus() {
		return globalStatus;
	}
	public void setGlobalStatus(String globalStatus) {
		this.globalStatus = globalStatus;
	}
	public String getRuleID() {
		return ruleID;
	}
	public void setRuleID(String ruleID) {
		this.ruleID = ruleID;
	}
	public String getQualifyingGroup() {
		return qualifyingGroup;
	}
	public void setQualifyingGroup(String qualifyingGroup) {
		this.qualifyingGroup = qualifyingGroup;
	}
	public String getRestrictedGroup() {
		return restrictedGroup;
	}
	public void setRestrictedGroup(String restrictedGroup) {
		this.restrictedGroup = restrictedGroup;
	}
	public String getMinNofromQualGroup() {
		return minNofromQualGroup;
	}
	public void setMinNofromQualGroup(String minNofromQualGroup) {
		this.minNofromQualGroup = minNofromQualGroup;
	}
	public String getQualGroupHistory() {
		return qualGroupHistory;
	}
	public void setQualGroupHistory(String qualGroupHistory) {
		this.qualGroupHistory = qualGroupHistory;
	}
	public String getMinDuration() {
		return minDuration;
	}
	public void setMinDuration(String minDuration) {
		this.minDuration = minDuration;
	}
	public String getMaxDuration() {
		return maxDuration;
	}
	public void setMaxDuration(String maxDuration) {
		this.maxDuration = maxDuration;
	}
	public String getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public String getExpirationDate() {
		return expirationDate;
	}
	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}
	public String getContractObligation() {
		return contractObligation;
	}
	public void setContractObligation(String contractObligation) {
		this.contractObligation = contractObligation;
	}
	public String getCheckOrder() {
		return checkOrder;
	}
	public void setCheckOrder(String checkOrder) {
		this.checkOrder = checkOrder;
	}
	public String getQualifyingEntity() {
		return qualifyingEntity;
	}
	public void setQualifyingEntity(String qualifyingEntity) {
		this.qualifyingEntity = qualifyingEntity;
	}
	public String getImpactedEntity() {
		return impactedEntity;
	}
	public void setImpactedEntity(String impactedEntity) {
		this.impactedEntity = impactedEntity;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getDeployDate() {
		return deployDate;
	}
	public void setDeployDate(String deployDate) {
		this.deployDate = deployDate;
	}
	public String getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}
	public String getLastImportDateTime() {
		return lastImportDateTime;
	}
	public void setLastImportDateTime(String lastImportDateTime) {
		this.lastImportDateTime = lastImportDateTime;
	}
	public String getLastImportedBy() {
		return lastImportedBy;
	}
	public void setLastImportedBy(String lastImportedBy) {
		this.lastImportedBy = lastImportedBy;
	}
	public String getRowActionCode() {
		return rowActionCode;
	}
	public void setRowActionCode(String rowActionCode) {
		this.rowActionCode = rowActionCode;
	}
	public String getWorkEffortName() {
		return workEffortName;
	}
	public void setWorkEffortName(String workEffortName) {
		this.workEffortName = workEffortName;
	}
	public String getEnvironmentSource() {
		return environmentSource;
	}
	public void setEnvironmentSource(String environmentSource) {
		this.environmentSource = environmentSource;
	}
	public String getQualifyingGroupException() {
		return qualifyingGroupException;
	}
	public void setQualifyingGroupException(String qualifyingGroupException) {
		this.qualifyingGroupException = qualifyingGroupException;
	}
	public String getImpactedGroupException() {
		return impactedGroupException;
	}
	public void setImpactedGroupException(String impactedGroupException) {
		this.impactedGroupException = impactedGroupException;
	}
	
}
