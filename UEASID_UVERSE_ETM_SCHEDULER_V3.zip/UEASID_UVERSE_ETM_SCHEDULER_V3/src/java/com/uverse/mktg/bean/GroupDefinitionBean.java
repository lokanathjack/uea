package com.uverse.mktg.bean;
public class GroupDefinitionBean {
	private String globalStatus;
	private String groupId;
	private String type;
	private String promotionOrBundleId;
	private String offerID;
	private String rowActionCode;
	private String deployDate;
	private String ctdbCreationDateTime;
	private String lastImportDateTime;
	private String lastImportedBy;
	private String workEffortName;
	private String environmentSource;
	public String getGlobalStatus() {
		return globalStatus;
	}
	public void setGlobalStatus(String globalStatus) {
		this.globalStatus = globalStatus;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getPromotionOrBundleId() {
		return promotionOrBundleId;
	}
	public void setPromotionOrBundleId(String promotionOrBundleId) {
		this.promotionOrBundleId = promotionOrBundleId;
	}
	public String getofferID() {
		return offerID;
	}
	public void setOfferID(String offerID) {
		this.offerID = offerID;
	}
	public String getRowActionCode() {
		return rowActionCode;
	}
	public void setRowActionCode(String rowActionCode) {
		this.rowActionCode = rowActionCode;
	}
	public String getDeployDate() {
		return deployDate;
	}
	public void setDeployDate(String deployDate) {
		this.deployDate = deployDate;
	}
	public String getCtdbCreationDateTime() {
		return ctdbCreationDateTime;
	}
	public void setCtdbCreationDateTime(String ctdbCreationDateTime) {
		this.ctdbCreationDateTime = ctdbCreationDateTime;
	}
	public String getLastImportDateTime() {
		return lastImportDateTime;
	}
	public void setLastImportDateTime(String lastImportDateTime) {
		this.lastImportDateTime = lastImportDateTime;
	}
	public String getLastImportedBy() {
		return lastImportedBy;
	}
	public void setLastImportedBy(String lastImportedBy) {
		this.lastImportedBy = lastImportedBy;
	}
	public String getWorkEffortName() {
		return workEffortName;
	}
	public void setWorkEffortName(String workEffortName) {
		this.workEffortName = workEffortName;
	}
	public String getEnvironmentSource() {
		return environmentSource;
	}
	public void setEnvironmentSource(String environmentSource) {
		this.environmentSource = environmentSource;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((ctdbCreationDateTime == null) ? 0 : ctdbCreationDateTime
						.hashCode());
		result = prime * result
				+ ((deployDate == null) ? 0 : deployDate.hashCode());
		result = prime
				* result
				+ ((environmentSource == null) ? 0 : environmentSource
						.hashCode());
		result = prime * result
				+ ((globalStatus == null) ? 0 : globalStatus.hashCode());
		result = prime * result + ((groupId == null) ? 0 : groupId.hashCode());
		result = prime
				* result
				+ ((lastImportDateTime == null) ? 0 : lastImportDateTime
						.hashCode());
		result = prime * result
				+ ((lastImportedBy == null) ? 0 : lastImportedBy.hashCode());
		result = prime * result + ((offerID == null) ? 0 : offerID.hashCode());
		result = prime
				* result
				+ ((promotionOrBundleId == null) ? 0 : promotionOrBundleId
						.hashCode());
		result = prime * result
				+ ((rowActionCode == null) ? 0 : rowActionCode.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		result = prime * result
				+ ((workEffortName == null) ? 0 : workEffortName.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		GroupDefinitionBean other = (GroupDefinitionBean) obj;
		if (ctdbCreationDateTime == null) {
			if (other.ctdbCreationDateTime != null)
				return false;
		} else if (!ctdbCreationDateTime.equals(other.ctdbCreationDateTime))
			return false;
		if (deployDate == null) {
			if (other.deployDate != null)
				return false;
		} else if (!deployDate.equals(other.deployDate))
			return false;
		if (environmentSource == null) {
			if (other.environmentSource != null)
				return false;
		} else if (!environmentSource.equals(other.environmentSource))
			return false;
		if (globalStatus == null) {
			if (other.globalStatus != null)
				return false;
		} else if (!globalStatus.equals(other.globalStatus))
			return false;
		if (groupId == null) {
			if (other.groupId != null)
				return false;
		} else if (!groupId.equals(other.groupId))
			return false;
		if (lastImportDateTime == null) {
			if (other.lastImportDateTime != null)
				return false;
		} else if (!lastImportDateTime.equals(other.lastImportDateTime))
			return false;
		if (lastImportedBy == null) {
			if (other.lastImportedBy != null)
				return false;
		} else if (!lastImportedBy.equals(other.lastImportedBy))
			return false;
		if (offerID == null) {
			if (other.offerID != null)
				return false;
		} else if (!offerID.equals(other.offerID))
			return false;
		if (promotionOrBundleId == null) {
			if (other.promotionOrBundleId != null)
				return false;
		} else if (!promotionOrBundleId.equals(other.promotionOrBundleId))
			return false;
		if (rowActionCode == null) {
			if (other.rowActionCode != null)
				return false;
		} else if (!rowActionCode.equals(other.rowActionCode))
			return false;
		if (type == null) {
			if (other.type != null)
				return false;
		} else if (!type.equals(other.type))
			return false;
		if (workEffortName == null) {
			if (other.workEffortName != null)
				return false;
		} else if (!workEffortName.equals(other.workEffortName))
			return false;
		return true;
	}
	
	/*public String toString(){
		return "TBGroupDefinitionBean[globalStatus="+globalStatus+"]";
	}*/
	
}
