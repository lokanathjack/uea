package com.uverse.mktg.bean;

import java.util.List;

/**
 * @author sm802k
 *
 */
public class ConfigBean {
private String tableName;
private String bkpTableName;
private String fileName;
private String fileExt;
private String somComponent; // Required only for Som type files
private String promoComponent; // Required only for promo type files
private String baseofferComponent; // Required only for Base Offer type files
public String getPromoComponent() {
	return promoComponent;
}
public void setPromoComponent(String promoComponent) {
	this.promoComponent = promoComponent;
}
private String deleimeter;
private List<String> csvColumns;
public String getTableName() {
	return tableName;
}
public void setTableName(String tableName) {
	this.tableName = tableName;
}
public String getBkpTableName() {
	return bkpTableName;
}
public void setBkpTableName(String bkpTableName) {
	this.bkpTableName = bkpTableName;
}
public String getFileName() {
	return fileName;
}
public void setFileName(String fileName) {
	this.fileName = fileName;
}
public String getFileExt() {
	return fileExt;
}
public void setFileExt(String fileExt) {
	this.fileExt = fileExt;
}
public String getSomComponent() {
	return somComponent;
}
public void setSomComponent(String somComponent) {
	this.somComponent = somComponent;
}
public List<String> getCsvColumns() {
	return csvColumns;
}
public void setCsvColumns(List<String> csvColumns) {
	this.csvColumns = csvColumns;
}
public String getDeleimeter() {
	return deleimeter;
}
public void setDeleimeter(String string) {
	this.deleimeter = string;
}
}
