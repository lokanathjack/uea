package com.uverse.mktg.bean;


public class GroupAttributesBean {

	private String globalStatus;
	private String ruleID;
	private String attributeName;
	private String operatorValue;
	private String minValue;
	private String maxValue;
	private String minDuration;
	private String maxDuration;
	private String startDate;
	private String endDate;
	private String restrictGroupID;
	private String restrictTarget;
	private String restrictOrdered;
	private String restrictException;
	private String legallyBound;
	private String deployDate;
	private String status;
	private String rowActionCode;
	private String lastImportDateTime;
	private String lastImportedBy;
	private String workEffortName;
	private String environmentSource;
	private String ruleGroup;

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((attributeName == null) ? 0 : attributeName.hashCode());
		result = prime * result
				+ ((deployDate == null) ? 0 : deployDate.hashCode());
		result = prime * result + ((endDate == null) ? 0 : endDate.hashCode());
		result = prime
				* result
				+ ((environmentSource == null) ? 0 : environmentSource
						.hashCode());
		result = prime * result
				+ ((globalStatus == null) ? 0 : globalStatus.hashCode());
		result = prime
				* result
				+ ((lastImportDateTime == null) ? 0 : lastImportDateTime
						.hashCode());
		result = prime * result
				+ ((lastImportedBy == null) ? 0 : lastImportedBy.hashCode());
		result = prime * result
				+ ((legallyBound == null) ? 0 : legallyBound.hashCode());
		result = prime * result
				+ ((maxDuration == null) ? 0 : maxDuration.hashCode());
		result = prime * result
				+ ((maxValue == null) ? 0 : maxValue.hashCode());
		result = prime * result
				+ ((minDuration == null) ? 0 : minDuration.hashCode());
		result = prime * result
				+ ((minValue == null) ? 0 : minValue.hashCode());
		result = prime * result
				+ ((operatorValue == null) ? 0 : operatorValue.hashCode());
		result = prime
				* result
				+ ((restrictException == null) ? 0 : restrictException
						.hashCode());
		result = prime * result
				+ ((restrictGroupID == null) ? 0 : restrictGroupID.hashCode());
		result = prime * result
				+ ((restrictOrdered == null) ? 0 : restrictOrdered.hashCode());
		result = prime * result
				+ ((restrictTarget == null) ? 0 : restrictTarget.hashCode());
		result = prime * result
				+ ((rowActionCode == null) ? 0 : rowActionCode.hashCode());
		result = prime * result
				+ ((ruleGroup == null) ? 0 : ruleGroup.hashCode());
		result = prime * result + ((ruleID == null) ? 0 : ruleID.hashCode());
		result = prime * result
				+ ((startDate == null) ? 0 : startDate.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		result = prime * result
				+ ((workEffortName == null) ? 0 : workEffortName.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		GroupAttributesBean other = (GroupAttributesBean) obj;
		if (attributeName == null) {
			if (other.attributeName != null)
				return false;
		} else if (!attributeName.equals(other.attributeName))
			return false;
		if (deployDate == null) {
			if (other.deployDate != null)
				return false;
		} else if (!deployDate.equals(other.deployDate))
			return false;
		if (endDate == null) {
			if (other.endDate != null)
				return false;
		} else if (!endDate.equals(other.endDate))
			return false;
		if (environmentSource == null) {
			if (other.environmentSource != null)
				return false;
		} else if (!environmentSource.equals(other.environmentSource))
			return false;
		if (globalStatus == null) {
			if (other.globalStatus != null)
				return false;
		} else if (!globalStatus.equals(other.globalStatus))
			return false;
		if (lastImportDateTime == null) {
			if (other.lastImportDateTime != null)
				return false;
		} else if (!lastImportDateTime.equals(other.lastImportDateTime))
			return false;
		if (lastImportedBy == null) {
			if (other.lastImportedBy != null)
				return false;
		} else if (!lastImportedBy.equals(other.lastImportedBy))
			return false;
		if (legallyBound == null) {
			if (other.legallyBound != null)
				return false;
		} else if (!legallyBound.equals(other.legallyBound))
			return false;
		if (maxDuration == null) {
			if (other.maxDuration != null)
				return false;
		} else if (!maxDuration.equals(other.maxDuration))
			return false;
		if (maxValue == null) {
			if (other.maxValue != null)
				return false;
		} else if (!maxValue.equals(other.maxValue))
			return false;
		if (minDuration == null) {
			if (other.minDuration != null)
				return false;
		} else if (!minDuration.equals(other.minDuration))
			return false;
		if (minValue == null) {
			if (other.minValue != null)
				return false;
		} else if (!minValue.equals(other.minValue))
			return false;
		if (operatorValue == null) {
			if (other.operatorValue != null)
				return false;
		} else if (!operatorValue.equals(other.operatorValue))
			return false;
		if (restrictException == null) {
			if (other.restrictException != null)
				return false;
		} else if (!restrictException.equals(other.restrictException))
			return false;
		if (restrictGroupID == null) {
			if (other.restrictGroupID != null)
				return false;
		} else if (!restrictGroupID.equals(other.restrictGroupID))
			return false;
		if (restrictOrdered == null) {
			if (other.restrictOrdered != null)
				return false;
		} else if (!restrictOrdered.equals(other.restrictOrdered))
			return false;
		if (restrictTarget == null) {
			if (other.restrictTarget != null)
				return false;
		} else if (!restrictTarget.equals(other.restrictTarget))
			return false;
		if (rowActionCode == null) {
			if (other.rowActionCode != null)
				return false;
		} else if (!rowActionCode.equals(other.rowActionCode))
			return false;
		if (ruleGroup == null) {
			if (other.ruleGroup != null)
				return false;
		} else if (!ruleGroup.equals(other.ruleGroup))
			return false;
		if (ruleID == null) {
			if (other.ruleID != null)
				return false;
		} else if (!ruleID.equals(other.ruleID))
			return false;
		if (startDate == null) {
			if (other.startDate != null)
				return false;
		} else if (!startDate.equals(other.startDate))
			return false;
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		if (workEffortName == null) {
			if (other.workEffortName != null)
				return false;
		} else if (!workEffortName.equals(other.workEffortName))
			return false;
		return true;
	}
	public String getGlobalStatus() {
		return globalStatus;
	}
	public void setGlobalStatus(String globalStatus) {
		this.globalStatus = globalStatus;
	}
	public String getRuleID() {
		return ruleID;
	}
	public void setRuleID(String ruleID) {
		this.ruleID = ruleID;
	}
	public String getAttributeName() {
		return attributeName;
	}
	public void setAttributeName(String attributeName) {
		this.attributeName = attributeName;
	}
	public String getOperatorValue() {
		return operatorValue;
	}
	public void setOperatorValue(String operatorValue) {
		this.operatorValue = operatorValue;
	}
	public String getMinValue() {
		return minValue;
	}
	public void setMinValue(String minValue) {
		this.minValue = minValue;
	}
	public String getMaxValue() {
		return maxValue;
	}
	public void setMaxValue(String maxValue) {
		this.maxValue = maxValue;
	}
	public String getMinDuration() {
		return minDuration;
	}
	public void setMinDuration(String minDuration) {
		this.minDuration = minDuration;
	}
	public String getMaxDuration() {
		return maxDuration;
	}
	public void setMaxDuration(String maxDuration) {
		this.maxDuration = maxDuration;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getRestrictGroupID() {
		return restrictGroupID;
	}
	public void setRestrictGroupID(String restrictGroupID) {
		this.restrictGroupID = restrictGroupID;
	}
	public String getRestrictTarget() {
		return restrictTarget;
	}
	public void setRestrictTarget(String restrictTarget) {
		this.restrictTarget = restrictTarget;
	}
	public String getRestrictOrdered() {
		return restrictOrdered;
	}
	public void setRestrictOrdered(String restrictOrdered) {
		this.restrictOrdered = restrictOrdered;
	}
	public String getRestrictException() {
		return restrictException;
	}
	public void setRestrictException(String restrictException) {
		this.restrictException = restrictException;
	}
	public String getLegallyBound() {
		return legallyBound;
	}
	public void setLegallyBound(String legallyBound) {
		this.legallyBound = legallyBound;
	}
	public String getDeployDate() {
		return deployDate;
	}
	public void setDeployDate(String deployDate) {
		this.deployDate = deployDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRowActionCode() {
		return rowActionCode;
	}
	public void setRowActionCode(String rowActionCode) {
		this.rowActionCode = rowActionCode;
	}
	public String getLastImportDateTime() {
		return lastImportDateTime;
	}
	public void setLastImportDateTime(String lastImportDateTime) {
		this.lastImportDateTime = lastImportDateTime;
	}
	public String getLastImportedBy() {
		return lastImportedBy;
	}
	public void setLastImportedBy(String lastImportedBy) {
		this.lastImportedBy = lastImportedBy;
	}
	public String getWorkEffortName() {
		return workEffortName;
	}
	public void setWorkEffortName(String workEffortName) {
		this.workEffortName = workEffortName;
	}
	public String getEnvironmentSource() {
		return environmentSource;
	}
	public void setEnvironmentSource(String environmentSource) {
		this.environmentSource = environmentSource;
	}
	public String getRuleGroup() {
		return ruleGroup;
	}
	public void setRuleGroup(String ruleGroup) {
		this.ruleGroup = ruleGroup;
	}
	
	
	
}
