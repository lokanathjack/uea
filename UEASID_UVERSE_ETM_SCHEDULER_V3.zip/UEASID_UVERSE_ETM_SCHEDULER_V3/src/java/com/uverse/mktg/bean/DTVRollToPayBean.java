package com.uverse.mktg.bean;

public class DTVRollToPayBean {
	
	private String status;
	private String newChangeDeploymentDate;
	private String promoCode;
	private String offerId;
	private String offerName;
	private String rollType;
	private String shortMessageId;
	private String shortMessageText;
	private String longMessageId;
	private String longMessageText;
	private String pfdMessageId;
	private String pfdMessageText;
	
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getNewChangeDeploymentDate() {
		return newChangeDeploymentDate;
	}
	public void setNewChangeDeploymentDate(String newChangeDeploymentDate) {
		this.newChangeDeploymentDate = newChangeDeploymentDate;
	}
	public String getPromoCode() {
		return promoCode;
	}
	public void setPromoCode(String promoCode) {
		this.promoCode = promoCode;
	}
	public String getOfferId() {
		return offerId;
	}
	public void setOfferId(String offerId) {
		this.offerId = offerId;
	}
	public String getOfferName() {
		return offerName;
	}
	public void setOfferName(String offerName) {
		this.offerName = offerName;
	}
	public String getRollType() {
		return rollType;
	}
	public void setRollType(String rollType) {
		this.rollType = rollType;
	}
	public String getShortMessageId() {
		return shortMessageId;
	}
	public void setShortMessageId(String shortMessageId) {
		this.shortMessageId = shortMessageId;
	}
	public String getShortMessageText() {
		return shortMessageText;
	}
	public void setShortMessageText(String shortMessageText) {
		this.shortMessageText = shortMessageText;
	}
	public String getLongMessageId() {
		return longMessageId;
	}
	public void setLongMessageId(String longMessageId) {
		this.longMessageId = longMessageId;
	}
	public String getLongMessageText() {
		return longMessageText;
	}
	public void setLongMessageText(String longMessageText) {
		this.longMessageText = longMessageText;
	}
	public String getPfdMessageId() {
		return pfdMessageId;
	}
	public void setPfdMessageId(String pfdMessageId) {
		this.pfdMessageId = pfdMessageId;
	}
	public String getPfdMessageText() {
		return pfdMessageText;
	}
	public void setPfdMessageText(String pfdMessageText) {
		this.pfdMessageText = pfdMessageText;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((longMessageId == null) ? 0 : longMessageId.hashCode());
		result = prime * result
				+ ((longMessageText == null) ? 0 : longMessageText.hashCode());
		result = prime
				* result
				+ ((newChangeDeploymentDate == null) ? 0
						: newChangeDeploymentDate.hashCode());
		result = prime * result + ((offerId == null) ? 0 : offerId.hashCode());
		result = prime * result
				+ ((offerName == null) ? 0 : offerName.hashCode());
		result = prime * result
				+ ((pfdMessageId == null) ? 0 : pfdMessageId.hashCode());
		result = prime * result
				+ ((pfdMessageText == null) ? 0 : pfdMessageText.hashCode());
		result = prime * result
				+ ((promoCode == null) ? 0 : promoCode.hashCode());
		result = prime * result
				+ ((rollType == null) ? 0 : rollType.hashCode());
		result = prime * result
				+ ((shortMessageId == null) ? 0 : shortMessageId.hashCode());
		result = prime
				* result
				+ ((shortMessageText == null) ? 0 : shortMessageText.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DTVRollToPayBean other = (DTVRollToPayBean) obj;
		if (longMessageId == null) {
			if (other.longMessageId != null)
				return false;
		} else if (!longMessageId.equals(other.longMessageId))
			return false;
		if (longMessageText == null) {
			if (other.longMessageText != null)
				return false;
		} else if (!longMessageText.equals(other.longMessageText))
			return false;
		if (newChangeDeploymentDate == null) {
			if (other.newChangeDeploymentDate != null)
				return false;
		} else if (!newChangeDeploymentDate
				.equals(other.newChangeDeploymentDate))
			return false;
		if (offerId == null) {
			if (other.offerId != null)
				return false;
		} else if (!offerId.equals(other.offerId))
			return false;
		if (offerName == null) {
			if (other.offerName != null)
				return false;
		} else if (!offerName.equals(other.offerName))
			return false;
		if (pfdMessageId == null) {
			if (other.pfdMessageId != null)
				return false;
		} else if (!pfdMessageId.equals(other.pfdMessageId))
			return false;
		if (pfdMessageText == null) {
			if (other.pfdMessageText != null)
				return false;
		} else if (!pfdMessageText.equals(other.pfdMessageText))
			return false;
		if (promoCode == null) {
			if (other.promoCode != null)
				return false;
		} else if (!promoCode.equals(other.promoCode))
			return false;
		if (rollType == null) {
			if (other.rollType != null)
				return false;
		} else if (!rollType.equals(other.rollType))
			return false;
		if (shortMessageId == null) {
			if (other.shortMessageId != null)
				return false;
		} else if (!shortMessageId.equals(other.shortMessageId))
			return false;
		if (shortMessageText == null) {
			if (other.shortMessageText != null)
				return false;
		} else if (!shortMessageText.equals(other.shortMessageText))
			return false;
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		return true;
	}
	
}
