package com.uverse.mktg.bean;

public class BaseOfferBean {

	private String deploymentDate;
	private String status;
	private String notes;
	private String offerId;
	private String promotionCode;
	private String salesOfferId;
	private String salesOfferName;
	private String salesOfferDescription;
	private String category;
	private String lob;
	private String type;
	private String priority;
	private String disposition;
	private String section;
	private String soGroup;
	private String sendToADE;
	private String adeName;
	private String mainPermutationId;
	private String callIntent1;
	private String callIntent2;
	private int promoCtr=1;
	public int getPromoCtr() {
		return promoCtr;
	}
	public void setPromoCtr(int promoCtr) {
		this.promoCtr = promoCtr;
	}
	public String getDeploymentDate() {
		return deploymentDate;
	}
	public void setDeploymentDate(String deploymentDate) {
		this.deploymentDate = deploymentDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((adeName == null) ? 0 : adeName.hashCode());
		result = prime * result
				+ ((callIntent1 == null) ? 0 : callIntent1.hashCode());
		result = prime * result
				+ ((callIntent2 == null) ? 0 : callIntent2.hashCode());
		result = prime * result
				+ ((category == null) ? 0 : category.hashCode());
		result = prime * result
				+ ((creditBand == null) ? 0 : creditBand.hashCode());
		result = prime * result
				+ ((creditRisk == null) ? 0 : creditRisk.hashCode());
		result = prime * result
				+ ((customerSubtype == null) ? 0 : customerSubtype.hashCode());
		result = prime * result
				+ ((dealerGroup == null) ? 0 : dealerGroup.hashCode());
		result = prime * result
				+ ((deploymentDate == null) ? 0 : deploymentDate.hashCode());
		result = prime * result
				+ ((disposition == null) ? 0 : disposition.hashCode());
		result = prime * result + ((endDate == null) ? 0 : endDate.hashCode());
		result = prime * result
				+ ((filterKey == null) ? 0 : filterKey.hashCode());
		result = prime * result + ((geoCode == null) ? 0 : geoCode.hashCode());
		result = prime * result
				+ ((isNewComp == null) ? 0 : isNewComp.hashCode());
		result = prime * result
				+ ((isNewService == null) ? 0 : isNewService.hashCode());
		result = prime * result
				+ ((isPremium == null) ? 0 : isPremium.hashCode());
		result = prime * result + ((lob == null) ? 0 : lob.hashCode());
		result = prime * result + ((localId == null) ? 0 : localId.hashCode());
		result = prime
				* result
				+ ((mainPermutationId == null) ? 0 : mainPermutationId
						.hashCode());
		result = prime * result + ((msc == null) ? 0 : msc.hashCode());
		result = prime * result + ((notes == null) ? 0 : notes.hashCode());
		result = prime * result + ((offerId == null) ? 0 : offerId.hashCode());
		result = prime * result
				+ ((partnerName == null) ? 0 : partnerName.hashCode());
		result = prime * result
				+ ((priority == null) ? 0 : priority.hashCode());
		result = prime * result + promoCtr;
		result = prime * result
				+ ((promotionCode == null) ? 0 : promotionCode.hashCode());
		result = prime * result
				+ ((salesChannel == null) ? 0 : salesChannel.hashCode());
		result = prime
				* result
				+ ((salesOfferDescription == null) ? 0 : salesOfferDescription
						.hashCode());
		result = prime * result
				+ ((salesOfferId == null) ? 0 : salesOfferId.hashCode());
		result = prime * result
				+ ((salesOfferName == null) ? 0 : salesOfferName.hashCode());
		result = prime * result + ((section == null) ? 0 : section.hashCode());
		result = prime * result
				+ ((securityProfile == null) ? 0 : securityProfile.hashCode());
		result = prime * result
				+ ((sendToADE == null) ? 0 : sendToADE.hashCode());
		result = prime * result + ((soGroup == null) ? 0 : soGroup.hashCode());
		result = prime * result
				+ ((startDate == null) ? 0 : startDate.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		result = prime * result
				+ ((switchOnOff == null) ? 0 : switchOnOff.hashCode());
		result = prime * result
				+ ((teamSkills == null) ? 0 : teamSkills.hashCode());
		result = prime
				* result
				+ ((transportTypeGroup == null) ? 0 : transportTypeGroup
						.hashCode());
		result = prime * result
				+ ((treatmentCode == null) ? 0 : treatmentCode.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		result = prime
				* result
				+ ((zipCodeExclusion == null) ? 0 : zipCodeExclusion.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BaseOfferBean other = (BaseOfferBean) obj;
		if (adeName == null) {
			if (other.adeName != null)
				return false;
		} else if (!adeName.equals(other.adeName))
			return false;
		if (callIntent1 == null) {
			if (other.callIntent1 != null)
				return false;
		} else if (!callIntent1.equals(other.callIntent1))
			return false;
		if (callIntent2 == null) {
			if (other.callIntent2 != null)
				return false;
		} else if (!callIntent2.equals(other.callIntent2))
			return false;
		if (category == null) {
			if (other.category != null)
				return false;
		} else if (!category.equals(other.category))
			return false;
		if (creditBand == null) {
			if (other.creditBand != null)
				return false;
		} else if (!creditBand.equals(other.creditBand))
			return false;
		if (creditRisk == null) {
			if (other.creditRisk != null)
				return false;
		} else if (!creditRisk.equals(other.creditRisk))
			return false;
		if (customerSubtype == null) {
			if (other.customerSubtype != null)
				return false;
		} else if (!customerSubtype.equals(other.customerSubtype))
			return false;
		if (dealerGroup == null) {
			if (other.dealerGroup != null)
				return false;
		} else if (!dealerGroup.equals(other.dealerGroup))
			return false;
		if (deploymentDate == null) {
			if (other.deploymentDate != null)
				return false;
		} else if (!deploymentDate.equals(other.deploymentDate))
			return false;
		if (disposition == null) {
			if (other.disposition != null)
				return false;
		} else if (!disposition.equals(other.disposition))
			return false;
		if (endDate == null) {
			if (other.endDate != null)
				return false;
		} else if (!endDate.equals(other.endDate))
			return false;
		if (filterKey == null) {
			if (other.filterKey != null)
				return false;
		} else if (!filterKey.equals(other.filterKey))
			return false;
		if (geoCode == null) {
			if (other.geoCode != null)
				return false;
		} else if (!geoCode.equals(other.geoCode))
			return false;
		if (isNewComp == null) {
			if (other.isNewComp != null)
				return false;
		} else if (!isNewComp.equals(other.isNewComp))
			return false;
		if (isNewService == null) {
			if (other.isNewService != null)
				return false;
		} else if (!isNewService.equals(other.isNewService))
			return false;
		if (isPremium == null) {
			if (other.isPremium != null)
				return false;
		} else if (!isPremium.equals(other.isPremium))
			return false;
		if (lob == null) {
			if (other.lob != null)
				return false;
		} else if (!lob.equals(other.lob))
			return false;
		if (localId == null) {
			if (other.localId != null)
				return false;
		} else if (!localId.equals(other.localId))
			return false;
		if (mainPermutationId == null) {
			if (other.mainPermutationId != null)
				return false;
		} else if (!mainPermutationId.equals(other.mainPermutationId))
			return false;
		if (msc == null) {
			if (other.msc != null)
				return false;
		} else if (!msc.equals(other.msc))
			return false;
		if (notes == null) {
			if (other.notes != null)
				return false;
		} else if (!notes.equals(other.notes))
			return false;
		if (offerId == null) {
			if (other.offerId != null)
				return false;
		} else if (!offerId.equals(other.offerId))
			return false;
		if (partnerName == null) {
			if (other.partnerName != null)
				return false;
		} else if (!partnerName.equals(other.partnerName))
			return false;
		if (priority == null) {
			if (other.priority != null)
				return false;
		} else if (!priority.equals(other.priority))
			return false;
		if (promoCtr != other.promoCtr)
			return false;
		if (promotionCode == null) {
			if (other.promotionCode != null)
				return false;
		} else if (!promotionCode.equals(other.promotionCode))
			return false;
		if (salesChannel == null) {
			if (other.salesChannel != null)
				return false;
		} else if (!salesChannel.equals(other.salesChannel))
			return false;
		if (salesOfferDescription == null) {
			if (other.salesOfferDescription != null)
				return false;
		} else if (!salesOfferDescription.equals(other.salesOfferDescription))
			return false;
		if (salesOfferId == null) {
			if (other.salesOfferId != null)
				return false;
		} else if (!salesOfferId.equals(other.salesOfferId))
			return false;
		if (salesOfferName == null) {
			if (other.salesOfferName != null)
				return false;
		} else if (!salesOfferName.equals(other.salesOfferName))
			return false;
		if (section == null) {
			if (other.section != null)
				return false;
		} else if (!section.equals(other.section))
			return false;
		if (securityProfile == null) {
			if (other.securityProfile != null)
				return false;
		} else if (!securityProfile.equals(other.securityProfile))
			return false;
		if (sendToADE == null) {
			if (other.sendToADE != null)
				return false;
		} else if (!sendToADE.equals(other.sendToADE))
			return false;
		if (soGroup == null) {
			if (other.soGroup != null)
				return false;
		} else if (!soGroup.equals(other.soGroup))
			return false;
		if (startDate == null) {
			if (other.startDate != null)
				return false;
		} else if (!startDate.equals(other.startDate))
			return false;
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		if (switchOnOff == null) {
			if (other.switchOnOff != null)
				return false;
		} else if (!switchOnOff.equals(other.switchOnOff))
			return false;
		if (teamSkills == null) {
			if (other.teamSkills != null)
				return false;
		} else if (!teamSkills.equals(other.teamSkills))
			return false;
		if (transportTypeGroup == null) {
			if (other.transportTypeGroup != null)
				return false;
		} else if (!transportTypeGroup.equals(other.transportTypeGroup))
			return false;
		if (treatmentCode == null) {
			if (other.treatmentCode != null)
				return false;
		} else if (!treatmentCode.equals(other.treatmentCode))
			return false;
		if (type == null) {
			if (other.type != null)
				return false;
		} else if (!type.equals(other.type))
			return false;
		if (zipCodeExclusion == null) {
			if (other.zipCodeExclusion != null)
				return false;
		} else if (!zipCodeExclusion.equals(other.zipCodeExclusion))
			return false;
		return true;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public String getOfferId() {
		return offerId;
	}
	public void setOfferId(String offerId) {
		this.offerId = offerId;
	}
	public String getPromotionCode() {
		return promotionCode;
	}
	public void setPromotionCode(String promotionCode) {
		this.promotionCode = promotionCode;
	}
	public String getSalesOfferId() {
		return salesOfferId;
	}
	public void setSalesOfferId(String salesOfferId) {
		this.salesOfferId = salesOfferId;
	}
	public String getSalesOfferName() {
		return salesOfferName;
	}
	public void setSalesOfferName(String salesOfferName) {
		this.salesOfferName = salesOfferName;
	}
	public String getSalesOfferDescription() {
		return salesOfferDescription;
	}
	public void setSalesOfferDescription(String salesOfferDescription) {
		this.salesOfferDescription = salesOfferDescription;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getLob() {
		return lob;
	}
	public void setLob(String lob) {
		this.lob = lob;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public String getDisposition() {
		return disposition;
	}
	public void setDisposition(String disposition) {
		this.disposition = disposition;
	}
	public String getSection() {
		return section;
	}
	public void setSection(String section) {
		this.section = section;
	}
	public String getSoGroup() {
		return soGroup;
	}
	public void setSoGroup(String soGroup) {
		this.soGroup = soGroup;
	}
	public String getSendToADE() {
		return sendToADE;
	}
	public void setSendToADE(String sendToADE) {
		this.sendToADE = sendToADE;
	}
	public String getAdeName() {
		return adeName;
	}
	public void setAdeName(String adeName) {
		this.adeName = adeName;
	}
	public String getMainPermutationId() {
		return mainPermutationId;
	}
	public void setMainPermutationId(String mainPermutationId) {
		this.mainPermutationId = mainPermutationId;
	}
	public String getCallIntent1() {
		return callIntent1;
	}
	public void setCallIntent1(String callIntent1) {
		this.callIntent1 = callIntent1;
	}
	public String getCallIntent2() {
		return callIntent2;
	}
	public void setCallIntent2(String callIntent2) {
		this.callIntent2 = callIntent2;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getFilterKey() {
		return filterKey;
	}
	public void setFilterKey(String filterKey) {
		this.filterKey = filterKey;
	}
	public String getLocalId() {
		return localId;
	}
	public void setLocalId(String localId) {
		this.localId = localId;
	}
	public String getSalesChannel() {
		return salesChannel;
	}
	public void setSalesChannel(String salesChannel) {
		this.salesChannel = salesChannel;
	}
	public String getTransportTypeGroup() {
		return transportTypeGroup;
	}
	public void setTransportTypeGroup(String transportTypeGroup) {
		this.transportTypeGroup = transportTypeGroup;
	}
	public String getSwitchOnOff() {
		return switchOnOff;
	}
	public void setSwitchOnOff(String switchOnOff) {
		this.switchOnOff = switchOnOff;
	}
	public String getIsNewComp() {
		return isNewComp;
	}
	public void setIsNewComp(String isNewComp) {
		this.isNewComp = isNewComp;
	}
	public String getIsPremium() {
		return isPremium;
	}
	public void setIsPremium(String isPremium) {
		this.isPremium = isPremium;
	}
	public String getCreditRisk() {
		return creditRisk;
	}
	public void setCreditRisk(String creditRisk) {
		this.creditRisk = creditRisk;
	}
	public String getTeamSkills() {
		return teamSkills;
	}
	public void setTeamSkills(String teamSkills) {
		this.teamSkills = teamSkills;
	}
	public String getSecurityProfile() {
		return securityProfile;
	}
	public void setSecurityProfile(String securityProfile) {
		this.securityProfile = securityProfile;
	}
	public String getDealerGroup() {
		return dealerGroup;
	}
	public void setDealerGroup(String dealerGroup) {
		this.dealerGroup = dealerGroup;
	}
	public String getMsc() {
		return msc;
	}
	public void setMsc(String msc) {
		this.msc = msc;
	}
	public String getIsNewService() {
		return isNewService;
	}
	public void setIsNewService(String isNewService) {
		this.isNewService = isNewService;
	}
	public String getGeoCode() {
		return geoCode;
	}
	public void setGeoCode(String geoCode) {
		this.geoCode = geoCode;
	}
	public String getZipCodeExclusion() {
		return zipCodeExclusion;
	}
	public void setZipCodeExclusion(String zipCodeExclusion) {
		this.zipCodeExclusion = zipCodeExclusion;
	}
	public String getCreditBand() {
		return creditBand;
	}
	public void setCreditBand(String creditBand) {
		this.creditBand = creditBand;
	}
	public String getTreatmentCode() {
		return treatmentCode;
	}
	public void setTreatmentCode(String treatmentCode) {
		this.treatmentCode = treatmentCode;
	}
	public String getPartnerName() {
		return partnerName;
	}
	public void setPartnerName(String partnerName) {
		this.partnerName = partnerName;
	}
	public String getCustomerSubtype() {
		return customerSubtype;
	}
	public void setCustomerSubtype(String customerSubtype) {
		this.customerSubtype = customerSubtype;
	}
	private String startDate;
	private String endDate;
	private String filterKey;
	private String localId;
	private String salesChannel;
	private String transportTypeGroup;
	private String switchOnOff;
	private String isNewComp;
	private String isPremium;
	private String creditRisk;
	private String teamSkills;
	private String securityProfile;
	private String dealerGroup;
	private String msc;
	private String isNewService;
	private String geoCode;
	private String zipCodeExclusion;
	private String creditBand;
	private String treatmentCode;
	private String partnerName;
	private String customerSubtype;
	
}
