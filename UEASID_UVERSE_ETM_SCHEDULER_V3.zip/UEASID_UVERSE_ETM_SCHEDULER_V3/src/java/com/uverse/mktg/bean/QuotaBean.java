package com.uverse.mktg.bean;

public class QuotaBean {

	private String globalStatus;
	private String quotaID;
	private String bundlePromoID;
	private String offerID;
	private String bundlePromotionType;
	private String quotaLevel;
	private String entityID;
	private String startDate;
	private String endDate;
	private String quotaAmount;
	private String deployDate;
	private String CTDBCreationDateTime;
	private String lastImportDateTime;
	private String lastImportedBy;
	private String rowActionCode;
	private String workEffortName;
	private String environmentSource;
	
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((CTDBCreationDateTime == null) ? 0 : CTDBCreationDateTime
						.hashCode());
		result = prime * result
				+ ((bundlePromoID == null) ? 0 : bundlePromoID.hashCode());
		result = prime
				* result
				+ ((bundlePromotionType == null) ? 0 : bundlePromotionType
						.hashCode());
		result = prime * result
				+ ((deployDate == null) ? 0 : deployDate.hashCode());
		result = prime * result + ((endDate == null) ? 0 : endDate.hashCode());
		result = prime * result
				+ ((entityID == null) ? 0 : entityID.hashCode());
		result = prime
				* result
				+ ((environmentSource == null) ? 0 : environmentSource
						.hashCode());
		result = prime * result
				+ ((globalStatus == null) ? 0 : globalStatus.hashCode());
		result = prime
				* result
				+ ((lastImportDateTime == null) ? 0 : lastImportDateTime
						.hashCode());
		result = prime * result
				+ ((lastImportedBy == null) ? 0 : lastImportedBy.hashCode());
		result = prime * result + ((offerID == null) ? 0 : offerID.hashCode());
		result = prime * result
				+ ((quotaAmount == null) ? 0 : quotaAmount.hashCode());
		result = prime * result + ((quotaID == null) ? 0 : quotaID.hashCode());
		result = prime * result
				+ ((quotaLevel == null) ? 0 : quotaLevel.hashCode());
		result = prime * result
				+ ((rowActionCode == null) ? 0 : rowActionCode.hashCode());
		result = prime * result
				+ ((startDate == null) ? 0 : startDate.hashCode());
		result = prime * result
				+ ((workEffortName == null) ? 0 : workEffortName.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		QuotaBean other = (QuotaBean) obj;
		if (CTDBCreationDateTime == null) {
			if (other.CTDBCreationDateTime != null)
				return false;
		} else if (!CTDBCreationDateTime.equals(other.CTDBCreationDateTime))
			return false;
		if (bundlePromoID == null) {
			if (other.bundlePromoID != null)
				return false;
		} else if (!bundlePromoID.equals(other.bundlePromoID))
			return false;
		if (bundlePromotionType == null) {
			if (other.bundlePromotionType != null)
				return false;
		} else if (!bundlePromotionType.equals(other.bundlePromotionType))
			return false;
		if (deployDate == null) {
			if (other.deployDate != null)
				return false;
		} else if (!deployDate.equals(other.deployDate))
			return false;
		if (endDate == null) {
			if (other.endDate != null)
				return false;
		} else if (!endDate.equals(other.endDate))
			return false;
		if (entityID == null) {
			if (other.entityID != null)
				return false;
		} else if (!entityID.equals(other.entityID))
			return false;
		if (environmentSource == null) {
			if (other.environmentSource != null)
				return false;
		} else if (!environmentSource.equals(other.environmentSource))
			return false;
		if (globalStatus == null) {
			if (other.globalStatus != null)
				return false;
		} else if (!globalStatus.equals(other.globalStatus))
			return false;
		if (lastImportDateTime == null) {
			if (other.lastImportDateTime != null)
				return false;
		} else if (!lastImportDateTime.equals(other.lastImportDateTime))
			return false;
		if (lastImportedBy == null) {
			if (other.lastImportedBy != null)
				return false;
		} else if (!lastImportedBy.equals(other.lastImportedBy))
			return false;
		if (offerID == null) {
			if (other.offerID != null)
				return false;
		} else if (!offerID.equals(other.offerID))
			return false;
		if (quotaAmount == null) {
			if (other.quotaAmount != null)
				return false;
		} else if (!quotaAmount.equals(other.quotaAmount))
			return false;
		if (quotaID == null) {
			if (other.quotaID != null)
				return false;
		} else if (!quotaID.equals(other.quotaID))
			return false;
		if (quotaLevel == null) {
			if (other.quotaLevel != null)
				return false;
		} else if (!quotaLevel.equals(other.quotaLevel))
			return false;
		if (rowActionCode == null) {
			if (other.rowActionCode != null)
				return false;
		} else if (!rowActionCode.equals(other.rowActionCode))
			return false;
		if (startDate == null) {
			if (other.startDate != null)
				return false;
		} else if (!startDate.equals(other.startDate))
			return false;
		if (workEffortName == null) {
			if (other.workEffortName != null)
				return false;
		} else if (!workEffortName.equals(other.workEffortName))
			return false;
		return true;
	}
	public String getGlobalStatus() {
		return globalStatus;
	}
	public void setGlobalStatus(String globalStatus) {
		this.globalStatus = globalStatus;
	}
	public String getQuotaID() {
		return quotaID;
	}
	public void setQuotaID(String quotaID) {
		this.quotaID = quotaID;
	}
	public String getBundlePromoID() {
		return bundlePromoID;
	}
	public void setBundlePromoID(String bundlePromoID) {
		this.bundlePromoID = bundlePromoID;
	}
	public String getOfferID() {
		return offerID;
	}
	public void setOfferID(String offerID) {
		this.offerID = offerID;
	}
	public String getBundlePromotionType() {
		return bundlePromotionType;
	}
	public void setBundlePromotionType(String bundlePromotionType) {
		this.bundlePromotionType = bundlePromotionType;
	}
	public String getQuotaLevel() {
		return quotaLevel;
	}
	public void setQuotaLevel(String quotaLevel) {
		this.quotaLevel = quotaLevel;
	}
	public String getEntityID() {
		return entityID;
	}
	public void setEntityID(String entityID) {
		this.entityID = entityID;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getQuotaAmount() {
		return quotaAmount;
	}
	public void setQuotaAmount(String quotaAmount) {
		this.quotaAmount = quotaAmount;
	}
	public String getDeployDate() {
		return deployDate;
	}
	public void setDeployDate(String deployDate) {
		this.deployDate = deployDate;
	}
	public String getCTDBCreationDateTime() {
		return CTDBCreationDateTime;
	}
	public void setCTDBCreationDateTime(String creationDateTime) {
		CTDBCreationDateTime = creationDateTime;
	}
	public String getLastImportDateTime() {
		return lastImportDateTime;
	}
	public void setLastImportDateTime(String lastImportDateTime) {
		this.lastImportDateTime = lastImportDateTime;
	}
	public String getLastImportedBy() {
		return lastImportedBy;
	}
	public void setLastImportedBy(String lastImportedBy) {
		this.lastImportedBy = lastImportedBy;
	}
	public String getRowActionCode() {
		return rowActionCode;
	}
	public void setRowActionCode(String rowActionCode) {
		this.rowActionCode = rowActionCode;
	}
	public String getWorkEffortName() {
		return workEffortName;
	}
	public void setWorkEffortName(String workEffortName) {
		this.workEffortName = workEffortName;
	}
	public String getEnvironmentSource() {
		return environmentSource;
	}
	public void setEnvironmentSource(String environmentSource) {
		this.environmentSource = environmentSource;
	}
	
}
