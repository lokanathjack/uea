package com.uverse.mktg.bean;

public class BundlePromoBean {
	private String newChangeDeploymentDate;
	private String status; 
	private String notes; 
	private String offerId;
	private String promoCode; 
	private String component; 
	private String baseOfferDescription; 
	private String baseOfferId; 
	private String promoType; 
	private String bundleIds; 
	private String promoBillDisplay; 
	private String omsDisplay; 
	private String medAndLongDesc; 
	private String promoExpDateBillDisplay; 
	private String promotionAmount; 
	private String monthsDiscountApplied;  
	private String promoCtr;

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((baseOfferDescription == null) ? 0 : baseOfferDescription
						.hashCode());
		result = prime * result
				+ ((baseOfferId == null) ? 0 : baseOfferId.hashCode());
		result = prime * result
				+ ((bundleIds == null) ? 0 : bundleIds.hashCode());
		result = prime * result
				+ ((component == null) ? 0 : component.hashCode());
		result = prime * result
				+ ((medAndLongDesc == null) ? 0 : medAndLongDesc.hashCode());
		result = prime
				* result
				+ ((monthsDiscountApplied == null) ? 0 : monthsDiscountApplied
						.hashCode());
		result = prime
				* result
				+ ((newChangeDeploymentDate == null) ? 0
						: newChangeDeploymentDate.hashCode());
		result = prime * result + ((notes == null) ? 0 : notes.hashCode());
		result = prime * result + ((offerId == null) ? 0 : offerId.hashCode());
		result = prime * result
				+ ((omsDisplay == null) ? 0 : omsDisplay.hashCode());
		result = prime
				* result
				+ ((promoBillDisplay == null) ? 0 : promoBillDisplay.hashCode());
		result = prime * result
				+ ((promoCode == null) ? 0 : promoCode.hashCode());
		result = prime * result
				+ ((promoCtr == null) ? 0 : promoCtr.hashCode());
		result = prime
				* result
				+ ((promoExpDateBillDisplay == null) ? 0
						: promoExpDateBillDisplay.hashCode());
		result = prime * result
				+ ((promoType == null) ? 0 : promoType.hashCode());
		result = prime * result
				+ ((promotionAmount == null) ? 0 : promotionAmount.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BundlePromoBean other = (BundlePromoBean) obj;
		if (baseOfferDescription == null) {
			if (other.baseOfferDescription != null)
				return false;
		} else if (!baseOfferDescription.equals(other.baseOfferDescription))
			return false;
		if (baseOfferId == null) {
			if (other.baseOfferId != null)
				return false;
		} else if (!baseOfferId.equals(other.baseOfferId))
			return false;
		if (bundleIds == null) {
			if (other.bundleIds != null)
				return false;
		} else if (!bundleIds.equals(other.bundleIds))
			return false;
		if (component == null) {
			if (other.component != null)
				return false;
		} else if (!component.equals(other.component))
			return false;
		if (medAndLongDesc == null) {
			if (other.medAndLongDesc != null)
				return false;
		} else if (!medAndLongDesc.equals(other.medAndLongDesc))
			return false;
		if (monthsDiscountApplied == null) {
			if (other.monthsDiscountApplied != null)
				return false;
		} else if (!monthsDiscountApplied.equals(other.monthsDiscountApplied))
			return false;
		if (newChangeDeploymentDate == null) {
			if (other.newChangeDeploymentDate != null)
				return false;
		} else if (!newChangeDeploymentDate
				.equals(other.newChangeDeploymentDate))
			return false;
		if (notes == null) {
			if (other.notes != null)
				return false;
		} else if (!notes.equals(other.notes))
			return false;
		if (offerId == null) {
			if (other.offerId != null)
				return false;
		} else if (!offerId.equals(other.offerId))
			return false;
		if (omsDisplay == null) {
			if (other.omsDisplay != null)
				return false;
		} else if (!omsDisplay.equals(other.omsDisplay))
			return false;
		if (promoBillDisplay == null) {
			if (other.promoBillDisplay != null)
				return false;
		} else if (!promoBillDisplay.equals(other.promoBillDisplay))
			return false;
		if (promoCode == null) {
			if (other.promoCode != null)
				return false;
		} else if (!promoCode.equals(other.promoCode))
			return false;
		if (promoCtr == null) {
			if (other.promoCtr != null)
				return false;
		} else if (!promoCtr.equals(other.promoCtr))
			return false;
		if (promoExpDateBillDisplay == null) {
			if (other.promoExpDateBillDisplay != null)
				return false;
		} else if (!promoExpDateBillDisplay
				.equals(other.promoExpDateBillDisplay))
			return false;
		if (promoType == null) {
			if (other.promoType != null)
				return false;
		} else if (!promoType.equals(other.promoType))
			return false;
		if (promotionAmount == null) {
			if (other.promotionAmount != null)
				return false;
		} else if (!promotionAmount.equals(other.promotionAmount))
			return false;
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		return true;
	}
	public String getNewChangeDeploymentDate() {
		return newChangeDeploymentDate;
	}
	public void setNewChangeDeploymentDate(String newChangeDeploymentDate) {
		this.newChangeDeploymentDate = newChangeDeploymentDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public String getOfferId() {
		return offerId;
	}
	public void setOfferId(String offerId) {
		this.offerId = offerId;
	}
	public String getPromoCode() {
		return promoCode;
	}
	public void setPromoCode(String promoCode) {
		this.promoCode = promoCode;
	}
	public String getComponent() {
		return component;
	}
	public void setComponent(String component) {
		this.component = component;
	}
	public String getBaseOfferDescription() {
		return baseOfferDescription;
	}
	public void setBaseOfferDescription(String baseOfferDescription) {
		this.baseOfferDescription = baseOfferDescription;
	}
	public String getBaseOfferId() {
		return baseOfferId;
	}
	public void setBaseOfferId(String baseOfferId) {
		this.baseOfferId = baseOfferId;
	}
	public String getPromoType() {
		return promoType;
	}
	public void setPromoType(String promoType) {
		this.promoType = promoType;
	}
	public String getBundleIds() {
		return bundleIds;
	}
	public void setBundleIds(String bundleIds) {
		this.bundleIds = bundleIds;
	}
	public String getPromoBillDisplay() {
		return promoBillDisplay;
	}
	public void setPromoBillDisplay(String promoBillDisplay) {
		this.promoBillDisplay = promoBillDisplay;
	}
	public String getOmsDisplay() {
		return omsDisplay;
	}
	public void setOmsDisplay(String omsDisplay) {
		this.omsDisplay = omsDisplay;
	}
	public String getMedAndLongDesc() {
		return medAndLongDesc;
	}
	public void setMedAndLongDesc(String medAndLongDesc) {
		this.medAndLongDesc = medAndLongDesc;
	}
	public String getPromoExpDateBillDisplay() {
		return promoExpDateBillDisplay;
	}
	public void setPromoExpDateBillDisplay(String promoExpDateBillDisplay) {
		this.promoExpDateBillDisplay = promoExpDateBillDisplay;
	}
	public String getPromotionAmount() {
		return promotionAmount;
	}
	public void setPromotionAmount(String promotionAmount) {
		this.promotionAmount = promotionAmount;
	}
	public String getMonthsDiscountApplied() {
		return monthsDiscountApplied;
	}
	public void setMonthsDiscountApplied(String monthsDiscountApplied) {
		this.monthsDiscountApplied = monthsDiscountApplied;
	}
	public String getPromoCtr() {
		return promoCtr;
	}
	public void setPromoCtr(String promoCtr) {
		this.promoCtr = promoCtr;
	}
	
}
