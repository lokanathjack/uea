package com.uverse.mktg.bean;

public class SomBean {

	private String newChangeDeploymentDate;
	private String status;
	private String notes;
	private String offerId;
	private String promotionCode;
	private String component;
	private String productsAndPlans;
	private String baseOfferId;
	private String grandfatherVersions;
	private String rcOCPromo;
	private String promoType;
	private String promotionBillDisplay;
	private String myattComDisplay;
	private String promotionAmount;
	private String monthsDiscountApplied;
	private String medAndLongDesc;
	private String promoExpirationDateBillDisplay;
	private String groupRuleAssigned;
	private String quotaAssigned;
	private String contractETF;
	private String promoExemption;
	private String customerSubtype;
	private String somGeo;
	private String omsDisplay;
	private String saleStartDate;
	private String saleEndDate;
	private String rankings;
	private String promoActionType;
	private String premium_Tiers;
	private String promoCtr;
	private String paperlessPromoType;
	private String displayMonthsBeforeExpiration;
	private String flexiblePricing;
	//fields for DTV
	private String heartValue;
	private String churnMitigation;
	private String accountTypes;
	private String dynamicUpgrade;
	private String rollToPay;
	
	public String getRollToPay() {
		return rollToPay;
	}
	public void setRollToPay(String rollToPay) {
		this.rollToPay = rollToPay;
	}
	public String getPaperlessPromoType() {
		return paperlessPromoType;
	}
	public void setPaperlessPromoType(String paperlessPromoType) {
		this.paperlessPromoType = paperlessPromoType;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((baseOfferId == null) ? 0 : baseOfferId.hashCode());
		result = prime * result
				+ ((component == null) ? 0 : component.hashCode());
		result = prime * result
				+ ((contractETF == null) ? 0 : contractETF.hashCode());
		result = prime * result
				+ ((customerSubtype == null) ? 0 : customerSubtype.hashCode());
		result = prime
				* result
				+ ((displayMonthsBeforeExpiration == null) ? 0
						: displayMonthsBeforeExpiration.hashCode());
		result = prime
				* result
				+ ((flexiblePricing == null) ? 0
						: flexiblePricing.hashCode());
		result = prime
				* result
				+ ((grandfatherVersions == null) ? 0 : grandfatherVersions
						.hashCode());
		result = prime
				* result
				+ ((groupRuleAssigned == null) ? 0 : groupRuleAssigned
						.hashCode());
		result = prime * result
				+ ((medAndLongDesc == null) ? 0 : medAndLongDesc.hashCode());
		result = prime
				* result
				+ ((monthsDiscountApplied == null) ? 0 : monthsDiscountApplied
						.hashCode());
		result = prime * result
				+ ((myattComDisplay == null) ? 0 : myattComDisplay.hashCode());
		result = prime
				* result
				+ ((newChangeDeploymentDate == null) ? 0
						: newChangeDeploymentDate.hashCode());
		result = prime * result + ((notes == null) ? 0 : notes.hashCode());
		result = prime * result + ((offerId == null) ? 0 : offerId.hashCode());
		result = prime * result
				+ ((omsDisplay == null) ? 0 : omsDisplay.hashCode());
		result = prime
				* result
				+ ((paperlessPromoType == null) ? 0 : paperlessPromoType
						.hashCode());
		result = prime * result
				+ ((premium_Tiers == null) ? 0 : premium_Tiers.hashCode());
		result = prime
				* result
				+ ((productsAndPlans == null) ? 0 : productsAndPlans.hashCode());
		result = prime * result
				+ ((promoActionType == null) ? 0 : promoActionType.hashCode());
		result = prime * result
				+ ((promoCtr == null) ? 0 : promoCtr.hashCode());
		result = prime * result
				+ ((promoExemption == null) ? 0 : promoExemption.hashCode());
		result = prime
				* result
				+ ((promoExpirationDateBillDisplay == null) ? 0
						: promoExpirationDateBillDisplay.hashCode());
		result = prime * result
				+ ((promoType == null) ? 0 : promoType.hashCode());
		result = prime * result
				+ ((promotionAmount == null) ? 0 : promotionAmount.hashCode());
		result = prime
				* result
				+ ((promotionBillDisplay == null) ? 0 : promotionBillDisplay
						.hashCode());
		result = prime * result
				+ ((promotionCode == null) ? 0 : promotionCode.hashCode());
		result = prime * result
				+ ((quotaAssigned == null) ? 0 : quotaAssigned.hashCode());
		result = prime * result
				+ ((rankings == null) ? 0 : rankings.hashCode());
		result = prime * result
				+ ((rcOCPromo == null) ? 0 : rcOCPromo.hashCode());
		result = prime * result
				+ ((saleEndDate == null) ? 0 : saleEndDate.hashCode());
		result = prime * result
				+ ((saleStartDate == null) ? 0 : saleStartDate.hashCode());
		result = prime * result + ((somGeo == null) ? 0 : somGeo.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SomBean other = (SomBean) obj;
		if (baseOfferId == null) {
			if (other.baseOfferId != null)
				return false;
		} else if (!baseOfferId.equals(other.baseOfferId))
			return false;
		if (component == null) {
			if (other.component != null)
				return false;
		} else if (!component.equals(other.component))
			return false;
		if (contractETF == null) {
			if (other.contractETF != null)
				return false;
		} else if (!contractETF.equals(other.contractETF))
			return false;
		if (customerSubtype == null) {
			if (other.customerSubtype != null)
				return false;
		} else if (!customerSubtype.equals(other.customerSubtype))
			return false;
		if (displayMonthsBeforeExpiration == null) {
			if (other.displayMonthsBeforeExpiration != null)
				return false;
		} else if (!displayMonthsBeforeExpiration
				.equals(other.displayMonthsBeforeExpiration))
			return false;
		if (flexiblePricing == null) {
			if (other.flexiblePricing != null)
				return false;
		} else if (!flexiblePricing
				.equals(other.flexiblePricing))
			return false;
		if (grandfatherVersions == null) {
			if (other.grandfatherVersions != null)
				return false;
		} else if (!grandfatherVersions.equals(other.grandfatherVersions))
			return false;
		if (groupRuleAssigned == null) {
			if (other.groupRuleAssigned != null)
				return false;
		} else if (!groupRuleAssigned.equals(other.groupRuleAssigned))
			return false;
		if (medAndLongDesc == null) {
			if (other.medAndLongDesc != null)
				return false;
		} else if (!medAndLongDesc.equals(other.medAndLongDesc))
			return false;
		if (monthsDiscountApplied == null) {
			if (other.monthsDiscountApplied != null)
				return false;
		} else if (!monthsDiscountApplied.equals(other.monthsDiscountApplied))
			return false;
		if (myattComDisplay == null) {
			if (other.myattComDisplay != null)
				return false;
		} else if (!myattComDisplay.equals(other.myattComDisplay))
			return false;
		if (newChangeDeploymentDate == null) {
			if (other.newChangeDeploymentDate != null)
				return false;
		} else if (!newChangeDeploymentDate
				.equals(other.newChangeDeploymentDate))
			return false;
		if (notes == null) {
			if (other.notes != null)
				return false;
		} else if (!notes.equals(other.notes))
			return false;
		if (offerId == null) {
			if (other.offerId != null)
				return false;
		} else if (!offerId.equals(other.offerId))
			return false;
		if (omsDisplay == null) {
			if (other.omsDisplay != null)
				return false;
		} else if (!omsDisplay.equals(other.omsDisplay))
			return false;
		if (paperlessPromoType == null) {
			if (other.paperlessPromoType != null)
				return false;
		} else if (!paperlessPromoType.equals(other.paperlessPromoType))
			return false;
		if (premium_Tiers == null) {
			if (other.premium_Tiers != null)
				return false;
		} else if (!premium_Tiers.equals(other.premium_Tiers))
			return false;
		if (productsAndPlans == null) {
			if (other.productsAndPlans != null)
				return false;
		} else if (!productsAndPlans.equals(other.productsAndPlans))
			return false;
		if (promoActionType == null) {
			if (other.promoActionType != null)
				return false;
		} else if (!promoActionType.equals(other.promoActionType))
			return false;
		if (promoCtr == null) {
			if (other.promoCtr != null)
				return false;
		} else if (!promoCtr.equals(other.promoCtr))
			return false;
		if (promoExemption == null) {
			if (other.promoExemption != null)
				return false;
		} else if (!promoExemption.equals(other.promoExemption))
			return false;
		if (promoExpirationDateBillDisplay == null) {
			if (other.promoExpirationDateBillDisplay != null)
				return false;
		} else if (!promoExpirationDateBillDisplay
				.equals(other.promoExpirationDateBillDisplay))
			return false;
		if (promoType == null) {
			if (other.promoType != null)
				return false;
		} else if (!promoType.equals(other.promoType))
			return false;
		if (promotionAmount == null) {
			if (other.promotionAmount != null)
				return false;
		} else if (!promotionAmount.equals(other.promotionAmount))
			return false;
		if (promotionBillDisplay == null) {
			if (other.promotionBillDisplay != null)
				return false;
		} else if (!promotionBillDisplay.equals(other.promotionBillDisplay))
			return false;
		if (promotionCode == null) {
			if (other.promotionCode != null)
				return false;
		} else if (!promotionCode.equals(other.promotionCode))
			return false;
		if (quotaAssigned == null) {
			if (other.quotaAssigned != null)
				return false;
		} else if (!quotaAssigned.equals(other.quotaAssigned))
			return false;
		if (rankings == null) {
			if (other.rankings != null)
				return false;
		} else if (!rankings.equals(other.rankings))
			return false;
		if (rcOCPromo == null) {
			if (other.rcOCPromo != null)
				return false;
		} else if (!rcOCPromo.equals(other.rcOCPromo))
			return false;
		if (saleEndDate == null) {
			if (other.saleEndDate != null)
				return false;
		} else if (!saleEndDate.equals(other.saleEndDate))
			return false;
		if (saleStartDate == null) {
			if (other.saleStartDate != null)
				return false;
		} else if (!saleStartDate.equals(other.saleStartDate))
			return false;
		if (somGeo == null) {
			if (other.somGeo != null)
				return false;
		} else if (!somGeo.equals(other.somGeo))
			return false;
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		return true;
	}
	public String getNewChangeDeploymentDate() {
		return newChangeDeploymentDate;
	}
	public void setNewChangeDeploymentDate(String newChangeDeploymentDate) {
		this.newChangeDeploymentDate = newChangeDeploymentDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public String getOfferId() {
		return offerId;
	}
	public void setOfferId(String offerId) {
		this.offerId = offerId;
	}
	public String getPromotionCode() {
		return promotionCode;
	}
	public void setPromotionCode(String promotionCode) {
		this.promotionCode = promotionCode;
	}
	public String getComponent() {
		return component;
	}
	public void setComponent(String component) {
		this.component = component;
	}
	public String getProductsAndPlans() {
		return productsAndPlans;
	}
	public void setProductsAndPlans(String productsAndPlans) {
		this.productsAndPlans = productsAndPlans;
	}
	public String getBaseOfferId() {
		return baseOfferId;
	}
	public void setBaseOfferId(String baseOfferId) {
		this.baseOfferId = baseOfferId;
	}
	public String getGrandfatherVersions() {
		return grandfatherVersions;
	}
	public void setGrandfatherVersions(String grandfatherVersions) {
		this.grandfatherVersions = grandfatherVersions;
	}
	public String getRcOCPromo() {
		return rcOCPromo;
	}
	public void setRcOCPromo(String rcOCPromo) {
		this.rcOCPromo = rcOCPromo;
	}
	public String getPromoType() {
		return promoType;
	}
	public void setPromoType(String promoType) {
		this.promoType = promoType;
	}
	public String getPromotionBillDisplay() {
		return promotionBillDisplay;
	}
	public void setPromotionBillDisplay(String promotionBillDisplay) {
		this.promotionBillDisplay = promotionBillDisplay;
	}
	public String getMyattComDisplay() {
		return myattComDisplay;
	}
	public void setMyattComDisplay(String myattComDisplay) {
		this.myattComDisplay = myattComDisplay;
	}
	public String getPromotionAmount() {
		return promotionAmount;
	}
	public void setPromotionAmount(String promotionAmount) {
		this.promotionAmount = promotionAmount;
	}
	public String getMonthsDiscountApplied() {
		return monthsDiscountApplied;
	}
	public void setMonthsDiscountApplied(String monthsDiscountApplied) {
		this.monthsDiscountApplied = monthsDiscountApplied;
	}
	public String getMedAndLongDesc() {
		return medAndLongDesc;
	}
	public void setMedAndLongDesc(String medAndLongDesc) {
		this.medAndLongDesc = medAndLongDesc;
	}
	public String getPromoExpirationDateBillDisplay() {
		return promoExpirationDateBillDisplay;
	}
	public void setPromoExpirationDateBillDisplay(
			String promoExpirationDateBillDisplay) {
		this.promoExpirationDateBillDisplay = promoExpirationDateBillDisplay;
	}
	public String getGroupRuleAssigned() {
		return groupRuleAssigned;
	}
	public void setGroupRuleAssigned(String groupRuleAssigned) {
		this.groupRuleAssigned = groupRuleAssigned;
	}
	public String getQuotaAssigned() {
		return quotaAssigned;
	}
	public void setQuotaAssigned(String quotaAssigned) {
		this.quotaAssigned = quotaAssigned;
	}
	public String getContractETF() {
		return contractETF;
	}
	public void setContractETF(String contractETF) {
		this.contractETF = contractETF;
	}
	public String getPromoExemption() {
		return promoExemption;
	}
	public void setPromoExemption(String promoExemption) {
		this.promoExemption = promoExemption;
	}
	public String getCustomerSubtype() {
		return customerSubtype;
	}
	public void setCustomerSubtype(String customerSubtype) {
		this.customerSubtype = customerSubtype;
	}
	public String getSomGeo() {
		return somGeo;
	}
	public void setSomGeo(String somGeo) {
		this.somGeo = somGeo;
	}
	public String getOmsDisplay() {
		return omsDisplay;
	}
	public void setOmsDisplay(String omsDisplay) {
		this.omsDisplay = omsDisplay;
	}
	public String getSaleStartDate() {
		return saleStartDate;
	}
	public void setSaleStartDate(String saleStartDate) {
		this.saleStartDate = saleStartDate;
	}
	public String getSaleEndDate() {
		return saleEndDate;
	}
	public void setSaleEndDate(String saleEndDate) {
		this.saleEndDate = saleEndDate;
	}
	public String getRankings() {
		return rankings;
	}
	public void setRankings(String rankings) {
		this.rankings = rankings;
	}
	public String getPromoActionType() {
		return promoActionType;
	}
	public void setPromoActionType(String promoActionType) {
		this.promoActionType = promoActionType;
	}
	public String getPremium_Tiers() {
		return premium_Tiers;
	}
	public void setPremium_Tiers(String premium_Tiers) {
		this.premium_Tiers = premium_Tiers;
	}
	public String getPromoCtr() {
		return promoCtr;
	}
	public void setPromoCtr(String promoCtr) {
		this.promoCtr = promoCtr;
	}
	public String getDisplayMonthsBeforeExpiration() {
		return displayMonthsBeforeExpiration;
	}
	public void setDisplayMonthsBeforeExpiration(
			String displayMonthsBeforeExpiration) {
		this.displayMonthsBeforeExpiration = displayMonthsBeforeExpiration;
	}
	public String getFlexiblePricing() {
		return flexiblePricing;
	}
	public void setFlexiblePricing(String flexiblePricing) {
		this.flexiblePricing = flexiblePricing;
	}
	public String getHeartValue() {
		return heartValue;
	}
	public void setHeartValue(String heartValue) {
		this.heartValue = heartValue;
	}
	public String getChurnMitigation() {
		return churnMitigation;
	}
	public void setChurnMitigation(String churnMitigation) {
		this.churnMitigation = churnMitigation;
	}
	public String getAccountTypes() {
		return accountTypes;
	}
	public void setAccountTypes(String accountTypes) {
		this.accountTypes = accountTypes;
	}
	public String getDynamicUpgrade() {
		return dynamicUpgrade;
	}
	public void setDynamicUpgrade(String dynamicUpgrade) {
		this.dynamicUpgrade = dynamicUpgrade;
	}
}
