package com.uverse.mktg.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class UtilityDAO {

	public static void truncateBackupTable(Connection conn,
			String backupTableName) throws SQLException {

		Statement stmt = conn.createStatement();
		String sqlTruncateBkp = "DELETE FROM " + backupTableName;
		stmt.executeUpdate(sqlTruncateBkp);
		System.out.println("Truncating Backup table");
	}

	public static void copyFromMasterToBackup(Connection conn,
			String backupTableName, String mainTableName) throws SQLException {

		Statement stmt = conn.createStatement();
		String sqlCopyFromMasterToBkp = "INSERT INTO " + backupTableName
				+ " SELECT * FROM " + mainTableName;
		stmt.executeUpdate(sqlCopyFromMasterToBkp);
		System.out.println("Copy from master to backup table");
	}

	public static void truncateMasterTable(Connection conn, String mainTableName)
			throws SQLException {

		Statement stmt = conn.createStatement();
		String sqlTruncateMaster = "DELETE FROM " + mainTableName;
		stmt.executeUpdate(sqlTruncateMaster);
		System.out.println("Truncating Master table");
	}

	// Methods for SOM table with "where" clause for Component

	public static void truncateBackupTableSom(Connection conn,
			String backupTableName, String component) throws SQLException {

		Statement stmt = conn.createStatement();
		String sqlTruncateBkp = "DELETE FROM " + backupTableName
				+ " WHERE COMPONENT= '" + component + "'";
		stmt.executeUpdate(sqlTruncateBkp);
		System.out.println("Truncating Backup table");
	}

	public static void copyFromMasterToBackupSom(Connection conn,
			String backupTableName, String mainTableName, String component)
			throws SQLException {

		Statement stmt = conn.createStatement();
		String sqlCopyFromMasterToBkp = "INSERT INTO " + backupTableName
				+ " SELECT * FROM " + mainTableName + " WHERE COMPONENT= '"
				+ component + "'";
		stmt.executeUpdate(sqlCopyFromMasterToBkp);
		System.out.println("Copy from master to backup table");
	}

	public static void truncateMasterTableSom(Connection conn,
			String mainTableName, String component) throws SQLException {

		Statement stmt = conn.createStatement();
		String sqlTruncateMaster = "DELETE FROM " + mainTableName
				+ " WHERE COMPONENT= '" + component + "'";
		stmt.executeUpdate(sqlTruncateMaster);
		System.out.println("Truncating Master table");
	}
	
	// Methods for PROMO table with "where" clause for Component

	public static void truncateBackupTablePromo(Connection conn,
			String backupTableName, String lob) throws SQLException {

		Statement stmt = conn.createStatement();
		String sqlTruncateBkp = "DELETE FROM " + backupTableName
				+ " WHERE LOB= '" + lob + "'";
		stmt.executeUpdate(sqlTruncateBkp);
		System.out.println("Truncating Backup table");
	}

	public static void copyFromMasterToBackupPromo(Connection conn,
			String backupTableName, String mainTableName, String lob)
			throws SQLException {

		Statement stmt = conn.createStatement();
		String sqlCopyFromMasterToBkp = "INSERT INTO " + backupTableName
				+ " SELECT * FROM " + mainTableName + " WHERE LOB= '"
				+ lob + "'";
		stmt.executeUpdate(sqlCopyFromMasterToBkp);
		System.out.println("Copy from master to backup table");
	}

	public static void truncateMasterTablePromo(Connection conn,
			String mainTableName, String lob) throws SQLException {

		Statement stmt = conn.createStatement();
		String sqlTruncateMaster = "DELETE FROM " + mainTableName
				+ " WHERE LOB= '" + lob + "'";
		stmt.executeUpdate(sqlTruncateMaster);
		System.out.println("Truncating Master table");
	}
	
}
